"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect, ReactNode } from "react"

type Language = "uz" | "ru" | "en"

interface Translations {
  select: any
  view: ReactNode
  writeReview: ReactNode
  customerReviews: ReactNode
  productFeatures: ReactNode
  technicalSpecs: ReactNode
  freeShipping: ReactNode
  // Navigation
  home: string
  about: string
  contact: string
  login: string
  register: string
  logout: string
  search: string
  cart: string
  myAccount: string
  myOrders: string
  myWishlist: string
  categories: string
  smartphones: string
  tablets: string
  laptops: string
  headphones: string
  smartwatches: string
  accessories: string
  aboutCompany: string

  // Auth
  firstName: string
  email: string
  phone: string
  password: string
  forgotPassword: string
  dontHaveAccount: string
  haveAccount: string
  verifyAccount: string
  verificationCodeSent: string
  didntReceiveCode: string
  resendCode: string
  verify: string
  forgotPasswordInstructions: string
  resetPassword: string
  backToLogin: string
  nameRequired: string
  emailRequired: string
  phoneRequired: string
  passwordRequired: string
  verificationCodeRequired: string
  passwordResetSent: string
  agreeToTerms: string
  termsOfService: string
  and: string
  privacyPolicy: string
  acceptTermsRequired: string
  or: string
  rememberMe: string

  // Product
  addToCart: string
  add: string
  added: string
  featured: string
  viewAll: string
  ideal: string
  good: string
  price: string
  memory: string
  battery: string
  box: string
  region: string
  warranty: string
  color: string
  sortBy: string
  priceRange: string
  priceLowToHigh: string
  priceHighToLow: string
  nameAtoZ: string
  nameZtoA: string
  filters: string
  resetFilters: string
  noProducts: string
  tryOtherFilters: string
  productsAvailable: string
  moreDetails: string
  viewAllPhones: string
  shopNow: string
  productAdded: string
  productAddedDesc: string
  outOfStock: string
  inStock: string
  quantity: string
  totalPrice: string
  checkout: string
  continueShopping: string
  emptyCart: string
  emptyCartDesc: string
  removeFromCart: string
  clearCart: string
  subtotal: string
  discount: string
  total: string
  promoCode: string
  apply: string
  applied: string
  invalidPromoCode: string
  orderSummary: string
  proceedToCheckout: string
  recommendedProducts: string
  featuredProducts: string
  newArrivals: string
  bestSellers: string
  onSale: string
  category: string
  brand: string
  condition: string
  availability: string
  rating: string
  reviews: string
  specifications: string
  description: string
  features: string
  relatedProducts: string
  addToWishlist: string
  removeFromWishlist: string
  share: string
  searchResults: string
  searchFor: string
  noSearchResults: string
  tryDifferentKeywords: string
  backToHome: string
  filterByPrice: string
  filterByCategory: string
  filterByBrand: string
  filterByCondition: string
  filterByAvailability: string
  filterByRating: string
  sortByRelevance: string
  sortByPopularity: string
  sortByNewest: string
  sortByPriceAsc: string
  sortByPriceDesc: string
  sortByRating: string
  sortByReviews: string
  showMore: string
  showLess: string
  readMore: string
  readLess: string
  viewDetails: string
  buyNow: string
  addedToCart: string
  goToCart: string
  continueShoppingBtn: string
  outOfStockMsg: string
  notifyMe: string
  notifyMeDesc: string
  emailPlaceholder: string
  phonePlaceholder: string
  passwordPlaceholder: string
  searchPlaceholder: string
  promoCodePlaceholder: string
  firstNamePlaceholder: string
  lastNamePlaceholder: string
  addressPlaceholder: string
  cityPlaceholder: string
  postalCodePlaceholder: string
  countryPlaceholder: string
  commentPlaceholder: string
  reviewPlaceholder: string
  questionPlaceholder: string
  answerPlaceholder: string

  // Hero
  heroTitle: string
  heroDescription: string
  newModel: string
  sixMonthWarranty: string
  sixMonthPayment: string

  // Features
  qualityGuarantee: string
  qualityDescription: string
  fastDelivery: string
  deliveryDescription: string
  easyPayment: string
  paymentDescription: string
  support: string
  supportDescription: string
  bonuses: string
  bonusesDescription: string
  authenticity: string
  authenticityDescription: string
  whyChooseUs: string

  // Footer
  companyInfo: string
  allRightsReserved: string
  address: string
  workHours: string
  trackOrder: string
  news: string
  faq: string
  contactUs: string
  followUs: string
  subscribeToNewsletter: string
  subscribeDesc: string
  subscribe: string
  yourEmail: string
  copyright: string
  termsAndConditions: string
  returnPolicy: string
  shippingPolicy: string
  paymentMethods: string
  careers: string
  blog: string
  partners: string
  affiliateProgram: string

  // Company page
  companyHistory: string
  ourMission: string
  ourVision: string
  ourTeam: string
  ourValues: string
  ourAchievements: string
  ourPartners: string
  ourLocation: string
  joinOurTeam: string
  frequentlyAskedQuestions: string
  question: string
  answer: string

  // About Company Page - Additional translations
  pageTitle: string
  companyName: string
  tagline: string
  aboutUs: string
  aboutDescription: string
  productsDescription: string
  happyCustomers: string
  stores: string
  storesInTashkent: string
  contactDescription: string
  addressValue: string
  workingHours: string
  workingHoursWeekdays: string
  workingHoursSunday: string
  socialNetworks: string
  faqQuestion1: string
  faqAnswer1: string
  faqQuestion2: string
  faqAnswer2: string
  faqQuestion3: string
  faqAnswer3: string
  faqQuestion4: string
  faqAnswer4: string
  faqQuestion5: string
  faqAnswer5: string
  ourStores: string
  storeChilanzar: string
  storeChilanzarBranch: string
  storeChilanzarAddress: string
  storeWorkingHours: string
  viewOnMap: string
  storeYunusabad: string
  storeYunusabadBranch: string
  storeYunusabadAddress: string
  storeSergeli: string
  storeSergeliBranch: string
  storeSergeliAddress: string
  latestProducts: string
  productDescription: string
  colors: string
  color1: string
  color2: string
  color3: string
  ourMissionTitle: string
  missionDescription: string
  quality: string
  trust: string
  trustDescription: string
  innovation: string
  innovationDescription: string
  value1: string
  value2: string
  value3: string
  historyDescription: string
  historyDescription2: string
  historyTimeline: string
  historyEvent1: string
  historyYear2020: string
  historyDesc2020: string
  historyYear2022: string
  historyDesc2022: string
  historyYear2025: string
  historyDesc2025: string
  phoneNumber: string
  addressShort: string
  footerText: string
  campaign: string
  siteCreator: string

  // Account
  myProfile: string
  editProfile: string
  myAddresses: string
  myPaymentMethods: string
  myNotifications: string
  myReviews: string
  myQuestions: string
  myWishList: string
  orderHistory: string
  trackMyOrder: string
  returns: string
  cancellations: string
  savedCards: string
  changePassword: string
  deleteAccount: string
  logoutFromAllDevices: string
  personalInformation: string
  shippingInformation: string
  billingInformation: string
  notificationSettings: string
  privacySettings: string
  accountSettings: string

  // Checkout
  shippingAddress: string
  billingAddress: string
  sameAsShipping: string
  paymentMethod: string
  orderDetails: string
  placeOrder: string
  orderConfirmation: string
  thankYouForYourOrder: string
  orderNumber: string
  orderDate: string
  orderStatus: string
  paymentStatus: string
  shippingMethod: string
  deliveryDate: string
  deliveryAddress: string
  billingDetails: string
  orderItems: string

  // Notifications
  successfulLogin: string
  successfulRegistration: string
  successfulLogout: string
  successfulPasswordReset: string
  successfulPasswordChange: string
  successfulProfileUpdate: string
  successfulAddressAdd: string
  successfulAddressUpdate: string
  successfulAddressDelete: string
  successfulCardAdd: string
  successfulCardUpdate: string
  successfulCardDelete: string
  successfulOrderPlace: string
  successfulOrderCancel: string
  successfulReturnRequest: string
  successfulSubscription: string
  successfulUnsubscription: string
  successfulContactSubmission: string
  successfulReviewSubmission: string
  successfulQuestionSubmission: string

  // Error messages
  errorLogin: string
  errorRegistration: string
  errorPasswordReset: string
  errorPasswordChange: string
  errorProfileUpdate: string
  errorAddressAdd: string
  errorAddressUpdate: string
  errorAddressDelete: string
  errorCardAdd: string
  errorCardUpdate: string
  errorCardDelete: string
  errorOrderPlace: string
  errorOrderCancel: string
  errorReturnRequest: string
  errorSubscription: string
  errorUnsubscription: string
  errorContactSubmission: string
  errorReviewSubmission: string
  errorQuestionSubmission: string
  errorGeneral: string

  // Time
  today: string
  yesterday: string
  days: string
  hours: string
  minutes: string
  seconds: string

  // Other
  yes: string
  no: string
  ok: string
  cancel: string
  save: string
  edit: string
  delete: string
  remove: string
  update: string
  create: string
  submit: string
  confirm: string
  back: string
  next: string
  previous: string
  finish: string
  continue: string
  loading: string
  processing: string
  sending: string
  uploading: string
  downloading: string
  success: string
  error: string
  warning: string
  info: string
}

// Define translations for each language
const translations: Record<Language, Translations> = {
  uz: {
    // Navigation
    home: "Bosh sahifa",
    about: "Biz haqimizda",
    contact: "Aloqa",
    login: "Kirish",
    register: "Ro'yxatdan o'tish",
    logout: "Chiqish",
    search: "Qidirish",
    cart: "Savatcha",
    myAccount: "Mening hisobim",
    myOrders: "Mening buyurtmalarim",
    myWishlist: "Mening sevimlilarim",
    categories: "Kategoriyalar",
    smartphones: "Smartfonlar",
    tablets: "Planshetlar",
    laptops: "Noutbuklar",
    headphones: "Quloqchinlar",
    smartwatches: "Aqlli soatlar",
    accessories: "Aksessuarlar",
    aboutCompany: "Kompaniya haqida",

    // Auth
    firstName: "Ismingiz",
    email: "Elektron pochta",
    phone: "Telefon raqami",
    password: "Parol",
    forgotPassword: "Parolni unutdingizmi?",
    dontHaveAccount: "Hisobingiz yo'qmi? Ro'yxatdan o'ting",
    haveAccount: "Hisobingiz bormi? Kirish",
    verifyAccount: "Hisobingizni tasdiqlang",
    verificationCodeSent: "Tasdiqlash kodi yuborildi",
    didntReceiveCode: "Kodni olmadingizmi?",
    resendCode: "Qayta yuborish",
    verify: "Tasdiqlash",
    forgotPasswordInstructions: "Parolni tiklash uchun elektron pochtangizni kiriting. Biz sizga tiklash havolasini yuboramiz.",
    resetPassword: "Parolni tiklash",
    backToLogin: "Kirishga qaytish",
    nameRequired: "Ism kiritilishi shart",
    emailRequired: "Elektron pochta kiritilishi shart",
    phoneRequired: "Telefon raqami kiritilishi shart",
    passwordRequired: "Parol kiritilishi shart",
    verificationCodeRequired: "Tasdiqlash kodi kiritilishi shart",
    passwordResetSent: "Parolni tiklash havolasi yuborildi",
    agreeToTerms: "Men roziman",
    termsOfService: "Xizmat ko'rsatish shartlari",
    and: "va",
    privacyPolicy: "Maxfiylik siyosati",
    acceptTermsRequired: "Shartlarni qabul qilishingiz kerak",
    or: "YOKI",
    rememberMe: "Meni eslab qolish",

    // Product
    addToCart: "Savatga qo'shish",
    add: "Qo'shish",
    added: "Qo'shildi",
    featured: "Tavsiya etilgan mahsulotlar",
    viewAll: "Hammasini ko'rish",
    ideal: "Ideal",
    good: "Yaxshi",
    price: "Narxi",
    memory: "Xotira",
    battery: "Batareya",
    box: "Qutisi",
    region: "Mintaqa",
    warranty: "Kafolat",
    color: "Rang",
    sortBy: "Saralash",
    priceRange: "Narx oralig'i",
    priceLowToHigh: "Narx: pastdan yuqoriga",
    priceHighToLow: "Narx: yuqoridan pastga",
    nameAtoZ: "Nom: A dan Z gacha",
    nameZtoA: "Nom: Z dan A gacha",
    filters: "Filtrlar",
    resetFilters: "Filtrlarni tiklash",
    noProducts: "Mahsulotlar topilmadi",
    tryOtherFilters: "Boshqa filtrlarni sinab ko'ring",
    productsAvailable: "mahsulot mavjud",
    moreDetails: "Batafsil ma'lumot",
    viewAllPhones: "Barcha telefonlarni ko'rish",
    shopNow: "Hozir xarid qilish",
    productAdded: "Mahsulot qo'shildi",
    productAddedDesc: "Mahsulot savatchangizga qo'shildi",
    outOfStock: "Mavjud emas",
    inStock: "Mavjud",
    quantity: "Miqdori",
    totalPrice: "Umumiy narx",
    checkout: "Buyurtma berish",
    continueShopping: "Xarid qilishni davom ettirish",
    emptyCart: "Savatingiz bo'sh",
    emptyCartDesc: "Siz hali savatchangizga hech narsa qo'shmaganga o'xshaysiz",
    removeFromCart: "Savatdan olib tashlash",
    clearCart: "Savatni tozalash",
    subtotal: "Oraliq jami",
    discount: "Chegirma",
    total: "Jami",
    promoCode: "Promo kod",
    apply: "Qo'llash",
    applied: "Qo'llanildi",
    invalidPromoCode: "Noto'g'ri promo kod",
    orderSummary: "Buyurtma xulosasi",
    proceedToCheckout: "Buyurtma berishga o'tish",
    recommendedProducts: "Tavsiya etilgan mahsulotlar",
    featuredProducts: "Tanlangan mahsulotlar",
    newArrivals: "Yangi kelganlar",
    bestSellers: "Eng ko'p sotilganlar",
    onSale: "Chegirmada",
    category: "Kategoriya",
    brand: "Brend",
    condition: "Holati",
    availability: "Mavjudligi",
    rating: "Reyting",
    reviews: "Sharhlar",
    specifications: "Xususiyatlar",
    description: "Tavsif",
    features: "Xususiyatlar",
    relatedProducts: "O'xshash mahsulotlar",
    addToWishlist: "Sevimlilar ro'yxatiga qo'shish",
    removeFromWishlist: "Sevimlilar ro'yxatidan olib tashlash",
    share: "Ulashish",
    searchResults: "Qidiruv natijalari",
    searchFor: "Qidirish",
    noSearchResults: "Qidiruv natijalari topilmadi",
    tryDifferentKeywords: "Boshqa kalit so'zlarni sinab ko'ring",
    backToHome: "Bosh sahifaga qaytish",
    filterByPrice: "Narx bo'yicha filtrlash",
    filterByCategory: "Kategoriya bo'yicha filtrlash",
    filterByBrand: "Brend bo'yicha filtrlash",
    filterByCondition: "Holat bo'yicha filtrlash",
    filterByAvailability: "Mavjudlik bo'yicha filtrlash",
    filterByRating: "Reyting bo'yicha filtrlash",
    sortByRelevance: "Dolzarblik bo'yicha saralash",
    sortByPopularity: "Mashhurlik bo'yicha saralash",
    sortByNewest: "Eng yangi bo'yicha saralash",
    sortByPriceAsc: "Narx: pastdan yuqoriga saralash",
    sortByPriceDesc: "Narx: yuqoridan pastga saralash",
    sortByRating: "Reyting bo'yicha saralash",
    sortByReviews: "Sharhlar bo'yicha saralash",
    showMore: "Ko'proq ko'rsatish",
    showLess: "Kamroq ko'rsatish",
    readMore: "Ko'proq o'qish",
    readLess: "Kamroq o'qish",
    viewDetails: "Tafsilotlarni ko'rish",
    buyNow: "Hozir sotib olish",
    addedToCart: "Savatga qo'shildi",
    goToCart: "Savatga o'tish",
    continueShoppingBtn: "Xarid qilishni davom ettirish",
    outOfStockMsg: "Bu mahsulot hozirda mavjud emas",
    notifyMe: "Menga xabar bering",
    notifyMeDesc: "Bu mahsulot mavjud bo'lganda sizga xabar beramiz",
    emailPlaceholder: "Elektron pochtangizni kiriting",
    phonePlaceholder: "Telefon raqamingizni kiriting",
    passwordPlaceholder: "Parolingizni kiriting",
    searchPlaceholder: "Mahsulotlarni qidirish",
    promoCodePlaceholder: "Promo kodni kiriting",
    firstNamePlaceholder: "Ismingizni kiriting",
    lastNamePlaceholder: "Familiyangizni kiriting",
    addressPlaceholder: "Manzilingizni kiriting",
    cityPlaceholder: "Shahringizni kiriting",
    postalCodePlaceholder: "Pochta indeksingizni kiriting",
    countryPlaceholder: "Davlatingizni kiriting",
    commentPlaceholder: "Izohingizni kiriting",
    reviewPlaceholder: "Sharhingizni yozing",
    questionPlaceholder: "Savol bering",
    answerPlaceholder: "Javobingizni yozing",

    // Hero
    heroTitle: "iPhone 16 Pro Max - Eng kuchli iPhone",
    heroDescription: "Yangi A19 Pro protsessori, yangilangan kamera tizimi va yanada ko'proq xotira bilan.",
    newModel: "Yangi model",
    sixMonthWarranty: "6 oylik kafolat",
    sixMonthPayment: "6 oylik to'lov",

    // Features
    qualityGuarantee: "Sifat kafolati",
    qualityDescription: "Barcha mahsulotlar qattiq sifat nazoratidan o'tkaziladi",
    fastDelivery: "Tezkor yetkazib berish",
    deliveryDescription: "Toshkent bo'ylab 24 soat ichida yetkazib berish",
    easyPayment: "Qulay to'lov",
    paymentDescription: "Naqd, karta va muddatli to'lov imkoniyati",
    support: "24/7 qo'llab-quvvatlash",
    supportDescription: "Har qanday savollar bo'yicha yordam",
    bonuses: "Bonuslar va aksiyalar",
    bonusesDescription: "Har bir xarid uchun bonus ballari",
    authenticity: "100% original",
    authenticityDescription: "Faqat original Apple mahsulotlari",
    whyChooseUs: "Nega bizni tanlashingiz kerak",

    // Footer
    companyInfo: "Seven - O'zbekistondagi eng yirik Apple mahsulotlari do'koni. Biz 2018 yildan beri mijozlarimizga sifatli mahsulotlar va xizmatlar taqdim etib kelmoqdamiz.",
    allRightsReserved: "Barcha huquqlar himoyalangan",
    address: "Farg'ona, Sayilgoh ko'chasi 29",
    workHours: "9:00 - 21:00, har kuni",
    trackOrder: "Buyurtmani kuzatish",
    news: "Yangiliklar va videolar",
    faq: "Ko'p so'raladigan savollar",
    contactUs: "Biz bilan bog'lanish",
    followUs: "Bizni kuzating",
    subscribeToNewsletter: "Yangiliklarimizga obuna bo'ling",
    subscribeDesc: "Eng so'nggi yangiliklar va maxsus takliflarni oling",
    subscribe: "Obuna bo'lish",
    yourEmail: "Elektron pochtangiz",
    copyright: "Mualliflik huquqi",
    termsAndConditions: "Foydalanish shartlari",
    returnPolicy: "Qaytarish siyosati",
    shippingPolicy: "Yetkazib berish siyosati",
    paymentMethods: "To'lov usullari",
    careers: "Karyera",
    blog: "Blog",
    partners: "Hamkorlar",
    affiliateProgram: "Hamkorlik dasturi",

    // Company page
    companyHistory: "Kompaniya tarixi",
    ourMission: "Bizning vazifamiz",
    ourVision: "Bizning ko'rinishimiz",
    ourTeam: "Bizning jamoa",
    ourValues: "Bizning qadriyatlarimiz",
    ourAchievements: "Bizning yutuqlarimiz",
    ourPartners: "Bizning hamkorlarimiz",
    ourLocation: "Bizning joylashuvimiz",
    joinOurTeam: "Jamoamizga qo'shiling",
    frequentlyAskedQuestions: "Ko'p so'raladigan savollar",
    question: "Savol",
    answer: "Javob",

    // About Company Page
    pageTitle: "Kompaniya haqida",
    companyName: "Seven",
    tagline: "O'zbekistondagi eng ishonchli va sifatli mobil qurilmalar hamda aksessuarlar sotuvchi do'kon",
    aboutUs: "Biz haqimizda",
    aboutDescription: "Seven Uz 2020 yilda tashkil etilgan bo'lib, O'zbekistondagi eng ishonchli va sifatli mobil qurilmalar hamda aksessuarlar sotuvchi do'konlardan biri hisoblanadi. Bizning asosiy maqsadimiz mijozlarimizga eng yuqori sifatli mahsulotlarni qulay narxlarda taqdim etishdir.",
    productsDescription: "Biz faqat original va sifatli mahsulotlarni sotamiz. Barcha mahsulotlar kafolat bilan ta'minlanadi. Bizning do'konda Apple, Samsung, Xiaomi, Huawei va boshqa brendlarning eng so'nggi rusumli smartfonlari, planshetlari va aksessuarlarini topishingiz mumkin.",
    happyCustomers: "Mamnun mijozlar",
    stores: "Do'konlar",
    storesInTashkent: "Toshkent bo'ylab",
    contactDescription: "Savol va takliflar uchun biz bilan bog'laning",
    addressValue: "Toshkent sh., Chilonzor tumani, 17-mavze, 1-uy",
    workingHours: "Ish vaqti:",
    workingHoursWeekdays: "Dushanba - Shanba: 9:00 - 22:00",
    workingHoursSunday: "Yakshanba: 10:00 - 20:00",
    socialNetworks: "Ijtimoiy tarmoqlar:",
    faqQuestion1: "Mahsulotlaringiz original va kafolatli ekanligiga qanday ishonch hosil qilishim mumkin?",
    faqAnswer1: "Barcha mahsulotlarimiz rasmiy distribyutorlardan keladi va sertifikatlar bilan ta'minlanadi. Har bir mahsulot kafolat kartasi bilan birga keladi va siz uni do'konimizda tekshirishingiz mumkin.",
    faqQuestion2: "Mahsulotlarni muddatli to'lov orqali sotib olish mumkinmi?",
    faqAnswer2: "Ha, biz 3, 6 va 12 oylik muddatli to'lov imkoniyatini taqdim etamiz. Buning uchun pasport va bank kartasi talab qilinadi.",
    faqQuestion3: "Mahsulotlarni O'zbekistonning boshqa shaharlariga yetkazib berish xizmati mavjudmi?",
    faqAnswer3: "Ha, biz O'zbekistonning barcha viloyatlariga yetkazib berish xizmatini taqdim etamiz. Yetkazib berish muddati 1-3 kun.",
    faqQuestion4: "Agar sotib olingan mahsulot menga yoqmasa, uni qaytarib berishim mumkinmi?",
    faqAnswer4: "Ha, siz mahsulotni 14 kun ichida qaytarishingiz mumkin, agar u ishlatilmagan va original qutisida bo'lsa.",
    faqQuestion5: "Do'koningizda qanday to'lov usullari mavjud?",
    faqAnswer5: "Biz naqd pul, bank kartasi, Click, Payme va boshqa to'lov tizimlari orqali to'lovlarni qabul qilamiz.",
    ourStores: "Bizning do'konlarimiz",
    storeChilanzar: "Seven Uz Chilonzor",
    storeChilanzarBranch: "Chilonzor filiali",
    storeChilanzarAddress: "Toshkent sh., Chilonzor tumani, 17-mavze, 1-uy",
    storeWorkingHours: "9:00 - 22:00 (har kuni)",
    viewOnMap: "Xaritada ko'rish",
    storeYunusabad: "Seven Uz Yunusobod",
    storeYunusabadBranch: "Yunusobod filiali",
    storeYunusabadAddress: "Toshkent sh., Yunusobod tumani, 4-mavze, 12-uy",
    storeSergeli: "Seven Uz Sergeli",
    storeSergeliBranch: "Sergeli filiali",
    storeSergeliAddress: "Toshkent sh., Sergeli tumani, 4-mavze, 12-uy",
    latestProducts: "Eng so'nggi premium mahsulotlar",
    productDescription: "Apple Watch Ultra 2, eng kuchli va chidamli Apple Watch",
    colors: "Ranglar:",
    color1: "Natural Titanium",
    color2: "Titanium Black",
    color3: "Titanium Orange",
    ourMissionTitle: "Bizning vazifamiz",
    missionDescription: "Seven Uz kompaniyasining asosiy vazifasi O'zbekiston aholisiga eng yuqori sifatli texnologik mahsulotlarni qulay narxlarda va muddatli to'lov imkoniyati bilan taqdim etishdir. Biz har bir mijozga alohida yondashib, uning ehtiyojlariga mos mahsulotni tanlashda yordam beramiz.",
    quality: "Sifat",
    trust: "Ishonch",
    trustDescription: "Yillar davomida ishonchni oqlaganmiz",
    innovation: "Innovatsiya",
    innovationDescription: "Eng so'nggi texnologiyalarni taqdim etamiz",
    value1: "Mijoz manfaati - Har doim mijoz manfaatini birinchi o'ringa qo'yamiz",
    value2: "Sifat - Faqat eng yuqori sifatli mahsulotlarni taqdim etamiz",
    value3: "Innovatsiya - Doimo yangiliklar va innovatsiyalarni izlaymiz",
    historyDescription: "Seven Uz 2020 yilda kichik internet-do'kon sifatida o'z faoliyatini boshladi. Dastlab biz faqat Apple mahsulotlarini sotish bilan shug'ullangan bo'lsak, keyinchalik Samsung, Xiaomi va boshqa brendlarning mahsulotlarini ham sotishni yo'lga qo'ydik.",
    historyDescription2: "2022 yilga kelib biz Toshkent shahrida o'z do'konlarimizni ochdik va bugungi kunda 5 dan ortiq do'konlarimiz faoliyat yuritmoqda. Biz doimiy ravishda o'sib bormoqdamiz va yaqin kelajakda O'zbekistonning boshqa shaharlarida ham do'konlar ochishni rejalashtirganmiz.",
    historyTimeline: "Seven Uz tarixi",
    historyEvent1: "Birinchi do'konimiz ochilishi (2022)",
    historyYear2020: "2020",
    historyDesc2020: "Seven Uz internet-do'koni sifatida faoliyatini boshladi",
    historyYear2022: "2022",
    historyDesc2022: "Toshkent shahrida birinchi jismoniy do'konimiz ochildi",
    historyYear2025: "2025",
    historyDesc2025: "O'zbekiston bo'ylab 10 dan ortiq do'konlar ochish rejasi",
    phoneNumber: "+998 98 777 11 33",
    addressShort: "Toshkent, Chilonzor tumani",
    footerText: "Seven - O'zbekistondagi eng yirik Apple mahsulotlari do'koni. Biz 2018 yildan beri mijozlarimizga sifatli mahsulotlar va xizmatlar taqdim etib kelmoqdamiz.",
    campaign: "Kampaniya: UNIPRO",
    siteCreator: "Sayt yaratuvchisi: Lazizbek Sheryigitov",

    // Account
    myProfile: "Mening profilim",
    editProfile: "Profilni tahrirlash",
    myAddresses: "Mening manzillarim",
    myPaymentMethods: "Mening to'lov usullarim",
    myNotifications: "Mening bildirishnomalarim",
    myReviews: "Mening sharhlarim",
    myQuestions: "Mening savollarim",
    myWishList: "Mening sevimlilarim",
    orderHistory: "Buyurtmalar tarixi",
    trackMyOrder: "Buyurtmamni kuzatish",
    returns: "Qaytarishlar",
    cancellations: "Bekor qilishlar",
    savedCards: "Saqlangan kartalar",
    changePassword: "Parolni o'zgartirish",
    deleteAccount: "Hisobni o'chirish",
    logoutFromAllDevices: "Barcha qurilmalardan chiqish",
    personalInformation: "Shaxsiy ma'lumotlar",
    shippingInformation: "Yetkazib berish ma'lumotlari",
    billingInformation: "Hisob-kitob ma'lumotlari",
    notificationSettings: "Bildirishnoma sozlamalari",
    privacySettings: "Maxfiylik sozlamalari",
    accountSettings: "Hisob sozlamalari",

    // Checkout
    shippingAddress: "Yetkazib berish manzili",
    billingAddress: "Hisob-kitob manzili",
    sameAsShipping: "Yetkazib berish manzili bilan bir xil",
    paymentMethod: "To'lov usuli",
    orderDetails: "Buyurtma tafsilotlari",
    placeOrder: "Buyurtma berish",
    orderConfirmation: "Buyurtma tasdiqlandi",
    thankYouForYourOrder: "Buyurtmangiz uchun rahmat",
    orderNumber: "Buyurtma raqami",
    orderDate: "Buyurtma sanasi",
    orderStatus: "Buyurtma holati",
    paymentStatus: "To'lov holati",
    shippingMethod: "Yetkazib berish usuli",
    deliveryDate: "Yetkazib berish sanasi",
    deliveryAddress: "Yetkazib berish manzili",
    billingDetails: "Hisob-kitob tafsilotlari",
    orderItems: "Buyurtma elementlari",

    // Notifications
    successfulLogin: "Muvaffaqiyatli kirildi",
    successfulRegistration: "Muvaffaqiyatli ro'yxatdan o'tildi",
    successfulLogout: "Muvaffaqiyatli chiqildi",
    successfulPasswordReset: "Parol muvaffaqiyatli tiklandi",
    successfulPasswordChange: "Parol muvaffaqiyatli o'zgartirildi",
    successfulProfileUpdate: "Profil muvaffaqiyatli yangilandi",
    successfulAddressAdd: "Manzil muvaffaqiyatli qo'shildi",
    successfulAddressUpdate: "Manzil muvaffaqiyatli yangilandi",
    successfulAddressDelete: "Manzil muvaffaqiyatli o'chirildi",
    successfulCardAdd: "Karta muvaffaqiyatli qo'shildi",
    successfulCardUpdate: "Karta muvaffaqiyatli yangilandi",
    successfulCardDelete: "Karta muvaffaqiyatli o'chirildi",
    successfulOrderPlace: "Buyurtma muvaffaqiyatli joylashtirildi",
    successfulOrderCancel: "Buyurtma muvaffaqiyatli bekor qilindi",
    successfulReturnRequest: "Qaytarish so'rovi muvaffaqiyatli yuborildi",
    successfulSubscription: "Muvaffaqiyatli obuna bo'lindi",
    successfulUnsubscription: "Muvaffaqiyatli obunadan chiqildi",
    successfulContactSubmission: "Aloqa formasi muvaffaqiyatli yuborildi",
    successfulReviewSubmission: "Sharh muvaffaqiyatli yuborildi",
    successfulQuestionSubmission: "Savol muvaffaqiyatli yuborildi",

    // Error messages
    errorLogin: "Kirishda xatolik yuz berdi",
    errorRegistration: "Ro'yxatdan o'tishda xatolik yuz berdi",
    errorPasswordReset: "Parolni tiklashda xatolik yuz berdi",
    errorPasswordChange: "Parolni o'zgartirishda xatolik yuz berdi",
    errorProfileUpdate: "Profilni yangilashda xatolik yuz berdi",
    errorAddressAdd: "Manzil qo'shishda xatolik yuz berdi",
    errorAddressUpdate: "Manzilni yangilashda xatolik yuz berdi",
    errorAddressDelete: "Manzilni o'chirishda xatolik yuz berdi",
    errorCardAdd: "Karta qo'shishda xatolik yuz berdi",
    errorCardUpdate: "Kartani yangilashda xatolik yuz berdi",
    errorCardDelete: "Kartani o'chirishda xatolik yuz berdi",
    errorOrderPlace: "Buyurtma joylashtirishda xatolik yuz berdi",
    errorOrderCancel: "Buyurtmani bekor qilishda xatolik yuz berdi",
    errorReturnRequest: "Qaytarish so'rovini yuborishda xatolik yuz berdi",
    errorSubscription: "Obuna bo'lishda xatolik yuz berdi",
    errorUnsubscription: "Obunadan chiqishda xatolik yuz berdi",
    errorContactSubmission: "Aloqa formasini yuborishda xatolik yuz berdi",
    errorReviewSubmission: "Sharhni yuborishda xatolik yuz berdi",
    errorQuestionSubmission: "Savolni yuborishda xatolik yuz berdi",
    errorGeneral: "Xatolik yuz berdi",

    // Time
    today: "Bugun",
    yesterday: "Kecha",
    days: "kun",
    hours: "soat",
    minutes: "daqiqa",
    seconds: "soniya",

    // Other
    yes: "Ha",
    no: "Yo'q",
    ok: "OK",
    cancel: "Bekor qilish",
    save: "Saqlash",
    edit: "Tahrirlash",
    delete: "O'chirish",
    remove: "Olib tashlash",
    update: "Yangilash",
    create: "Yaratish",
    submit: "Yuborish",
    confirm: "Tasdiqlash",
    back: "Orqaga",
    next: "Keyingi",
    previous: "Oldingi",
    finish: "Tugatish",
    continue: "Davom etish",
    loading: "Yuklanmoqda",
    processing: "Ishlanmoqda",
    sending: "Yuborilmoqda",
    uploading: "Yuklanmoqda",
    downloading: "Yuklab olinmoqda",
    success: "Muvaffaqiyat",
    error: "Xatolik",
    warning: "Ogohlantirish",
    info: "Ma'lumot",
    view: undefined,
    writeReview: undefined,
    customerReviews: undefined,
    productFeatures: undefined,
    technicalSpecs: undefined,
    freeShipping: undefined
  },
  ru: {
    // Navigation
    home: "Главная",
    about: "О нас",
    contact: "Контакты",
    login: "Вход",
    register: "Регистрация",
    logout: "Выход",
    search: "Поиск",
    cart: "Корзина",
    myAccount: "Мой аккаунт",
    myOrders: "Мои заказы",
    myWishlist: "Избранное",
    categories: "Категории",
    smartphones: "Смартфоны",
    tablets: "Планшеты",
    laptops: "Ноутбуки",
    headphones: "Наушники",
    smartwatches: "Умные часы",
    accessories: "Аксессуары",
    aboutCompany: "О компании",

    // Auth
    firstName: "Имя",
    email: "Электронная почта",
    phone: "Телефон",
    password: "Пароль",
    forgotPassword: "Забыли пароль?",
    dontHaveAccount: "Нет аккаунта? Зарегистрируйтесь",
    haveAccount: "Уже есть аккаунт? Войти",
    verifyAccount: "Подтвердите аккаунт",
    verificationCodeSent: "Код подтверждения отправлен",
    didntReceiveCode: "Не получили код?",
    resendCode: "Отправить повторно",
    verify: "Подтвердить",
    forgotPasswordInstructions: "Введите вашу электронную почту для восстановления пароля. Мы отправим вам ссылку для сброса.",
    resetPassword: "Сбросить пароль",
    backToLogin: "Вернуться к входу",
    nameRequired: "Имя обязательно",
    emailRequired: "Электронная почта обязательна",
    phoneRequired: "Телефон обязателен",
    passwordRequired: "Пароль обязателен",
    verificationCodeRequired: "Код подтверждения обязателен",
    passwordResetSent: "Ссылка для сброса пароля отправлена",
    agreeToTerms: "Я согласен с",
    termsOfService: "Условиями использования",
    and: "и",
    privacyPolicy: "Политикой конфиденциальности",
    acceptTermsRequired: "Вы должны принять условия",
    or: "ИЛИ",
    rememberMe: "Запомнить меня",

    // Product
    addToCart: "Добавить в корзину",
    add: "Добавить",
    added: "Добавлено",
    featured: "Рекомендуемые товары",
    viewAll: "Смотреть все",
    ideal: "Идеальное",
    good: "Хорошее",
    price: "Цена",
    memory: "Память",
    battery: "Батарея",
    box: "Коробка",
    region: "Регион",
    warranty: "Гарантия",
    color: "Цвет",
    sortBy: "Сортировать по",
    priceRange: "Диапазон цен",
    priceLowToHigh: "Цена: от низкой к высокой",
    priceHighToLow: "Цена: от высокой к низкой",
    nameAtoZ: "Название: от А до Я",
    nameZtoA: "Название: от Я до А",
    filters: "Фильтры",
    resetFilters: "Сбросить фильтры",
    noProducts: "Товары не найдены",
    tryOtherFilters: "Попробуйте другие фильтры",
    productsAvailable: "товаров доступно",
    moreDetails: "Подробнее",
    viewAllPhones: "Смотреть все телефоны",
    shopNow: "Купить сейчас",
    productAdded: "Товар добавлен",
    productAddedDesc: "Товар добавлен в вашу корзину",
    outOfStock: "Нет в наличии",
    inStock: "В наличии",
    quantity: "Количество",
    totalPrice: "Общая цена",
    checkout: "Оформить заказ",
    continueShopping: "Продолжить покупки",
    emptyCart: "Ваша корзина пуста",
    emptyCartDesc: "Похоже, вы еще ничего не добавили в корзину",
    removeFromCart: "Удалить из корзины",
    clearCart: "Очистить корзину",
    subtotal: "Промежуточный итог",
    discount: "Скидка",
    total: "Итого",
    promoCode: "Промо-код",
    apply: "Применить",
    applied: "Применено",
    invalidPromoCode: "Недействительный промо-код",
    orderSummary: "Сводка заказа",
    proceedToCheckout: "Перейти к оформлению",
    recommendedProducts: "Рекомендуемые товары",
    featuredProducts: "Избранные товары",
    newArrivals: "Новые поступления",
    bestSellers: "Бестселлеры",
    onSale: "Со скидкой",
    category: "Категория",
    brand: "Бренд",
    condition: "Состояние",
    availability: "Наличие",
    rating: "Рейтинг",
    reviews: "Отзывы",
    specifications: "Характеристики",
    description: "Описание",
    features: "Особенности",
    relatedProducts: "Похожие товары",
    addToWishlist: "Добавить в избранное",
    removeFromWishlist: "Удалить из избранного",
    share: "Поделиться",
    searchResults: "Результаты поиска",
    searchFor: "Поиск",
    noSearchResults: "Результаты поиска не найдены",
    tryDifferentKeywords: "Попробуйте другие ключевые слова",
    backToHome: "Вернуться на главную",
    filterByPrice: "Фильтр по цене",
    filterByCategory: "Фильтр по категории",
    filterByBrand: "Фильтр по бренду",
    filterByCondition: "Фильтр по состоянию",
    filterByAvailability: "Фильтр по наличию",
    filterByRating: "Фильтр по рейтингу",
    sortByRelevance: "Сортировать по релевантности",
    sortByPopularity: "Сортировать по популярности",
    sortByNewest: "Сортировать по новизне",
    sortByPriceAsc: "Сортировать по цене: от низкой к высокой",
    sortByPriceDesc: "Сортировать по цене: от высокой к низкой",
    sortByRating: "Сортировать по рейтингу",
    sortByReviews: "Сортировать по отзывам",
    showMore: "Показать больше",
    showLess: "Показать меньше",
    readMore: "Читать больше",
    readLess: "Читать меньше",
    viewDetails: "Посмотреть детали",
    buyNow: "Купить сейчас",
    addedToCart: "Добавлено в корзину",
    goToCart: "Перейти в корзину",
    continueShoppingBtn: "Продолжить покупки",
    outOfStockMsg: "Этого товара нет в наличии",
    notifyMe: "Уведомить меня",
    notifyMeDesc: "Мы уведомим вас, когда этот товар появится в наличии",
    emailPlaceholder: "Введите вашу электронную почту",
    phonePlaceholder: "Введите ваш номер телефона",
    passwordPlaceholder: "Введите ваш пароль",
    searchPlaceholder: "Поиск товаров",
    promoCodePlaceholder: "Введите промо-код",
    firstNamePlaceholder: "Введите ваше имя",
    lastNamePlaceholder: "Введите вашу фамилию",
    addressPlaceholder: "Введите ваш адрес",
    cityPlaceholder: "Введите ваш город",
    postalCodePlaceholder: "Введите ваш почтовый индекс",
    countryPlaceholder: "Введите вашу страну",
    commentPlaceholder: "Введите ваш комментарий",
    reviewPlaceholder: "Напишите ваш отзыв",
    questionPlaceholder: "Задайте вопрос",
    answerPlaceholder: "Напишите ваш ответ",

    // Hero
    heroTitle: "iPhone 16 Pro Max - Самый мощный iPhone",
    heroDescription: "С новым процессором A19 Pro, улучшенной системой камер и увеличенной памятью.",
    newModel: "Новая модель",
    sixMonthWarranty: "Гарантия 6 месяцев",
    sixMonthPayment: "Рассрочка на 6 месяцев",

    // Features
    qualityGuarantee: "Гарантия качества",
    qualityDescription: "Все товары проходят строгий контроль качества",
    fastDelivery: "Быстрая доставка",
    deliveryDescription: "Доставка по Ташкенту в течение 24 часов",
    easyPayment: "Удобная оплата",
    paymentDescription: "Наличные, карта и возможность рассрочки",
    support: "Поддержка 24/7",
    supportDescription: "Помощь по любым вопросам",
    bonuses: "Бонусы и акции",
    bonusesDescription: "Бонусные баллы за каждую покупку",
    authenticity: "100% оригинал",
    authenticityDescription: "Только оригинальные продукты Apple",
    whyChooseUs: "Почему стоит выбрать нас",

    // Footer
    companyInfo: "Seven - крупнейший магазин продукции Apple в Узбекистане. Мы предоставляем качественные товары и услуги нашим клиентам с 2018 года.",
    allRightsReserved: "Все права защищены",
    address: "Фергана, ул. Сайилгох 29",
    workHours: "9:00 - 21:00, ежедневно",
    trackOrder: "Отследить заказ",
    news: "Новости и видео",
    faq: "Часто задаваемые вопросы",
    contactUs: "Связаться с нами",
    followUs: "Следите за нами",
    subscribeToNewsletter: "Подпишитесь на нашу рассылку",
    subscribeDesc: "Получайте последние новости и специальные предложения",
    subscribe: "Подписаться",
    yourEmail: "Ваша электронная почта",
    copyright: "Авторское право",
    termsAndConditions: "Условия использования",
    returnPolicy: "Политика возврата",
    shippingPolicy: "Политика доставки",
    paymentMethods: "Способы оплаты",
    careers: "Карьера",
    blog: "Блог",
    partners: "Партнеры",
    affiliateProgram: "Партнерская программа",

    // Company page
    companyHistory: "История компании",
    ourMission: "Наша миссия",
    ourVision: "Наше видение",
    ourTeam: "Наша команда",
    ourValues: "Наши ценности",
    ourAchievements: "Наши достижения",
    ourPartners: "Наши партнеры",
    ourLocation: "Наше местоположение",
    joinOurTeam: "Присоединяйтесь к нашей команде",
    frequentlyAskedQuestions: "Часто задаваемые вопросы",
    question: "Вопрос",
    answer: "Ответ",

    // About Company Page
    pageTitle: "О компании",
    companyName: "Seven",
    tagline: "Самый надежный и качественный магазин мобильных устройств и аксессуаров в Узбекистане",
    aboutUs: "О нас",
    aboutDescription: "Seven Uz был основан в 2020 году и является одним из самых надежных и качественных магазинов мобильных устройств и аксессуаров в Узбекистане. Наша основная цель - предоставить нашим клиентам продукцию высочайшего качества по доступным ценам.",
    productsDescription: "Мы продаем только оригинальные и качественные продукты. Все товары поставляются с гарантией. В нашем магазине вы можете найти самые последние модели смартфонов, планшетов и аксессуаров от Apple, Samsung, Xiaomi, Huawei и других брендов.",
    happyCustomers: "Довольных клиентов",
    stores: "Магазинов",
    storesInTashkent: "По Ташкенту",
    contactDescription: "Свяжитесь с нами для вопросов и предложений",
    addressValue: "г. Ташкент, Чиланзарский район, 17-квартал, дом 1",
    workingHours: "Часы работы:",
    workingHoursWeekdays: "Понедельник - Суббота: 9:00 - 22:00",
    workingHoursSunday: "Воскресенье: 10:00 - 20:00",
    socialNetworks: "Социальные сети:",
    faqQuestion1: "Как я могу убедиться, что ваши продукты оригинальные и имеют гарантию?",
    faqAnswer1: "Все наши продукты поступают от официальных дистрибьюторов и поставляются с сертификатами. Каждый продукт поставляется с гарантийной картой, и вы можете проверить его в нашем магазине.",
    faqQuestion2: "Можно ли купить товары в рассрочку?",
    faqAnswer2: "Да, мы предоставляем возможность рассрочки на 3, 6 и 12 месяцев. Для этого требуется паспорт и банковская карта.",
    faqQuestion3: "Есть ли услуга доставки товаров в другие города Узбекистана?",
    faqAnswer3: "Да, мы предоставляем услугу доставки во все регионы Узбекистана. Срок доставки составляет 1-3 дня.",
    faqQuestion4: "Могу ли я вернуть товар, если он мне не понравился?",
    faqAnswer4: "Да, вы можете вернуть товар в течение 14 дней, если он не использовался и находится в оригинальной упаковке.",
    faqQuestion5: "Какие способы оплаты доступны в вашем магазине?",
    faqAnswer5: "Мы принимаем оплату наличными, банковскими картами, через Click, Payme и другие платежные системы.",
    ourStores: "Наши магазины",
    storeChilanzar: "Seven Uz Чиланзар",
    storeChilanzarBranch: "Чиланзарский филиал",
    storeChilanzarAddress: "г. Ташкент, Чиланзарский район, 17-квартал, дом 1",
    storeWorkingHours: "9:00 - 22:00 (ежедневно)",
    viewOnMap: "Посмотреть на карте",
    storeYunusabad: "Seven Uz Юнусабад",
    storeYunusabadBranch: "Юнусабадский филиал",
    storeYunusabadAddress: "г. Ташкент, Юнусабадский район, 4-квартал, дом 12",
    storeSergeli: "Seven Uz Сергели",
    storeSergeliBranch: "Сергелийский филиал",
    storeSergeliAddress: "г. Ташкент, Сергелийский район, 4-квартал, дом 12",
    latestProducts: "Последние премиум-продукты",
    productDescription: "Apple Watch Ultra 2, самые мощные и прочные Apple Watch",
    colors: "Цвета:",
    color1: "Натуральный титан",
    color2: "Титановый черный",
    color3: "Титановый оранжевый",
    ourMissionTitle: "Наша миссия",
    missionDescription: "Основная миссия компании Seven Uz - предоставить населению Узбекистана высококачественные технологические продукты по доступным ценам и с возможностью рассрочки. Мы индивидуально подходим к каждому клиенту и помогаем выбрать продукт, соответствующий его потребностям.",
    quality: "Качество",
    trust: "Доверие",
    trustDescription: "Мы оправдываем доверие на протяжении многих лет",
    innovation: "Инновации",
    innovationDescription: "Мы предлагаем самые последние технологии",
    value1: "Интересы клиента - Мы всегда ставим интересы клиента на первое место",
    value2: "Качество - Мы предлагаем только продукты высочайшего качества",
    value3: "Инновации - Мы всегда ищем новинки и инновации",
    historyDescription: "Seven Uz начал свою деятельность в 2020 году как небольшой интернет-магазин. Изначально мы занимались только продажей продукции Apple, но позже начали продавать продукцию Samsung, Xiaomi и других брендов.",
    historyDescription2: "К 2022 году мы открыли свои магазины в Ташкенте, и сегодня у нас работает более 5 магазинов. Мы постоянно растем и планируем открыть магазины в других городах Узбекистана в ближайшем будущем.",
    historyTimeline: "История Seven Uz",
    historyEvent1: "Открытие нашего первого магазина (2022)",
    historyYear2020: "2020",
    historyDesc2020: "Seven Uz начал свою деятельность как интернет-магазин",
    historyYear2022: "2022",
    historyDesc2022: "Открыт наш первый физический магазин в Ташкенте",
    historyYear2025: "2025",
    historyDesc2025: "План открытия более 10 магазинов по всему Узбекистану",
    phoneNumber: "+998 98 777 11 33",
    addressShort: "Ташкент, Чиланзарский район",
    footerText: "Seven - крупнейший магазин продукции Apple в Узбекистане. Мы предоставляем качественные товары и услуги нашим клиентам с 2018 года.",
    campaign: "Кампания: UNIPRO",
    siteCreator: "Создатель сайта: Лазизбек Шерйигитов",

    // Account
    myProfile: "Мой профиль",
    editProfile: "Редактировать профиль",
    myAddresses: "Мои адреса",
    myPaymentMethods: "Мои способы оплаты",
    myNotifications: "Мои уведомления",
    myReviews: "Мои отзывы",
    myQuestions: "Мои вопросы",
    myWishList: "Мои избранные",
    orderHistory: "История заказов",
    trackMyOrder: "Отследить мой заказ",
    returns: "Возвраты",
    cancellations: "Отмены",
    savedCards: "Сохраненные карты",
    changePassword: "Изменить пароль",
    deleteAccount: "Удалить аккаунт",
    logoutFromAllDevices: "Выйти со всех устройств",
    personalInformation: "Личная информация",
    shippingInformation: "Информация о доставке",
    billingInformation: "Платежная информация",
    notificationSettings: "Настройки уведомлений",
    privacySettings: "Настройки конфиденциальности",
    accountSettings: "Настройки аккаунта",

    // Checkout
    shippingAddress: "Адрес доставки",
    billingAddress: "Платежный адрес",
    sameAsShipping: "Совпадает с адресом доставки",
    paymentMethod: "Способ оплаты",
    orderDetails: "Детали заказа",
    placeOrder: "Разместить заказ",
    orderConfirmation: "Подтверждение заказа",
    thankYouForYourOrder: "Спасибо за ваш заказ",
    orderNumber: "Номер заказа",
    orderDate: "Дата заказа",
    orderStatus: "Статус заказа",
    paymentStatus: "Статус оплаты",
    shippingMethod: "Способ доставки",
    deliveryDate: "Дата доставки",
    deliveryAddress: "Адрес доставки",
    billingDetails: "Платежные реквизиты",
    orderItems: "Товары в заказе",

    // Notifications
    successfulLogin: "Успешный вход",
    successfulRegistration: "Успешная регистрация",
    successfulLogout: "Успешный выход",
    successfulPasswordReset: "Успешный сброс пароля",
    successfulPasswordChange: "Пароль успешно изменен",
    successfulProfileUpdate: "Профиль успешно обновлен",
    successfulAddressAdd: "Адрес успешно добавлен",
    successfulAddressUpdate: "Адрес успешно обновлен",
    successfulAddressDelete: "Адрес успешно удален",
    successfulCardAdd: "Карта успешно добавлена",
    successfulCardUpdate: "Карта успешно обновлена",
    successfulCardDelete: "Карта успешно удалена",
    successfulOrderPlace: "Заказ успешно размещен",
    successfulOrderCancel: "Заказ успешно отменен",
    successfulReturnRequest: "Запрос на возврат успешно отправлен",
    successfulSubscription: "Успешная подписка",
    successfulUnsubscription: "Успешная отписка",
    successfulContactSubmission: "Форма обратной связи успешно отправлена",
    successfulReviewSubmission: "Отзыв успешно отправлен",
    successfulQuestionSubmission: "Вопрос успешно отправлен",

    // Error messages
    errorLogin: "Ошибка входа",
    errorRegistration: "Ошибка регистрации",
    errorPasswordReset: "Ошибка сброса пароля",
    errorPasswordChange: "Ошибка изменения пароля",
    errorProfileUpdate: "Ошибка обновления профиля",
    errorAddressAdd: "Ошибка добавления адреса",
    errorAddressUpdate: "Ошибка обновления адреса",
    errorAddressDelete: "Ошибка удаления адреса",
    errorCardAdd: "Ошибка добавления карты",
    errorCardUpdate: "Ошибка обновления карты",
    errorCardDelete: "Ошибка удаления карты",
    errorOrderPlace: "Ошибка размещения заказа",
    errorOrderCancel: "Ошибка отмены заказа",
    errorReturnRequest: "Ошибка отправки запроса на возврат",
    errorSubscription: "Ошибка подписки",
    errorUnsubscription: "Ошибка отписки",
    errorContactSubmission: "Ошибка отправки формы обратной связи",
    errorReviewSubmission: "Ошибка отправки отзыва",
    errorQuestionSubmission: "Ошибка отправки вопроса",
    errorGeneral: "Что-то пошло не так",

    // Time
    today: "Сегодня",
    yesterday: "Вчера",
    days: "дней",
    hours: "часов",
    minutes: "минут",
    seconds: "секунд",

    // Other
    yes: "Да",
    no: "Нет",
    ok: "ОК",
    cancel: "Отмена",
    save: "Сохранить",
    edit: "Редактировать",
    delete: "Удалить",
    remove: "Удалить",
    update: "Обновить",
    create: "Создать",
    submit: "Отправить",
    confirm: "Подтвердить",
    back: "Назад",
    next: "Далее",
    previous: "Предыдущий",
    finish: "Завершить",
    continue: "Продолжить",
    loading: "Загрузка",
    processing: "Обработка",
    sending: "Отправка",
    uploading: "Загрузка",
    downloading: "Скачивание",
    success: "Успех",
    error: "Ошибка",
    warning: "Предупреждение",
    info: "Информация",
    view: undefined,
    writeReview: undefined,
    customerReviews: undefined,
    productFeatures: undefined,
    technicalSpecs: undefined,
    freeShipping: undefined
  },
  en: {
    // Navigation
    home: "Home",
    about: "About",
    contact: "Contact",
    login: "Login",
    register: "Register",
    logout: "Logout",
    search: "Search",
    cart: "Cart",
    myAccount: "My Account",
    myOrders: "My Orders",
    myWishlist: "My Wishlist",
    categories: "Categories",
    smartphones: "Smartphones",
    tablets: "Tablets",
    laptops: "Laptops",
    headphones: "Headphones",
    smartwatches: "Smartwatches",
    accessories: "Accessories",
    aboutCompany: "About Company",

    // Auth
    firstName: "First Name",
    email: "Email",
    phone: "Phone",
    password: "Password",
    forgotPassword: "Forgot Password?",
    dontHaveAccount: "Don't have an account? Register",
    haveAccount: "Already have an account? Login",
    verifyAccount: "Verify Account",
    verificationCodeSent: "Verification code sent",
    didntReceiveCode: "Didn't receive code?",
    resendCode: "Resend",
    verify: "Verify",
    forgotPasswordInstructions: "Enter your email to reset password. We'll send you a reset link.",
    resetPassword: "Reset Password",
    backToLogin: "Back to Login",
    nameRequired: "Name is required",
    emailRequired: "Email is required",
    phoneRequired: "Phone is required",
    passwordRequired: "Password is required",
    verificationCodeRequired: "Verification code is required",
    passwordResetSent: "Password reset link sent",
    agreeToTerms: "I agree to",
    termsOfService: "Terms of Service",
    and: "and",
    privacyPolicy: "Privacy Policy",
    acceptTermsRequired: "You must accept terms",
    or: "OR",
    rememberMe: "Remember me",

    // Product
    addToCart: "Add to Cart",
    add: "Add",
    added: "Added",
    featured: "Featured Products",
    viewAll: "View All",
    ideal: "Ideal",
    good: "Good",
    price: "Price",
    memory: "Memory",
    battery: "Battery",
    box: "Box",
    region: "Region",
    warranty: "Warranty",
    color: "Color",
    sortBy: "Sort By",
    priceRange: "Price Range",
    priceLowToHigh: "Price: Low to High",
    priceHighToLow: "Price: High to Low",
    nameAtoZ: "Name: A to Z",
    nameZtoA: "Name: Z to A",
    filters: "Filters",
    resetFilters: "Reset Filters",
    noProducts: "No Products Found",
    tryOtherFilters: "Try different filters",
    productsAvailable: "products available",
    moreDetails: "More Details",
    viewAllPhones: "View All Phones",
    shopNow: "Shop Now",
    productAdded: "Product Added",
    productAddedDesc: "Product has been added to your cart",
    outOfStock: "Out of Stock",
    inStock: "In Stock",
    quantity: "Quantity",
    totalPrice: "Total Price",
    checkout: "Checkout",
    continueShopping: "Continue Shopping",
    emptyCart: "Your Cart is Empty",
    emptyCartDesc: "Looks like you haven't added anything to your cart yet",
    removeFromCart: "Remove from Cart",
    clearCart: "Clear Cart",
    subtotal: "Subtotal",
    discount: "Discount",
    total: "Total",
    promoCode: "Promo Code",
    apply: "Apply",
    applied: "Applied",
    invalidPromoCode: "Invalid Promo Code",
    orderSummary: "Order Summary",
    proceedToCheckout: "Proceed to Checkout",
    recommendedProducts: "Recommended Products",
    featuredProducts: "Featured Products",
    newArrivals: "New Arrivals",
    bestSellers: "Best Sellers",
    onSale: "On Sale",
    category: "Category",
    brand: "Brand",
    condition: "Condition",
    availability: "Availability",
    rating: "Rating",
    reviews: "Reviews",
    specifications: "Specifications",
    description: "Description",
    features: "Features",
    relatedProducts: "Related Products",
    addToWishlist: "Add to Wishlist",
    removeFromWishlist: "Remove from Wishlist",
    share: "Share",
    searchResults: "Search Results",
    searchFor: "Search for",
    noSearchResults: "No Search Results",
    tryDifferentKeywords: "Try different keywords",
    backToHome: "Back to Home",
    filterByPrice: "Filter by Price",
    filterByCategory: "Filter by Category",
    filterByBrand: "Filter by Brand",
    filterByCondition: "Filter by Condition",
    filterByAvailability: "Filter by Availability",
    filterByRating: "Filter by Rating",
    sortByRelevance: "Sort by Relevance",
    sortByPopularity: "Sort by Popularity",
    sortByNewest: "Sort by Newest",
    sortByPriceAsc: "Sort by Price: Low to High",
    sortByPriceDesc: "Sort by Price: High to Low",
    sortByRating: "Sort by Rating",
    sortByReviews: "Sort by Reviews",
    showMore: "Show More",
    showLess: "Show Less",
    readMore: "Read More",
    readLess: "Read Less",
    viewDetails: "View Details",
    buyNow: "Buy Now",
    addedToCart: "Added to Cart",
    goToCart: "Go to Cart",
    continueShoppingBtn: "Continue Shopping",
    outOfStockMsg: "This product is currently out of stock",
    notifyMe: "Notify Me",
    notifyMeDesc: "We'll notify you when this product is back in stock",
    emailPlaceholder: "Enter your email",
    phonePlaceholder: "Enter your phone number",
    passwordPlaceholder: "Enter your password",
    searchPlaceholder: "Search for products",
    promoCodePlaceholder: "Enter promo code",
    firstNamePlaceholder: "Enter your first name",
    lastNamePlaceholder: "Enter your last name",
    addressPlaceholder: "Enter your address",
    cityPlaceholder: "Enter your city",
    postalCodePlaceholder: "Enter your postal code",
    countryPlaceholder: "Enter your country",
    commentPlaceholder: "Enter your comment",
    reviewPlaceholder: "Write your review",
    questionPlaceholder: "Ask a question",
    answerPlaceholder: "Write your answer",

    // Hero
    heroTitle: "iPhone 16 Pro Max - The Most Powerful iPhone",
    heroDescription: "With the new A19 Pro processor, improved camera system, and more storage.",
    newModel: "New Model",
    sixMonthWarranty: "6 Month Warranty",
    sixMonthPayment: "6 Month Payment",

    // Features
    qualityGuarantee: "Quality Guarantee",
    qualityDescription: "All products undergo strict quality control",
    fastDelivery: "Fast Delivery",
    deliveryDescription: "Delivery within 24 hours in Tashkent",
    easyPayment: "Easy Payment",
    paymentDescription: "Cash, card, and installment payment options",
    support: "24/7 Support",
    supportDescription: "Help with any questions",
    bonuses: "Bonuses and Promotions",
    bonusesDescription: "Bonus points for every purchase",
    authenticity: "100% Original",
    authenticityDescription: "Only original Apple products",
    whyChooseUs: "Why Choose Us",

    // Footer
    companyInfo: "Seven - the largest Apple product store in Uzbekistan. We have been providing quality products and services to our customers since 2018.",
    allRightsReserved: "All rights reserved",
    address: "Farg'ona, Sayilgoh ko'chasi 29",
    workHours: "9:00 - 21:00, daily",
    trackOrder: "Track Order",
    news: "News and Videos",
    faq: "FAQ",
    contactUs: "Contact Us",
    followUs: "Follow Us",
    subscribeToNewsletter: "Subscribe to Our Newsletter",
    subscribeDesc: "Get the latest news and special offers",
    subscribe: "Subscribe",
    yourEmail: "Your Email",
    copyright: "Copyright",
    termsAndConditions: "Terms and Conditions",
    returnPolicy: "Return Policy",
    shippingPolicy: "Shipping Policy",
    paymentMethods: "Payment Methods",
    careers: "Careers",
    blog: "Blog",
    partners: "Partners",
    affiliateProgram: "Affiliate Program",

    // Company page
    companyHistory: "Company History",
    ourMission: "Our Mission",
    ourVision: "Our Vision",
    ourTeam: "Our Team",
    ourValues: "Our Values",
    ourAchievements: "Our Achievements",
    ourPartners: "Our Partners",
    ourLocation: "Our Location",
    joinOurTeam: "Join Our Team",
    frequentlyAskedQuestions: "Frequently Asked Questions",
    question: "Question",
    answer: "Answer",

    // About Company Page
    pageTitle: "About Company",
    companyName: "Seven",
    tagline: "The most reliable and quality mobile devices and accessories store in Uzbekistan",
    aboutUs: "About Us",
    aboutDescription: "Seven Uz was established in 2020 and is one of the most reliable and quality mobile devices and accessories stores in Uzbekistan. Our main goal is to provide our customers with the highest quality products at affordable prices.",
    productsDescription: "We sell only original and quality products. All products come with a warranty. In our store, you can find the latest models of smartphones, tablets, and accessories from Apple, Samsung, Xiaomi, Huawei, and other brands.",
    happyCustomers: "Happy Customers",
    stores: "Stores",
    storesInTashkent: "Across Tashkent",
    contactDescription: "Contact us for questions and suggestions",
    addressValue: "Tashkent, Chilanzar district, 17th block, building 1",
    workingHours: "Working Hours:",
    workingHoursWeekdays: "Monday - Saturday: 9:00 - 22:00",
    workingHoursSunday: "Sunday: 10:00 - 20:00",
    socialNetworks: "Social Networks:",
    faqQuestion1: "How can I be sure that your products are original and have a warranty?",
    faqAnswer1: "All our products come from official distributors and are provided with certificates. Each product comes with a warranty card, and you can check it in our store.",
    faqQuestion2: "Is it possible to buy products with installment payments?",
    faqAnswer2: "Yes, we provide installment payment options for 3, 6, and 12 months. This requires a passport and a bank card.",
    faqQuestion3: "Is there a delivery service to other cities in Uzbekistan?",
    faqAnswer3: "Yes, we provide delivery service to all regions of Uzbekistan. Delivery time is 1-3 days.",
    faqQuestion4: "Can I return a product if I don't like it?",
    faqAnswer4: "Yes, you can return the product within 14 days if it has not been used and is in its original packaging.",
    faqQuestion5: "What payment methods are available in your store?",
    faqAnswer5: "We accept payments in cash, bank cards, through Click, Payme, and other payment systems.",
    ourStores: "Our Stores",
    storeChilanzar: "Seven Uz Chilanzar",
    storeChilanzarBranch: "Chilanzar Branch",
    storeChilanzarAddress: "Tashkent, Chilanzar district, 17th block, building 1",
    storeWorkingHours: "9:00 - 22:00 (daily)",
    viewOnMap: "View on Map",
    storeYunusabad: "Seven Uz Yunusabad",
    storeYunusabadBranch: "Yunusabad Branch",
    storeYunusabadAddress: "Tashkent, Yunusabad district, 4th block, building 12",
    storeSergeli: "Seven Uz Sergeli",
    storeSergeliBranch: "Sergeli Branch",
    storeSergeliAddress: "Tashkent, Sergeli district, 4th block, building 12",
    latestProducts: "Latest Premium Products",
    productDescription: "Apple Watch Ultra 2, the most powerful and durable Apple Watch",
    colors: "Colors:",
    color1: "Natural Titanium",
    color2: "Titanium Black",
    color3: "Titanium Orange",
    ourMissionTitle: "Our Mission",
    missionDescription: "The main mission of Seven Uz company is to provide the population of Uzbekistan with high-quality technological products at affordable prices and with installment payment options. We approach each customer individually and help them choose a product that meets their needs.",
    quality: "Quality",
    trust: "Trust",
    trustDescription: "We have earned trust over the years",
    innovation: "Innovation",
    innovationDescription: "We offer the latest technologies",
    value1: "Customer Interest - We always put customer interests first",
    value2: "Quality - We offer only the highest quality products",
    value3: "Innovation - We are always looking for new products and innovations",
    historyDescription: "Seven Uz started its activities in 2020 as a small online store. Initially, we were only selling Apple products, but later we started selling Samsung, Xiaomi, and other brands' products as well.",
    historyDescription2: "By 2022, we opened our stores in Tashkent, and today we have more than 5 stores operating. We are constantly growing and plan to open stores in other cities of Uzbekistan in the near future.",
    historyTimeline: "Seven Uz History",
    historyEvent1: "Opening of our first store (2022)",
    historyYear2020: "2020",
    historyDesc2020: "Seven Uz started its activities as an online store",
    historyYear2022: "2022",
    historyDesc2022: "Our first physical store opened in Tashkent",
    historyYear2025: "2025",
    historyDesc2025: "Plan to open more than 10 stores across Uzbekistan",
    phoneNumber: "+998 98 777 11 33",
    addressShort: "Tashkent, Chilanzar district",
    footerText: "Seven - the largest Apple product store in Uzbekistan. We have been providing quality products and services to our customers since 2018.",
    campaign: "Campaign: UNIPRO",
    siteCreator: "Site creator: Lazizbek Sheryigitov",

    // Account
    myProfile: "My Profile",
    editProfile: "Edit Profile",
    myAddresses: "My Addresses",
    myPaymentMethods: "My Payment Methods",
    myNotifications: "My Notifications",
    myReviews: "My Reviews",
    myQuestions: "My Questions",
    myWishList: "My Wish List",
    orderHistory: "Order History",
    trackMyOrder: "Track My Order",
    returns: "Returns",
    cancellations: "Cancellations",
    savedCards: "Saved Cards",
    changePassword: "Change Password",
    deleteAccount: "Delete Account",
    logoutFromAllDevices: "Logout from All Devices",
    personalInformation: "Personal Information",
    shippingInformation: "Shipping Information",
    billingInformation: "Billing Information",
    notificationSettings: "Notification Settings",
    privacySettings: "Privacy Settings",
    accountSettings: "Account Settings",

    // Checkout
    shippingAddress: "Shipping Address",
    billingAddress: "Billing Address",
    sameAsShipping: "Same as Shipping",
    paymentMethod: "Payment Method",
    orderDetails: "Order Details",
    placeOrder: "Place Order",
    orderConfirmation: "Order Confirmation",
    thankYouForYourOrder: "Thank You for Your Order",
    orderNumber: "Order Number",
    orderDate: "Order Date",
    orderStatus: "Order Status",
    paymentStatus: "Payment Status",
    shippingMethod: "Shipping Method",
    deliveryDate: "Delivery Date",
    deliveryAddress: "Delivery Address",
    billingDetails: "Billing Details",
    orderItems: "Order Items",

    // Notifications
    successfulLogin: "Successfully logged in",
    successfulRegistration: "Successfully registered",
    successfulLogout: "Successfully logged out",
    successfulPasswordReset: "Password reset successful",
    successfulPasswordChange: "Password changed successfully",
    successfulProfileUpdate: "Profile updated successfully",
    successfulAddressAdd: "Address added successfully",
    successfulAddressUpdate: "Address updated successfully",
    successfulAddressDelete: "Address deleted successfully",
    successfulCardAdd: "Card added successfully",
    successfulCardUpdate: "Card updated successfully",
    successfulCardDelete: "Card deleted successfully",
    successfulOrderPlace: "Order placed successfully",
    successfulOrderCancel: "Order cancelled successfully",
    successfulReturnRequest: "Return request submitted successfully",
    successfulSubscription: "Subscribed successfully",
    successfulUnsubscription: "Unsubscribed successfully",
    successfulContactSubmission: "Contact form submitted successfully",
    successfulReviewSubmission: "Review submitted successfully",
    successfulQuestionSubmission: "Question submitted successfully",

    // Error messages
    errorLogin: "Failed to login",
    errorRegistration: "Failed to register",
    errorPasswordReset: "Failed to reset password",
    errorPasswordChange: "Failed to change password",
    errorProfileUpdate: "Failed to update profile",
    errorAddressAdd: "Failed to add address",
    errorAddressUpdate: "Failed to update address",
    errorAddressDelete: "Failed to delete address",
    errorCardAdd: "Failed to add card",
    errorCardUpdate: "Failed to update card",
    errorCardDelete: "Failed to delete card",
    errorOrderPlace: "Failed to place order",
    errorOrderCancel: "Failed to cancel order",
    errorReturnRequest: "Failed to submit return request",
    errorSubscription: "Failed to subscribe",
    errorUnsubscription: "Failed to unsubscribe",
    errorContactSubmission: "Failed to submit contact form",
    errorReviewSubmission: "Failed to submit review",
    errorQuestionSubmission: "Failed to submit question",
    errorGeneral: "Something went wrong",

    // Time
    today: "Today",
    yesterday: "Yesterday",
    days: "days",
    hours: "hours",
    minutes: "minutes",
    seconds: "seconds",

    // Other
    yes: "Yes",
    no: "No",
    ok: "OK",
    cancel: "Cancel",
    save: "Save",
    edit: "Edit",
    delete: "Delete",
    remove: "Remove",
    update: "Update",
    create: "Create",
    submit: "Submit",
    confirm: "Confirm",
    back: "Back",
    next: "Next",
    previous: "Previous",
    finish: "Finish",
    continue: "Continue",
    loading: "Loading",
    processing: "Processing",
    sending: "Sending",
    uploading: "Uploading",
    downloading: "Downloading",
    success: "Success",
    error: "Error",
    warning: "Warning",
    info: "Info",
    view: undefined,
    writeReview: undefined,
    customerReviews: undefined,
    productFeatures: undefined,
    technicalSpecs: undefined,
    freeShipping: undefined
  },
}

interface LanguageContextType {
  language: Language
  setLanguage: (language: Language) => void
  translations: Translations
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>("uz")

  useEffect(() => {
    const savedLanguage = localStorage.getItem("language") as Language
    if (savedLanguage && ["uz", "ru", "en"].includes(savedLanguage)) {
      setLanguage(savedLanguage)
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("language", language)
  }, [language])

  return (
    <LanguageContext.Provider value={{ language, setLanguage, translations: translations[language] }}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
