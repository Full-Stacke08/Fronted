import type { Product } from "./types"
import { smartphones } from "./categories/smartphones"
import { laptops } from "./categories/laptops"
import { tablets } from "./categories/tablets"
import { headphones } from "./categories/headphones"
import { smartwatches } from "./categories/smartwatches"
import { accessories } from "./categories/accessories"
import {
  products,
  getProductsByCategory,
  getNewProducts,
  getBestsellerProducts,
  searchProducts,
  getCategoryCounts,
  categories,
} from "./categories/index"

// Re-export all the functions and data
export {
  products,
  getProductsByCategory,
  getNewProducts,
  getBestsellerProducts,
  searchProducts,
  getCategoryCounts,
  categories,
}

// Combining all products
export const allProducts: Product[] = [
  {
    id: "iphone-16-pro-max",
    name: "iPhone 16 Pro Max",
    nameUz: "iPhone 16 Pro Max",
    nameRu: "iPhone 16 Pro Max",
    price: 1299,
    oldPrice: 1399,
    image: "https://macbro.uz/cdn/shop/files/5_6dd552d5-9eb5-4a4b-bd16-b953c077fcfc_298x_crop_center.png?v=1740662797",
    category: "Smartfonlar",
    categoryUz: "Smartfonlar",
    categoryRu: "Смартфоны",
    condition: "Ideal",
    conditionUz: "Ideal",
    conditionRu: "Идеальное",
    color: "Titanium Black",
    colorUz: "Titanium Black",
    colorRu: "Титановый черный",
    description: "Apple iPhone 16 Pro Max, eng so'nggi A17 Pro protsessor, titanium korpus, 48MP kamera",
    descriptionUz: "Apple iPhone 16 Pro Max, eng so'nggi A17 Pro protsessor, titanium korpus, 48MP kamera",
    descriptionRu: "Apple iPhone 16 Pro Max, новейший процессор A17 Pro, титановый корпус, камера 48МП",
    features: [
      "A17 Pro protsessor",
      "48MP asosiy kamera",
      "Titanium korpus",
      "6.7 dyuymli Super Retina XDR displey",
      "USB-C port",
      "5G qo'llab-quvvatlash",
    ],
    featuresUz: [
      "A17 Pro protsessor",
      "48MP asosiy kamera",
      "Titanium korpus",
      "6.7 dyuymli Super Retina XDR displey",
      "USB-C port",
      "5G qo'llab-quvvatlash",
    ],
    featuresRu: [
      "Процессор A17 Pro",
      "Основная камера 48МП",
      "Титановый корпус",
      "6.7-дюймовый дисплей Super Retina XDR",
      "Порт USB-C",
      "Поддержка 5G",
    ],
    specifications: {
      "Protsessor": "A17 Pro",
      "Xotira": "256GB",
      "Batareya": "100%",
      "Korpus": "Titanium",
      "Kamera": "48MP",
      "Displey": "6.7\" Super Retina XDR",
    },
    specificationsUz: {
      "Protsessor": "A17 Pro",
      "Xotira": "256GB",
      "Batareya": "100%",
      "Korpus": "Titanium",
      "Kamera": "48MP",
      "Displey": "6.7\" Super Retina XDR",
    },
    specificationsRu: {
      "Процессор": "A17 Pro",
      "Память": "256GB",
      "Батарея": "100%",
      "Корпус": "Титановый",
      "Камера": "48МП",
      "Дисплей": "6.7\" Super Retina XDR",
    },
    isNew: true,
    isBestseller: true,
    rating: 5,
    reviews: 120,
  },
  {
    id: "macbook-pro-16",
    name: "MacBook Pro 16-inch (2025)",
    nameUz: "MacBook Pro 16-dyuym (2025)",
    nameRu: "MacBook Pro 16-дюймов (2025)",
    price: 2499,
    oldPrice: 2699,
    image: "https://macbro.uz/cdn/shop/files/2spaceblack_298x_crop_center.png?v=1700727046",
    category: "Noutbuklar",
    categoryUz: "Noutbuklar",
    categoryRu: "Ноутбуки",
    condition: "Ideal",
    conditionUz: "Ideal",
    conditionRu: "Идеальное",
    color: "Space Black",
    colorUz: "Space Black",
    colorRu: "Космический черный",
    description: "Apple MacBook Pro 16-inch (2025), eng so'nggi M3 Pro protsessor, 32GB RAM, 1TB SSD",
    descriptionUz: "Apple MacBook Pro 16-dyuym (2025), eng so'nggi M3 Pro protsessor, 32GB RAM, 1TB SSD",
    descriptionRu: "Apple MacBook Pro 16-дюймов (2025), новейший процессор M3 Pro, 32GB RAM, 1TB SSD",
    features: [
      "M3 Pro protsessor",
      "32GB RAM",
      "1TB SSD",
      "16 dyuymli Liquid Retina XDR displey",
      "18 soatlik batareya",
      "Wi-Fi 6E",
    ],
    featuresUz: [
      "M3 Pro protsessor",
      "32GB RAM",
      "1TB SSD",
      "16 dyuymli Liquid Retina XDR displey",
      "18 soatlik batareya",
      "Wi-Fi 6E",
    ],
    featuresRu: [
      "Процессор M3 Pro",
      "32GB RAM",
      "1TB SSD",
      "16-дюймовый дисплей Liquid Retina XDR",
      "18-часовая батарея",
      "Wi-Fi 6E",
    ],
    specifications: {
      "Protsessor": "M3 Pro",
      "RAM": "32GB",
      "Xotira": "1TB SSD",
      "Displey": "16\" Liquid Retina XDR",
      "Batareya": "18 soat",
      "Aloqa": "Wi-Fi 6E",
    },
    specificationsUz: {
      "Protsessor": "M3 Pro",
      "RAM": "32GB",
      "Xotira": "1TB SSD",
      "Displey": "16\" Liquid Retina XDR",
      "Batareya": "18 soat",
      "Aloqa": "Wi-Fi 6E",
    },
    specificationsRu: {
      "Процессор": "M3 Pro",
      "RAM": "32GB",
      "Память": "1TB SSD",
      "Дисплей": "16\" Liquid Retina XDR",
      "Батарея": "18 часов",
      "Связь": "Wi-Fi 6E",
    },
    isNew: true,
    isBestseller: true,
    rating: 5,
    reviews: 85,
  },
  {
    id: "apple-watch-ultra-2",
    name: "Apple Watch Ultra 2",
    nameUz: "Apple Watch Ultra 2",
    nameRu: "Apple Watch Ultra 2",
    price: 799,
    oldPrice: 899,
    image: "https://macbro.uz/cdn/shop/files/8_04d0c414-d4a0-42c2-8f9a-c4129d2a7d76_298x_crop_center.png?v=1700308518",
    category: "Aqlli soatlar",
    categoryUz: "Aqlli soatlar",
    categoryRu: "Умные часы",
    condition: "Ideal",
    conditionUz: "Ideal",
    conditionRu: "Идеальное",
    color: "Titanium",
    colorUz: "Titanium",
    colorRu: "Титановый",
    description: "Apple Watch Ultra 2, eng kuchli Apple Watch, 36 soatlik batareya, 49mm titanium korpus",
    descriptionUz: "Apple Watch Ultra 2, eng kuchli Apple Watch, 36 soatlik batareya, 49mm titanium korpus",
    descriptionRu: "Apple Watch Ultra 2, самые мощные Apple Watch, 36-часовая батарея, 49мм титановый корпус",
    features: [
      "S9 SiP protsessor",
      "36 soatlik batareya",
      "49mm titanium korpus",
      "Always-On Retina LTPO OLED",
      "GPS + Cellular",
      "100m suvga chidamli",
    ],
    featuresUz: [
      "S9 SiP protsessor",
      "36 soatlik batareya",
      "49mm titanium korpus",
      "Always-On Retina LTPO OLED",
      "GPS + Cellular",
      "100m suvga chidamli",
    ],
    featuresRu: [
      "Процессор S9 SiP",
      "36-часовая батарея",
      "49мм титановый корпус",
      "Always-On Retina LTPO OLED",
      "GPS + Cellular",
      "Водонепроницаемость до 100м",
    ],
    specifications: {
      "Protsessor": "S9 SiP",
      "Batareya": "36 soat",
      "Korpus": "49mm Titanium",
      "Displey": "Always-On Retina LTPO OLED",
      "GPS": "GPS + Cellular",
      "Suvga chidamlilik": "100m",
    },
    specificationsUz: {
      "Protsessor": "S9 SiP",
      "Batareya": "36 soat",
      "Korpus": "49mm Titanium",
      "Displey": "Always-On Retina LTPO OLED",
      "GPS": "GPS + Cellular",
      "Suvga chidamlilik": "100m",
    },
    specificationsRu: {
      "Процессор": "S9 SiP",
      "Батарея": "36 часов",
      "Корпус": "49мм Титановый",
      "Дисплей": "Always-On Retina LTPO OLED",
      "GPS": "GPS + Cellular",
      "Водонепроницаемость": "100м",
    },
    isNew: true,
    isBestseller: true,
    rating: 5,
    reviews: 65,
  },
  {
    id: "airpods-max-2",
    name: "AirPods Max 2",
    nameUz: "AirPods Max 2",
    nameRu: "AirPods Max 2",
    price: 549,
    oldPrice: 599,
    image: "https://macbro.uz/cdn/shop/files/airpods-max-2_298x_crop_center.png?v=1740662797",
    category: "Quloqchinlar",
    categoryUz: "Quloqchinlar",
    categoryRu: "Наушники",
    condition: "Ideal",
    conditionUz: "Ideal",
    conditionRu: "Идеальное",
    color: "Space Gray",
    colorUz: "Space Gray",
    colorRu: "Космический серый",
    description: "AirPods Max 2, eng yuqori sifatli audio, faol shovqinni bekor qilish, 30 soatlik batareya",
    descriptionUz: "AirPods Max 2, eng yuqori sifatli audio, faol shovqinni bekor qilish, 30 soatlik batareya",
    descriptionRu: "AirPods Max 2, высочайшее качество звука, активное шумоподавление, 30-часовая батарея",
    features: [
      "H2 protsessor",
      "Faol shovqinni bekor qilish",
      "30 soatlik batareya",
      "Spatial Audio",
      "MagSafe zaryadlash",
      "IPX4 suvga chidamli",
    ],
    featuresUz: [
      "H2 protsessor",
      "Faol shovqinni bekor qilish",
      "30 soatlik batareya",
      "Spatial Audio",
      "MagSafe zaryadlash",
      "IPX4 suvga chidamli",
    ],
    featuresRu: [
      "Процессор H2",
      "Активное шумоподавление",
      "30-часовая батарея",
      "Spatial Audio",
      "Зарядка MagSafe",
      "Водонепроницаемость IPX4",
    ],
    specifications: {
      "Protsessor": "H2",
      "Batareya": "30 soat",
      "Shovqinni bekor qilish": "Faol",
      "Audio": "Spatial Audio",
      "Zaryadlash": "MagSafe",
      "Suvga chidamlilik": "IPX4",
    },
    specificationsUz: {
      "Protsessor": "H2",
      "Batareya": "30 soat",
      "Shovqinni bekor qilish": "Faol",
      "Audio": "Spatial Audio",
      "Zaryadlash": "MagSafe",
      "Suvga chidamlilik": "IPX4",
    },
    specificationsRu: {
      "Процессор": "H2",
      "Батарея": "30 часов",
      "Шумоподавление": "Активное",
      "Аудио": "Spatial Audio",
      "Зарядка": "MagSafe",
      "Водонепроницаемость": "IPX4",
    },
    isNew: true,
    isBestseller: true,
    rating: 5,
    reviews: 45,
  },
]

export const featuredProducts = products.slice(0, 4)

// Get product by ID
export function getProductById(id: string): Product | undefined {
  const product = allProducts.find((product) => product.id === id)

  // Add multiple images if not already present
  if (product && (!product.images || product.images.length === 0)) {
    // For each product, create at least 2 images using the main image
    // This ensures we always have at least 2 views of each product
    if (product.image) {
      // Create an images array if it doesn't exist
      product.images = [
        product.image,
        // Slightly modify the URL to simulate a different view
        product.image.includes("?") ? `${product.image.split("?")[0]}?v=alternate` : `${product.image}?v=alternate`,
      ]

      // For specific product types, add more appropriate secondary images
      if (product.category === "Smartphones" || product.categoryUz === "Smartfonlar") {
        if (product.name.includes("iPhone")) {
          // Add appropriate iPhone images
          const baseImages = [
            "https://macbro.uz/cdn/shop/files/1_e261fcfe-fde9-4824-b5e9-4ace8ac1afbb_298x_crop_center.png?v=1715944211",
            "https://macbro.uz/cdn/shop/files/iphone_16_pro_max_desert_2_596x_crop_center.png?v=1747058732",
            "https://macbro.uz/cdn/shop/files/iphone_16_pro_max_desert_1_596x_crop_center.png?v=1747055140",
          ]
          product.images = [product.image, ...baseImages.filter((img) => img !== product.image).slice(0, 2)]
        }
      } else if (product.category === "Laptops" || product.categoryUz === "Noutbuklar") {
        // Add MacBook specific images
        const macbookImages = [
          "https://macbro.uz/cdn/shop/files/2spaceblack_298x_crop_center.png?v=1700727046",
          "https://macbro.uz/cdn/shop/files/1spacegray_3dff8d7e-8252-49a3-8e8f-d85901204995_298x_crop_center.png?v=1700727039",
        ]
        product.images = [product.image, ...macbookImages.filter((img) => img !== product.image).slice(0, 2)]
      } else if (product.category === "Smartwatches" || product.categoryUz === "Aqlli soatlar") {
        // Add Apple Watch specific images
        const watchImages = [
          "https://macbro.uz/cdn/shop/files/8_04d0c414-d4a0-42c2-8f9a-c4129d2a7d76_298x_crop_center.png?v=1700308518",
          "https://macbro.uz/cdn/shop/files/2_845086ad-2e6a-451e-b9ec-59b72e3bf876_298x_crop_center.png?v=1700308508",
        ]
        product.images = [product.image, ...watchImages.filter((img) => img !== product.image).slice(0, 2)]
      }
    }
  }

  return product
}

// Get related products
export function getRelatedProducts(id: string, limit = 4): Product[] {
  const product = getProductById(id)
  if (!product) return []

  // Find products in the same category
  const sameCategory = allProducts.filter(
    (p) => p.id !== id && (p.category === product.category || p.categoryId === product.categoryId),
  )

  // If there are enough products in the same category, return those
  if (sameCategory.length >= limit) {
    return sameCategory.slice(0, limit)
  }

  // Otherwise, fill in with other products
  const otherProducts = allProducts.filter(
    (p) => p.id !== id && p.category !== product.category && p.categoryId !== product.categoryId,
  )

  return [...sameCategory, ...otherProducts].slice(0, limit)
}

export const categoryNames: Record<string, string> = {
  smartphones: "Smartphones",
  laptops: "Laptops",
  tablets: "Tablets",
  headphones: "Headphones",
  smartwatches: "Smartwatches",
  accessories: "Accessories",
}

// Specific category getters
export { smartphones, laptops, tablets, headphones, smartwatches, accessories }
