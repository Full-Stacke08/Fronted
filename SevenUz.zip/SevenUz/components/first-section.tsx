"use client"

import { useState } from "react"
import Image from "next/image"
import { motion, AnimatePresence } from "framer-motion"
import { ShoppingCart, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "./cart-provider"
import { useToast } from "@/hooks/use-toast"
import { useLanguage } from "./language-provider"
import { featuredProducts } from "@/lib/product-data"

export default function FirstSection() {
  const { addToCart } = useCart()
  const { toast } = useToast()
  const { translations } = useLanguage()
  const [hoveredProduct, setHoveredProduct] = useState<string | null>(null)
  const [addedProducts, setAddedProducts] = useState<{ [key: string]: boolean }>({})

  const handleAddToCart = (product: (typeof featuredProducts)[0]) => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      quantity: 1,
      image: product.image,
    })

    // Show animation
    setAddedProducts((prev) => ({ ...prev, [product.id]: true }))

    // Reset after animation
    setTimeout(() => {
      setAddedProducts((prev) => ({ ...prev, [product.id]: false }))
    }, 1500)

    // Show toast notification
    toast({
      title: translations.addToCart,
      description: `${product.name} ${translations.added.toLowerCase()}`,
      duration: 3000,
    })
  }

  return (
    <section className="py-12 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{translations.featured}</h2>
          <Button variant="link" className="text-red-600 dark:text-red-400">
            {translations.viewAll}
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <motion.div
              key={product.id}
              className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300"
              whileHover={{ y: -5 }}
              onMouseEnter={() => setHoveredProduct(product.id)}
              onMouseLeave={() => setHoveredProduct(null)}
            >
              <div className="relative h-48 sm:h-64 bg-gray-100 dark:bg-gray-700">
                <Image
                  src={product.image || "https://via.placeholder.com/300"}
                  alt={product.name}
                  fill
                  className="object-cover w-full h-full"
                />
              </div>

              <div className="p-4">
                <div className="flex flex-wrap gap-1 mb-2">
                  <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300">
                    {product.memory}
                  </span>
                  <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300">
                    {product.batteryHealth}
                  </span>
                  <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300">
                    {product.condition === "Ideal" ? translations.ideal : translations.good}
                  </span>
                </div>

                <h3 className="font-bold text-gray-900 dark:text-white mb-1">{product.name}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-3 line-clamp-2">{product.description}</p>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-lg text-red-600 dark:text-red-400">${product.price}</span>
                  <AnimatePresence>
                    {addedProducts[product.id] ? (
                      <motion.div
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.8, opacity: 0 }}
                        className="bg-green-600 text-white rounded-md px-3 py-1 flex items-center"
                      >
                        <Check className="h-4 w-4 mr-1" />
                        <span className="text-xs">{translations.added}</span>
                      </motion.div>
                    ) : (
                      <motion.div
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.8, opacity: 0 }}
                      >
                        <Button
                          size="sm"
                          onClick={() => handleAddToCart(product)}
                          className="bg-red-600 hover:bg-red-700 text-white"
                        >
                          <ShoppingCart className="h-4 w-4 mr-1" />
                          {translations.add}
                        </Button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
