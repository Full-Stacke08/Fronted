"use client"

import { useRef, useEffect, useState } from "react"
import { motion, useAnimation, useInView, AnimatePresence } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { useLanguage } from "./language-provider"

export default function Hero() {
  const controls = useAnimation()
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true })
  const { translations } = useLanguage()

  const iPhoneImages = [
    "https://macbro.uz/cdn/shop/files/iphone_16_pro_max_desert_2_596x_crop_center.png?v=1747058732",
    "https://macbro.uz/cdn/shop/files/88_710926ce-588a-431d-876d-fff7afa7001a_298x_crop_center.png?v=1747049099",
    "https://macbro.uz/cdn/shop/files/12_5bad20a7-d522-4c92-be97-690fc3830d3d_345x_crop_center.png?v=1726467199",
    "https://macbro.uz/cdn/shop/files/2_0e1f2c7e-b6b5-44ce-8d9f-41ad785b28d9_345x_crop_center.png?v=1740662797",
  ]

  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [isAnimating, setIsAnimating] = useState(false)

  useEffect(() => {
    if (isInView) {
      controls.start("visible")
    }
  }, [controls, isInView])

  useEffect(() => {
    const interval = setInterval(() => {
      setIsAnimating(true)
      setTimeout(() => {
        setCurrentImageIndex((prevIndex) => (prevIndex + 1) % iPhoneImages.length)
        setIsAnimating(false)
      }, 500)
    }, 3000)

    return () => clearInterval(interval)
  }, [iPhoneImages.length])

  return (
    <section
      className="relative text-white overflow-x-hidden w-full max-w-screen overflow-hidden min-h-screen"
      ref={ref}
    >
      {/* Responsive Background Video with Overlay */}
      <div className="absolute inset-0 z-0">
  <iframe
    className="w-full h-full"
    src="https://www.youtube.com/embed/eDqfg_LexCQ?start=90&autoplay=1&mute=1&controls=0&loop=1&playlist=eDqfg_LexCQ"
    frameBorder="0"
    allow="autoplay; fullscreen; picture-in-picture"
    allowFullScreen
  />
  <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-black/50" />
</div>


      {/* Hero content */}
      <div className="container mx-auto px-4 py-16 md:py-24 lg:py-32 relative">
        <div className="flex flex-col md:flex-row items-center">
          {/* Left Text Section */}
          <motion.div
            initial="hidden"
            animate={controls}
            variants={{
              hidden: { opacity: 0, x: -50 },
              visible: {
                opacity: 1,
                x: 0,
                transition: {
                  duration: 0.8,
                  ease: "easeOut",
                },
              },
            }}
            className="w-full md:w-1/2 text-center md:text-left mb-8 md:mb-0"
          >
            <h1 className="text-4xl lg:text-5xl xl:text-6xl font-bold leading-tight mb-4">
              {translations.heroTitle}
            </h1>
            <p className="text-lg lg:text-xl opacity-90 mb-8 max-w-lg mx-auto md:mx-0">
              {translations.heroDescription}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <Button
                asChild
                size="lg"
                className="bg-red-600 hover:bg-red-700 text-white"
              >
                <Link href="/product/iphone-16-pro-max">
                  {translations.moreDetails}
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="bg-white text-gray-900 border-white hover:bg-white/90 dark:text-white dark:bg-transparent dark:hover:bg-white/10"
              >
                <Link href="/category/smartphones">
                  {translations.shopNow}
                </Link>
              </Button>
            </div>
          </motion.div>

          {/* Right iPhone Carousel */}
          <motion.div
            initial="hidden"
            animate={controls}
            variants={{
              hidden: { opacity: 0, y: 50 },
              visible: {
                opacity: 1,
                y: 0,
                transition: {
                  duration: 0.8,
                  delay: 0.3,
                  ease: "easeOut",
                },
              },
            }}
            className="w-full md:w-1/2 relative"
          >
            <div className="relative w-full h-[400px] md:h-[500px] mx-auto max-w-[600px]">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentImageIndex}
                  initial={{ y: -100, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: 100, opacity: 0 }}
                  transition={{ duration: 0.5, ease: "easeInOut" }}
                  className="absolute inset-0"
                >
                  <Image
                    src={iPhoneImages[currentImageIndex] || "/placeholder.svg"}
                    alt={`iPhone 16 Pro Max ${currentImageIndex + 1}`}
                    fill
                    className="object-contain"
                    priority={currentImageIndex === 0}
                  />
                </motion.div>
              </AnimatePresence>

              {/* Image indicators */}
              <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-2">
                {iPhoneImages.map((_, index) => (
                  <button
                    key={index}
                    className={`w-2 h-2 rounded-full transition-all duration-300 ${
                      currentImageIndex === index
                        ? "bg-red-600 w-4"
                        : "bg-white/50"
                    }`}
                    onClick={() => {
                      setIsAnimating(true)
                      setTimeout(() => {
                        setCurrentImageIndex(index)
                        setIsAnimating(false)
                      }, 500)
                    }}
                    aria-label={`View iPhone image ${index + 1}`}
                  />
                ))}
              </div>

              {/* Yangi model */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{
                  opacity: 1,
                  scale: 1,
                  transition: { delay: 0.8, duration: 0.5 },
                }}
                className="absolute top-10 right-2 sm:right-6 md:right-10 lg:-right-10 bg-white text-gray-900 rounded-full px-4 py-2 shadow-lg z-10"
              >
                <p className="text-sm font-bold">
                  {translations.newModel}
                </p>
              </motion.div>

              {/* 6 oy kafolat */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{
                  opacity: 1,
                  scale: 1,
                  transition: { delay: 1, duration: 0.5 },
                }}
                className="absolute bottom-20 left-2 sm:left-6 md:left-10 lg:-left-10 bg-red-600 text-white rounded-full px-4 py-2 shadow-lg z-10"
              >
                <p className="text-sm font-bold">
                  {translations.sixMonthWarranty}
                </p>
              </motion.div>

              {/* 6 oy to'lov */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{
                  opacity: 1,
                  scale: 1,
                  transition: { delay: 1.2, duration: 0.5 },
                }}
                className="absolute bottom-40 right-2 sm:right-6 md:right-10 lg:-right-8 bg-white text-gray-900 rounded-full px-4 py-2 shadow-lg z-10"
              >
                <p className="text-sm font-bold">
                  {translations.sixMonthPayment}
                </p>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
