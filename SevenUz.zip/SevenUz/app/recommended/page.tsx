"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { ShoppingCart, Star, Filter, ChevronDown, ChevronUp, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useCart } from "@/components/cart-provider"
import { useToast } from "@/hooks/use-toast"

// Sample recommended products data
const recommendedProducts = [
  {
    id: "iphone-15-pro-max",
    name: "iPhone 15 Pro Max",
    price: 1299,
    memory: "256GB",
    color: "Titanium",
    condition: "Ideal",
    batteryHealth: "100%",
    rating: 5,
    image: "https://avatars.mds.yandex.net/i?id=6da5adb4e8878ea753c03744d96e04ba8447cb47-5887708-images-thumbs&n=13",
    description: "Apple iPhone 15 Pro Max, eng so'nggi A17 Pro protsessor, titanium korpus, 48MP kamera",
    category: "premium",
  },
  {
    id: "iphone-15-pro",
    name: "iPhone 15 Pro",
    price: 999,
    memory: "128GB",
    color: "Natural",
    condition: "Ideal",
    batteryHealth: "100%",
    rating: 5,
    image: "https://avatars.mds.yandex.net/i?id=6da5adb4e8878ea753c03744d96e04ba8447cb47-5887708-images-thumbs&n=13",
    description: "Apple iPhone 15 Pro, A17 Pro protsessor, titanium korpus, 48MP kamera",
    category: "premium",
  },
  {
    id: "iphone-15",
    name: "iPhone 15",
    price: 799,
    memory: "128GB",
    color: "Pink",
    condition: "Ideal",
    batteryHealth: "100%",
    rating: 4.5,
    image: "https://avatars.mds.yandex.net/i?id=6da5adb4e8878ea753c03744d96e04ba8447cb47-5887708-images-thumbs&n=13",
    description: "Apple iPhone 15, A16 Bionic protsessor, Dynamic Island, 48MP kamera",
    category: "new",
  },
  {
    id: "iphone-14-pro-max",
    name: "iPhone 14 Pro Max",
    price: 899,
    memory: "256GB",
    color: "Deep Purple",
    condition: "Yaxshi",
    batteryHealth: "92%",
    rating: 4.5,
    image: "https://avatars.mds.yandex.net/i?id=6da5adb4e8878ea753c03744d96e04ba8447cb47-5887708-images-thumbs&n=13",
    description: "Apple iPhone 14 Pro Max, A16 Bionic protsessor, Dynamic Island, 48MP kamera",
    category: "popular",
  },
  {
    id: "iphone-14-pro",
    name: "iPhone 14 Pro",
    price: 799,
    memory: "128GB",
    color: "Space Black",
    condition: "Yaxshi",
    batteryHealth: "94%",
    rating: 4.5,
    image: "https://avatars.mds.yandex.net/i?id=6da5adb4e8878ea753c03744d96e04ba8447cb47-5887708-images-thumbs&n=13",
    description: "Apple iPhone 14 Pro, A16 Bionic protsessor, Dynamic Island, 48MP kamera",
    category: "popular",
  },
  {
    id: "iphone-14",
    name: "iPhone 14",
    price: 599,
    memory: "128GB",
    color: "Blue",
    condition: "Yaxshi",
    batteryHealth: "89%",
    rating: 4,
    image: "https://avatars.mds.yandex.net/i?id=6da5adb4e8878ea753c03744d96e04ba8447cb47-5887708-images-thumbs&n=13",
    description: "Apple iPhone 14, A15 Bionic protsessor, yangilangan kamera tizimi",
    category: "popular",
  },
  {
    id: "iphone-13-pro-max",
    name: "iPhone 13 Pro Max",
    price: 699,
    memory: "256GB",
    color: "Sierra Blue",
    condition: "Yaxshi",
    batteryHealth: "87%",
    rating: 4,
    image: "https://avatars.mds.yandex.net/i?id=6da5adb4e8878ea753c03744d96e04ba8447cb47-5887708-images-thumbs&n=13",
    description: "Apple iPhone 13 Pro Max, A15 Bionic protsessor, ProMotion displey, 3x optik zum",
    category: "sale",
  },
  {
    id: "iphone-13-pro",
    name: "iPhone 13 Pro",
    price: 599,
    memory: "128GB",
    color: "Graphite",
    condition: "Yaxshi",
    batteryHealth: "88%",
    rating: 4,
    image: "https://avatars.mds.yandex.net/i?id=6da5adb4e8878ea753c03744d96e04ba8447cb47-5887708-images-thumbs&n=13",
    description: "Apple iPhone 13 Pro, A15 Bionic protsessor, ProMotion displey, 3x optik zum",
    category: "sale",
  },
  {
    id: "iphone-13",
    name: "iPhone 13",
    price: 499,
    memory: "128GB",
    color: "Midnight",
    condition: "Yaxshi",
    batteryHealth: "90%",
    rating: 4,
    image: "https://avatars.mds.yandex.net/i?id=6da5adb4e8878ea753c03744d96e04ba8447cb47-5887708-images-thumbs&n=13",
    description: "Apple iPhone 13, A15 Bionic protsessor, yangilangan kamera tizimi",
    category: "sale",
  },
  {
    id: "iphone-12-pro-max",
    name: "iPhone 12 Pro Max",
    price: 599,
    memory: "256GB",
    color: "Pacific Blue",
    condition: "Yaxshi",
    batteryHealth: "85%",
    rating: 4,
    image: "https://avatars.mds.yandex.net/i?id=6da5adb4e8878ea753c03744d96e04ba8447cb47-5887708-images-thumbs&n=13",
    description: "Apple iPhone 12 Pro Max, A14 Bionic protsessor, LiDAR skaner",
    category: "sale",
  },
  {
    id: "airpods-pro-2",
    name: "AirPods Pro 2",
    price: 249,
    color: "White",
    condition: "Ideal",
    rating: 5,
    image: "https://avatars.mds.yandex.net/i?id=6da5adb4e8878ea753c03744d96e04ba8447cb47-5887708-images-thumbs&n=13",
    description: "Apple AirPods Pro 2, aktiv shovqinni yo'q qilish, H2 chip",
    category: "new",
  },
  {
    id: "apple-watch-ultra-2",
    name: "Apple Watch Ultra 2",
    price: 799,
    color: "Titanium",
    condition: "Ideal",
    rating: 5,
    image: "https://avatars.mds.yandex.net/i?id=6da5adb4e8878ea753c03744d96e04ba8447cb47-5887708-images-thumbs&n=13",
    description: "Apple Watch Ultra 2, eng kuchli va chidamli Apple Watch",
    category: "premium",
  },
]

export default function RecommendedProductsPage() {
  const { addToCart } = useCart()
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("all")
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 1500])
  const [selectedMemories, setSelectedMemories] = useState<string[]>([])
  const [selectedColors, setSelectedColors] = useState<string[]>([])
  const [showFilters, setShowFilters] = useState(false)
  const [sortBy, setSortBy] = useState<string>("price-asc")
  const [filteredProducts, setFilteredProducts] = useState(recommendedProducts)
  const [addedProducts, setAddedProducts] = useState<{ [key: string]: boolean }>({})

  // Get unique memories and colors
  const memories = [...new Set(recommendedProducts.filter((p) => p.memory).map((p) => p.memory))]
  const colors = [...new Set(recommendedProducts.filter((p) => p.color).map((p) => p.color))]

  // Filter and sort products based on selected filters
  useEffect(() => {
    let filtered = [...recommendedProducts]

    // Filter by category tab
    if (activeTab !== "all") {
      filtered = filtered.filter((product) => product.category === activeTab)
    }

    // Filter by price
    filtered = filtered.filter((product) => product.price >= priceRange[0] && product.price <= priceRange[1])

    // Filter by memory
    if (selectedMemories.length > 0) {
      filtered = filtered.filter((product) => product.memory && selectedMemories.includes(product.memory))
    }

    // Filter by color
    if (selectedColors.length > 0) {
      filtered = filtered.filter((product) => product.color && selectedColors.includes(product.color))
    }

    // Sort products
    if (sortBy === "price-asc") {
      filtered.sort((a, b) => a.price - b.price)
    } else if (sortBy === "price-desc") {
      filtered.sort((a, b) => b.price - a.price)
    } else if (sortBy === "name-asc") {
      filtered.sort((a, b) => a.name.localeCompare(b.name))
    } else if (sortBy === "name-desc") {
      filtered.sort((a, b) => b.name.localeCompare(a.name))
    } else if (sortBy === "rating-desc") {
      filtered.sort((a, b) => (b.rating || 0) - (a.rating || 0))
    }

    setFilteredProducts(filtered)
  }, [activeTab, priceRange, selectedMemories, selectedColors, sortBy])

  // Toggle memory selection
  const toggleMemory = (memory: string) => {
    setSelectedMemories((prev) => (prev.includes(memory) ? prev.filter((m) => m !== memory) : [...prev, memory]))
  }

  // Toggle color selection
  const toggleColor = (color: string) => {
    setSelectedColors((prev) => (prev.includes(color) ? prev.filter((c) => c !== color) : [...prev, color]))
  }

  // Handle add to cart
  const handleAddToCart = (product: any) => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      quantity: 1,
      image: product.image,
    })

    // Show animation
    setAddedProducts((prev) => ({ ...prev, [product.id]: true }))

    // Reset after animation
    setTimeout(() => {
      setAddedProducts((prev) => ({ ...prev, [product.id]: false }))
    }, 1500)

    // Show toast notification
    toast({
      title: "Mahsulot savatga qo'shildi",
      description: `${product.name} savatga qo'shildi`,
      duration: 3000,
    })
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pb-12">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-red-600 to-red-800 text-white">
        <div className="container mx-auto px-4 py-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="text-3xl md:text-4xl font-bold mb-4">Tavsiya etilgan mahsulotlar</h1>
            <p className="text-lg md:text-xl max-w-2xl mx-auto">
              Seven Uz tomonidan maxsus tanlangan eng zo'r mahsulotlar. Sifat va narx nisbati eng yaxshi bo'lgan
              mahsulotlar.
            </p>
          </motion.div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Category Tabs */}
        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <TabsList className="bg-white dark:bg-gray-800 p-1 rounded-lg">
              <TabsTrigger value="all" className="rounded-md">
                Barchasi
              </TabsTrigger>
              <TabsTrigger value="new" className="rounded-md">
                Yangi
              </TabsTrigger>
              <TabsTrigger value="popular" className="rounded-md">
                Ommabop
              </TabsTrigger>
              <TabsTrigger value="premium" className="rounded-md">
                Premium
              </TabsTrigger>
              <TabsTrigger value="sale" className="rounded-md">
                Chegirma
              </TabsTrigger>
            </TabsList>

            {/* Mobile Filter Toggle */}
            <div className="md:hidden">
              <Button
                variant="outline"
                size="sm"
                className="flex items-center"
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter className="h-4 w-4 mr-2" />
                <span>Filtrlar</span>
                {showFilters ? <ChevronUp className="h-4 w-4 ml-2" /> : <ChevronDown className="h-4 w-4 ml-2" />}
              </Button>
            </div>
          </div>

          <div className="flex flex-col md:flex-row gap-6">
            {/* Filters Sidebar */}
            <aside className={`md:w-1/4 lg:w-1/5 ${showFilters ? "block" : "hidden"} md:block`}>
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 sticky top-4">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">Filtrlar</h2>

                {/* Sort By */}
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Saralash</h3>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="w-full p-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-md text-sm text-gray-800 dark:text-gray-200"
                  >
                    <option value="price-asc">Narx: Arzondan qimmatga</option>
                    <option value="price-desc">Narx: Qimmatdan arzon</option>
                    <option value="name-asc">Nom: A-Z</option>
                    <option value="name-desc">Nom: Z-A</option>
                    <option value="rating-desc">Reyting: Yuqoridan pastga</option>
                  </select>
                </div>

                {/* Price Range Filter */}
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Narx oralig'i</h3>
                  <Slider
                    defaultValue={[0, 1500]}
                    max={1500}
                    step={50}
                    value={priceRange}
                    onValueChange={(value) => setPriceRange(value as [number, number])}
                    className="mb-2"
                  />
                  <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400">
                    <span>${priceRange[0]}</span>
                    <span>${priceRange[1]}</span>
                  </div>
                </div>

                {/* Memory Filter */}
                {memories.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Xotira</h3>
                    <div className="space-y-2">
                      {memories.map((memory) => (
                        <div key={memory} className="flex items-center">
                          <Checkbox
                            id={`memory-${memory}`}
                            checked={selectedMemories.includes(memory || "")}
                            onCheckedChange={() => toggleMemory(memory || "")}
                          />
                          <label
                            htmlFor={`memory-${memory}`}
                            className="ml-2 text-sm text-gray-600 dark:text-gray-400 cursor-pointer"
                          >
                            {memory}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Color Filter */}
                {colors.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Rang</h3>
                    <div className="space-y-2">
                      {colors.map((color) => (
                        <div key={color} className="flex items-center">
                          <Checkbox
                            id={`color-${color}`}
                            checked={selectedColors.includes(color)}
                            onCheckedChange={() => toggleColor(color)}
                          />
                          <label
                            htmlFor={`color-${color}`}
                            className="ml-2 text-sm text-gray-600 dark:text-gray-400 cursor-pointer"
                          >
                            {color}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Reset Filters */}
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={() => {
                    setPriceRange([0, 1500])
                    setSelectedMemories([])
                    setSelectedColors([])
                    setSortBy("price-asc")
                  }}
                >
                  Filtrlarni tozalash
                </Button>
              </div>
            </aside>

            {/* Products Grid */}
            <div className="md:w-3/4 lg:w-4/5">
              <TabsContent value="all" className="mt-0">
                <ProductGrid
                  products={filteredProducts}
                  handleAddToCart={handleAddToCart}
                  addedProducts={addedProducts}
                />
              </TabsContent>
              <TabsContent value="new" className="mt-0">
                <ProductGrid
                  products={filteredProducts}
                  handleAddToCart={handleAddToCart}
                  addedProducts={addedProducts}
                />
              </TabsContent>
              <TabsContent value="popular" className="mt-0">
                <ProductGrid
                  products={filteredProducts}
                  handleAddToCart={handleAddToCart}
                  addedProducts={addedProducts}
                />
              </TabsContent>
              <TabsContent value="premium" className="mt-0">
                <ProductGrid
                  products={filteredProducts}
                  handleAddToCart={handleAddToCart}
                  addedProducts={addedProducts}
                />
              </TabsContent>
              <TabsContent value="sale" className="mt-0">
                <ProductGrid
                  products={filteredProducts}
                  handleAddToCart={handleAddToCart}
                  addedProducts={addedProducts}
                />
              </TabsContent>
            </div>
          </div>
        </Tabs>
      </div>
    </div>
  )
}

interface ProductGridProps {
  products: any[]
  handleAddToCart: (product: any) => void
  addedProducts: { [key: string]: boolean }
}

function ProductGrid({ products, handleAddToCart, addedProducts }: ProductGridProps) {
  return (
    <>
      {products.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {products.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              whileHover={{ y: -5 }}
              className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all duration-300"
            >
              <Link href={`/product/${product.id}`} className="block">
                <div className="relative h-48 bg-gray-100 dark:bg-gray-700">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    fill
                    className="object-cover w-full h-full"
                  />
                  {product.category === "sale" && (
                    <div className="absolute top-2 right-2 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded">
                      Chegirma
                    </div>
                  )}
                  {product.category === "new" && (
                    <div className="absolute top-2 right-2 bg-green-600 text-white text-xs font-bold px-2 py-1 rounded">
                      Yangi
                    </div>
                  )}
                </div>
              </Link>

              <div className="p-4">
                <div className="flex items-center mb-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-3 w-3 ${
                        i < Math.floor(product.rating || 0)
                          ? "text-yellow-400 fill-current"
                          : "text-gray-300 dark:text-gray-600"
                      }`}
                    />
                  ))}
                  <span className="text-xs text-gray-600 dark:text-gray-400 ml-1">{product.rating}</span>
                </div>

                <Link href={`/product/${product.id}`} className="block">
                  <h3 className="font-medium text-gray-900 dark:text-white mb-1 hover:text-red-600 dark:hover:text-red-400 transition-colors">
                    {product.name}
                  </h3>
                </Link>

                <p className="text-xs text-gray-600 dark:text-gray-400 mb-2 line-clamp-2">{product.description}</p>

                <div className="flex flex-wrap gap-1 mb-3">
                  {product.memory && (
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300">
                      {product.memory}
                    </span>
                  )}
                  {product.batteryHealth && (
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300">
                      {product.batteryHealth}
                    </span>
                  )}
                  {product.condition && (
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300">
                      {product.condition}
                    </span>
                  )}
                </div>

                <div className="flex items-center justify-between">
                  <span className="font-bold text-lg text-red-600 dark:text-red-400">${product.price}</span>
                  {addedProducts[product.id] ? (
                    <motion.div
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="bg-green-600 text-white rounded-md px-3 py-1 flex items-center"
                    >
                      <Check className="h-4 w-4 mr-1" />
                      <span className="text-xs">Qo'shildi</span>
                    </motion.div>
                  ) : (
                    <Button
                      size="sm"
                      onClick={() => handleAddToCart(product)}
                      className="bg-red-600 hover:bg-red-700 text-white"
                    >
                      <ShoppingCart className="h-4 w-4 mr-1" />
                      Savatga
                    </Button>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="bg-white dark:bg-gray-800 rounded-lg p-8 text-center">
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Mahsulotlar topilmadi</h3>
          <p className="text-gray-600 dark:text-gray-400">Boshqa filtrlarni tanlashga harakat qiling.</p>
        </div>
      )}
    </>
  )
}
