import type { Product, Category } from "../types"
import { smartphones } from "./smartphones"
import { laptops } from "./laptops"
import { tablets } from "./tablets"
import { headphones } from "./headphones"
import { smartwatches } from "./smartwatches"
import { accessories } from "./accessories"

// Kategoriyalar ma'lumotlari
export const categories: Category[] = [
  {
    id: "smartphones",
    name: "Smartphones",
    nameUz: "Smartfonlar",
    nameRu: "Смартфоны",
    slug: "smartphones",
    image: "https://macbro.uz/cdn/shop/files/store-card-13-iphone-nav-202309_GEO_US_407x_crop_center.png?v=1721281629",
  },
  {
    id: "laptops",
    name: "Laptops",
    nameUz: "Noutbuklar",
    nameRu: "Ноутбуки",
    slug: "laptops",
    image: "https://macbro.uz/cdn/shop/files/store-card-13-mac-nav-202310_407x_crop_center.png?v=1721281685",
  },
  {
    id: "tablets",
    name: "Tablets",
    nameUz: "Planshetlar",
    nameRu: "Планшеты",
    slug: "tablets",
    image: "https://macbro.uz/cdn/shop/files/store-card-13-ipad-nav-202405_1_407x_crop_center.png?v=1721288180",
  },
  {
    id: "headphones",
    name: "Headphones",
    nameUz: "Quloqchinlar",
    nameRu: "Наушники",
    slug: "headphones",
    image: "https://macbro.uz/cdn/shop/files/store-card-13-airpods-nav-202209_407x_crop_center.png?v=1721281919",
  },
  {
    id: "smartwatches",
    name: "Smartwatches",
    nameUz: "Aqlli soatlar",
    nameRu: "Умные часы",
    slug: "smartwatches",
    image: "https://macbro.uz/cdn/shop/files/store-card-13-watch-nav-202309_407x_crop_center.png?v=1721281811",
  },
  {
    id: "accessories",
    name: "Accessories",
    nameUz: "Aksessuarlar",
    nameRu: "Аксессуары",
    slug: "accessories",
    image: "https://macbro.uz/cdn/shop/files/2_1668c985-fb05-4700-93c0-5573bc92210d_298x_crop_center.png?v=1701092143",
  },
]

// Barcha mahsulotlarni birlashtirish
export const products: Product[] = [
  ...smartphones,
  ...laptops,
  ...tablets,
  ...headphones,
  ...smartwatches,
  ...accessories,
]

// Kategoriya bo'yicha mahsulotlarni olish
export function getProductsByCategory(categorySlug: string): Product[] {
  // Kategoriya nomini slug bo'yicha topish
  const category = categories.find((cat) => cat.slug === categorySlug || cat.id === categorySlug)

  if (!category) {
    console.warn(`Category not found for slug: ${categorySlug}`)
    return []
  }

  // Kategoriya nomi bo'yicha mahsulotlarni filtrlash
  return products.filter((product) => {
    const productCategory = product.category?.toLowerCase()
    const productCategoryUz = product.categoryUz?.toLowerCase()
    const categoryName = category.name.toLowerCase()
    const categoryNameUz = category.nameUz?.toLowerCase()
    const categorySlugLower = category.slug.toLowerCase()

    return (
      productCategory === categoryName ||
      productCategory === categorySlugLower ||
      productCategoryUz === categoryNameUz ||
      productCategoryUz === categorySlugLower ||
      product.categoryId === category.id
    )
  })
}

// ID bo'yicha mahsulotni olish
export function getProductById(id: string): Product | undefined {
  return products.find((product) => product.id === id)
}

// Yangi mahsulotlarni olish
export function getNewProducts(limit = 8): Product[] {
  return products
    .filter((product) => product.isNew)
    .sort((a, b) => (b.rating || 0) - (a.rating || 0))
    .slice(0, limit)
}

// Eng ko'p sotilgan mahsulotlarni olish
export function getBestsellerProducts(limit = 8): Product[] {
  return products
    .filter((product) => product.isBestseller)
    .sort((a, b) => (b.rating || 0) - (a.rating || 0))
    .slice(0, limit)
}

// Qidiruv funksiyasi
export function searchProducts(query: string): Product[] {
  const searchTerm = query.toLowerCase()
  return products.filter(
    (product) =>
      product.name.toLowerCase().includes(searchTerm) ||
      product.nameUz?.toLowerCase().includes(searchTerm) ||
      product.description?.toLowerCase().includes(searchTerm) ||
      product.descriptionUz?.toLowerCase().includes(searchTerm) ||
      product.category.toLowerCase().includes(searchTerm) ||
      product.categoryUz?.toLowerCase().includes(searchTerm),
  )
}

// Kategoriyalar bo'yicha mahsulotlar sonini olish
export function getCategoryCounts(): Record<string, number> {
  const counts: Record<string, number> = {}

  categories.forEach((category) => {
    counts[category.slug] = getProductsByCategory(category.slug).length
  })

  return counts
}

// Kategoriya bo'yicha mahsulotlarni eksport qilish
export { smartphones, laptops, tablets, headphones, smartwatches, accessories }
