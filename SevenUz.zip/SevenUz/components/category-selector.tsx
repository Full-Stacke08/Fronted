"use client"

import { useRef, useEffect } from "react"
import Link from "next/link"
import { motion, useAnimation, useInView } from "framer-motion"
import { useLanguage } from "./language-provider"
import { Cable, Headphones, Laptop, Smartphone, Tablet, Watch } from "lucide-react"

export default function CategorySelector() {
  const controls = useAnimation()
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.2 })
  const { translations } = useLanguage()

  useEffect(() => {
    if (isInView) {
      controls.start("visible")
    }
  }, [controls, isInView])

  const categories = [
    {
      id: "smartphones",
      name: translations.smartphones,
      icon: <Smartphone className="h-6 w-6 text-red-600 dark:text-red-400" />,
    },
    {
      id: "tablets",
      name: translations.tablets,
      icon: <Tablet className="h-6 w-6 text-red-600 dark:text-red-400" />,
    },
    {
      id: "laptops",
      name: translations.laptops,
      icon: <Laptop className="h-6 w-6 text-red-600 dark:text-red-400" />,
    },
    {
      id: "headphones",
      name: translations.headphones,
      icon: <Headphones className="h-6 w-6 text-red-600 dark:text-red-400" />,
    },
    {
      id: "smartwatches",
      name: translations.smartwatches,
      icon: <Watch className="h-6 w-6 text-red-600 dark:text-red-400" />,
    },
    {
      id: "accessories",
      name: translations.accessories,
      icon: <Cable className="h-6 w-6 text-red-600 dark:text-red-400" />,
    },
  ]

  return (
    <section className="py-12 bg-white dark:bg-gray-800" ref={ref}>
      <div className="container mx-auto px-4">
        <motion.div
          initial="hidden"
          animate={controls}
          variants={{
            hidden: { opacity: 0, y: 20 },
            visible: {
              opacity: 1,
              y: 0,
              transition: {
                duration: 0.6,
                ease: "easeOut",
              },
            },
          }}
        >
          <h2 className="text-2xl font-bold text-center mb-8 text-gray-900 dark:text-white">
            {translations.categories}
          </h2>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
            {categories.map((category, index) => (
              <motion.div
                key={category.id}
                initial={{ opacity: 0, y: 20 }}
                animate={controls}
                variants={{
                  visible: {
                    opacity: 1,
                    y: 0,
                    transition: {
                      delay: index * 0.1,
                      duration: 0.5,
                    },
                  },
                }}
              >
                <Link href={`/category/${category.id}`}>
                  <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4 text-center hover:shadow-md transition-all duration-200 hover:-translate-y-1">
                    <div className="w-16 h-16 mx-auto bg-gray-100 dark:bg-gray-700 rounded-full mb-3 flex items-center justify-center overflow-hidden">
                      {category.icon}
                    </div>
                    <h3 className="font-medium text-gray-900 dark:text-white text-sm">{category.name}</h3>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}
