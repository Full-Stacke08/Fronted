import type React from "react"
import { EyeIcon } from "lucide-react"

export function Eye(props: React.ComponentProps<typeof EyeIcon>) {
  return <EyeIcon {...props} />
}
