import type { Product } from "../types"

export const smartwatches: Product[] = [
  {
    id: "apple-watch-ultra-2",
    name: "Apple Watch Ultra 2",
    description: "The most rugged and capable Apple Watch with precision dual-frequency GPS and up to 36 hours of battery life.",
    price: 799,
    category: "smartwatches",
    image: "/images/products/apple-watch-ultra-2.png",
    rating: 4.9,
    stock: 50,
    features: ["49mm titanium case", "Always-On Retina display", "Action button", "Up to 36 hours of battery life", "Water resistant to 100m"],
    colors: ["Natural Titanium"],
    storage: [],
    isNew: true,
    isFeatured: true,
\
