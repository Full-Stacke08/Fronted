"use client"

import { useEffect, useRef } from "react"
import { motion, useAnimation, useInView } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Instagram } from "lucide-react"
import Link from "next/link"
import { useLanguage } from "./language-provider"

const instagramPosts = [
  {
    id: "1",
    videoUrl: "https://www.instagram.com/reel/DJwaBeeMPXn/?igsh=OGRud21vdjV0NGtn",
    thumbnailUrl:
      "https://images.unsplash.com/photo-1517430816045-df4b7de11d1d", // MacBook with code
    title: "Sevenuz",
    description: "Ehtiyot bo’ling! Kuzatishyapti😅",
  },
  {
    id: "2",
    videoUrl: "https://www.instagram.com/reel/DJtmBBIMOOZ/?igsh=MXBmc2doOXRwaDlhMQ==",
    thumbnailUrl:
      "https://images.unsplash.com/photo-1556740749-887f6717d7e4", // Talking with client
    title: "Mijozlar bilan",
    description: "Sotuvchiyam videoni ko’rgan ekan😂",
  },
  {
    id: "3",
    videoUrl: "https://www.instagram.com/reel/DJrfQjlM2UK/?igsh=Ynk4cmFia3BpbGRv",
    thumbnailUrl:
      "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d", // Laughing guy
    title: "😂",
    description: "Shunaqalar ham ko’payib ketdi😂",
  },
  {
    id: "4",
    videoUrl: "https://www.instagram.com/reel/DJmV5DbMYQg/?igsh=ajI5MHpvYnRoeTE5",
    thumbnailUrl:
      "https://images.unsplash.com/photo-1524253482453-3fed8d2fe12b", // Confident guy
    title: "✔️",
    description: "Uncha-munchasigamas😂",
  },
];


export default function ThirdSection() {
  const controls = useAnimation()
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.3 })
  const { translations } = useLanguage()

  useEffect(() => {
    if (isInView) {
      controls.start("visible")
    }
  }, [controls, isInView])

  return (
    <section className="py-16 bg-gray-50 dark:bg-gray-900" ref={ref}>
      <div className="container mx-auto px-4">
        <motion.div
          initial="hidden"
          animate={controls}
          variants={{
            hidden: { opacity: 0, y: 20 },
            visible: {
              opacity: 1,
              y: 0,
              transition: {
                duration: 0.6,
                ease: "easeOut",
              },
            },
          }}
          className="max-w-6xl mx-auto"
        >
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white">{translations.news}</h2>
              <p className="text-gray-600 dark:text-gray-400 mt-2">
                Instagram sahifamizdagi so'nggi yangiliklar va videolar
              </p>
            </div>
            <Link href="https://www.instagram.com/seven_iphone.uz?igsh=amZqb2k3a281bm54" target="_blank" rel="noopener noreferrer">
              <Button variant="outline" className="flex items-center gap-2">
                <Instagram className="h-4 w-4 text-white hover:text-red-600 bg-red-600 hover:bg-white" />
                <span className="   hover:text-red-600  ">@seven.uz</span>
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {instagramPosts.map((post, index) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-all duration-300"
              >
                <Link href={post.videoUrl} target="_blank" rel="noopener noreferrer" className="block relative">
                  <div className="aspect-square relative overflow-hidden">
                    <img
                      src={post.thumbnailUrl || "https://www.instagram.com/reel/DJwaBeeMPXn/?igsh=OGRud21vdjV0NGtn"}
                      alt={post.title}
                      className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                    />
                    <div className="absolute inset-0 flex items-center justify-center bg-black/20 opacity-0 hover:opacity-100 transition-opacity duration-300">
                      <div className="w-12 h-12 rounded-full bg-white/90 flex items-center justify-center">
                        <div className="w-0 h-0 border-t-[8px] border-t-transparent border-l-[14px] border-l-red-600 border-b-[8px] border-b-transparent ml-1"></div>
                      </div>
                    </div>
                  </div>
                </Link>
                <div className="p-4">
                  <h3 className="font-bold text-gray-900 dark:text-white mb-1">{post.title}</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{post.description}</p>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-10">
            <Link href="https://www.instagram.com/seven_iphone.uz?igsh=amZqb2k3a281bm54" target="_blank" rel="noopener noreferrer">
              <Button className="bg-red-600 hover:bg-red-700 text-white">{translations.viewAll}</Button>
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
