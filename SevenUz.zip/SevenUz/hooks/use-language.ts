import { useLanguage } from "@/components/language-provider"

export { useLanguage }
