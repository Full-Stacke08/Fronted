import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Check, ChevronRight, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

export default function AirPodsMax2Page() {
  return (
    <div className="bg-white dark:bg-gray-950">
      {/* Breadcrumb */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
          <Link href="/" className="hover:text-red-600 dark:hover:text-red-400">
            Bosh sahifa
          </Link>
          <ChevronRight className="h-4 w-4 mx-2" />
          <Link href="/category/headphones" className="hover:text-red-600 dark:hover:text-red-400">
            Quloqchinlar
          </Link>
          <ChevronRight className="h-4 w-4 mx-2" />
          <span className="text-gray-900 dark:text-white">AirPods Max 2</span>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-b from-gray-100 to-white dark:from-gray-900 dark:to-gray-950 py-12 md:py-20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="w-full md:w-1/2 mb-8 md:mb-0">
              <Link href="/" className="inline-flex items-center text-red-600 mb-6 hover:underline">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Orqaga
              </Link>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-4">
                AirPods Max 2 (2025)
              </h1>
              <div className="flex items-center mb-4">
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="h-5 w-5 fill-current text-yellow-500" />
                  ))}
                </div>
                <span className="ml-2 text-gray-600 dark:text-gray-400">4.8 (932 sharh)</span>
              </div>
              <p className="text-lg text-gray-700 dark:text-gray-300 mb-6">
                Apple'ning eng yuqori sifatli quloqchini. Yangilangan H2 chipi, yanada yaxshilangan aktiv shovqinni yo'q
                qilish texnologiyasi va 30 soatgacha batareya quvvati bilan.
              </p>
              <div className="flex items-center mb-6">
                <span className="text-3xl font-bold text-gray-900 dark:text-white">8,999,000 so'm</span>
                <Badge className="ml-3 bg-green-600">Muddatli to'lov mavjud</Badge>
              </div>
              <div className="flex flex-wrap gap-4">
                <Button size="lg" className="bg-red-600 hover:bg-red-700">
                  Savatga qo'shish
                </Button>
              </div>
            </div>
            <div className="w-full md:w-1/2 flex justify-center">
              <div className="relative h-[400px] w-[700px]">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/airpods-max-select-silver-202011?wid=940&hei=1112&fmt=png-alpha&.v=1604021221000"
                  alt="AirPods Max 2"
                  fill
                  className="object-contain"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Product Details */}
      <div className="container mx-auto px-4 py-12">
        <Tabs defaultValue="features" className="w-full">
          <TabsList className="grid w-full md:w-auto grid-cols-3 mb-8">
            <TabsTrigger value="features">Xususiyatlar</TabsTrigger>
            <TabsTrigger value="specifications">Texnik ma'lumotlar</TabsTrigger>
            <TabsTrigger value="reviews">Sharhlar</TabsTrigger>
          </TabsList>
          <TabsContent value="features" className="space-y-12">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                  H2 chip - Eng kuchli audio protsessor
                </h2>
                <p className="text-gray-700 dark:text-gray-300 mb-4">
                  Yangi H2 chipi avvalgidan 2 barobar kuchliroq shovqinni yo'q qilish qobiliyatiga ega. Yangilangan
                  algoritm har soniyada 200 million marta atrof-muhit shovqinini tahlil qiladi va uni real vaqtda yo'q
                  qiladi.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">Yangilangan H2 audio protsessor</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">2 barobar kuchliroq shovqinni yo'q qilish</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">Yangilangan Adaptive EQ texnologiyasi</span>
                  </li>
                </ul>
              </div>
              <div className="relative h-[300px]">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/airpods-max-select-pink-202011?wid=940&hei=1112&fmt=png-alpha&.v=1604022365000"
                  alt="H2 Chip"
                  fill
                  className="object-contain"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div className="order-2 md:order-1 relative h-[300px]">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/airpods-max-select-green-202011?wid=940&hei=1112&fmt=png-alpha&.v=1604022364000"
                  alt="Sound Quality"
                  fill
                  className="object-contain"
                />
              </div>
              <div className="order-1 md:order-2">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Ajoyib ovoz sifati</h2>
                <p className="text-gray-700 dark:text-gray-300 mb-4">
                  AirPods Max 2 har bir quloqchinda 40 mm dinamik drayverlari bilan jihozlangan, bu esa chuqur bass,
                  aniq o'rta va tiniq yuqori chastotalarni ta'minlaydi. Computational Audio texnologiyasi har bir
                  tovushni real vaqtda optimallashtirib, eng yuqori sifatli audio tajribani ta'minlaydi.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">
                      40 mm Apple-loyihalashtirilgan dinamik drayverlar
                    </span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">Spatial Audio va Dynamic Head Tracking</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">Lossless Audio qo'llab-quvvatlaydi</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Qulay va chiroyli dizayn</h2>
                <p className="text-gray-700 dark:text-gray-300 mb-4">
                  AirPods Max 2 yuqori sifatli materiallardan tayyorlangan. Zanglamaydigan po'latdan yasalgan ramka,
                  mesh to'rli bosh tayanchi va akustik mato bilan qoplangan quloq yostiqchalari - barchasi uzoq vaqt
                  davomida qulay foydalanish uchun mo'ljallangan.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">
                      Yanada yengillashtirilgan konstruksiya (384g)
                    </span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">Almashtiriladigan quloq yostiqchalari</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">5 xil rang variantlari mavjud</span>
                  </li>
                </ul>
              </div>
              <div className="relative h-[300px]">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/airpods-max-select-spacegray-202011?wid=940&hei=1112&fmt=png-alpha&.v=1604709508000"
                  alt="Design"
                  fill
                  className="object-contain"
                />
              </div>
            </div>
          </TabsContent>
          <TabsContent value="specifications" className="space-y-6">
            <div className="border dark:border-gray-800 rounded-lg overflow-hidden">
              <div className="grid grid-cols-1 md:grid-cols-2">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">Audio</div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  40 mm Apple-loyihalashtirilgan dinamik drayverlar, Adaptive EQ, Aktiv shovqinni yo'q qilish,
                  Shaffoflik rejimi, Spatial Audio, Lossless Audio
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">Chip</div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  Apple H2 audio protsessor
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  Sensorlar
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  Optik sensor, pozitsiya sensori, harorat sensori, akselerometr, giroskop
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  Batareya
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  30 soatgacha tinglash vaqti (ANC yoqilgan holda), 5 daqiqalik zaryadlash 3 soatlik tinglash vaqtini
                  beradi
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  Boshqaruv
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  Digital Crown, shovqinni yo'q qilish tugmasi, ovoz bilan boshqarish (Siri)
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">Ulanish</div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  Bluetooth 5.3, USB-C port
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  Moslashuvchanlik
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  iPhone, iPad, Mac, Apple TV, Apple Watch bilan avtomatik ulanish
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  O'lchamlari
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  187.3 x 168.6 x 83.4 mm, 384 g
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="reviews" className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">Mijozlar sharhlari</h3>
              <Button>Sharh qoldirish</Button>
            </div>

            <div className="space-y-6">
              {/* Review 1 */}
              <div className="border dark:border-gray-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                      <span className="font-medium text-gray-700 dark:text-gray-300">LN</span>
                    </div>
                    <div className="ml-3">
                      <p className="font-medium text-gray-900 dark:text-white">Lola Nazarova</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">10 May, 2025</p>
                    </div>
                  </div>
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-4 w-4 fill-current text-yellow-500" />
                    ))}
                  </div>
                </div>
                <p className="text-gray-700 dark:text-gray-300">
                  Men bu quloqchinni ko'p sayohat qilganimda foydalanish uchun sotib oldim va juda mamnunman! Shovqinni
                  yo'q qilish funksiyasi samolyotda ham, gavjum ko'chalarda ham ajoyib ishlaydi. Ovoz sifati ham juda
                  yuqori darajada, ayniqsa klassik musiqa tinglash uchun.
                </p>
              </div>

              {/* Review 2 */}
              <div className="border dark:border-gray-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                      <span className="font-medium text-gray-700 dark:text-gray-300">OU</span>
                    </div>
                    <div className="ml-3">
                      <p className="font-medium text-gray-900 dark:text-white">Otabek Umarov</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">28 April, 2025</p>
                    </div>
                  </div>
                  <div className="flex">
                    {[1, 2, 3, 4].map((star) => (
                      <Star key={star} className="h-4 w-4 fill-current text-yellow-500" />
                    ))}
                    <Star className="h-4 w-4 text-gray-300 dark:text-gray-600" />
                  </div>
                </div>
                <p className="text-gray-700 dark:text-gray-300">
                  Quloqchin juda yaxshi, lekin narxi biroz qimmat. Ovoz sifati va shovqinni yo'q qilish funksiyasi juda
                  zo'r, ammo og'irligi uzoq vaqt davomida foydalanishda biroz noqulaylik tug'diradi. Umumiy baholashim -
                  yaxshi, lekin mukammal emas.
                </p>
              </div>

              {/* Review 3 */}
              <div className="border dark:border-gray-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                      <span className="font-medium text-gray-700 dark:text-gray-300">AK</span>
                    </div>
                    <div className="ml-3">
                      <p className="font-medium text-gray-900 dark:text-white">Akmal Karimov</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">15 April, 2025</p>
                    </div>
                  </div>
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-4 w-4 fill-current text-yellow-500" />
                    ))}
                  </div>
                </div>
                <p className="text-gray-700 dark:text-gray-300">
                  Men musiqa produceri sifatida bu quloqchinni professional ishim uchun sotib oldim. Ovoz sifati juda
                  aniq, har bir detalini eshitish mumkin. Spatial Audio funksiyasi bilan ishlash juda qulay, ayniqsa
                  mikslash paytida. Batareya quvvati ham ajoyib - butun ish kuni davomida yetadi. Albatta tavsiya
                  qilaman!
                </p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Related Products */}
      <div className="bg-gray-50 dark:bg-gray-900 py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-8">O'xshash mahsulotlar</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Product 1 */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
              <div className="relative h-48">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/MQD83?wid=1144&hei=1144&fmt=jpeg&qlt=90&.v=1660803972361"
                  alt="AirPods Pro 2"
                  fill
                  className="object-contain p-4"
                />
              </div>
              <div className="p-4">
                <h3 className="font-medium text-gray-900 dark:text-white mb-2">AirPods Pro 2</h3>
                <div className="flex items-center mb-2">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-3 w-3 fill-current text-yellow-500" />
                    ))}
                  </div>
                  <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">(1532)</span>
                </div>
                <p className="text-red-600 font-bold">3,999,000 so'm</p>
              </div>
            </div>

            {/* Product 2 */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
              <div className="relative h-48">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/MME73?wid=1144&hei=1144&fmt=jpeg&qlt=90&.v=1632861342000"
                  alt="AirPods 3"
                  fill
                  className="object-contain p-4"
                />
              </div>
              <div className="p-4">
                <h3 className="font-medium text-gray-900 dark:text-white mb-2">AirPods 3</h3>
                <div className="flex items-center mb-2">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-3 w-3 fill-current text-yellow-500" />
                    ))}
                  </div>
                  <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">(1024)</span>
                </div>
                <p className="text-red-600 font-bold">2,499,000 so'm</p>
              </div>
            </div>

            {/* Product 3 */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
              <div className="relative h-48">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/beats-solo4-product-red-witb-231005?wid=572&hei=572&fmt=jpeg&qlt=95&.v=1695933856697"
                  alt="Beats Solo 4"
                  fill
                  className="object-contain p-4"
                />
              </div>
              <div className="p-4">
                <h3 className="font-medium text-gray-900 dark:text-white mb-2">Beats Solo 4</h3>
                <div className="flex items-center mb-2">
                  <div className="flex">
                    {[1, 2, 3, 4].map((star) => (
                      <Star key={star} className="h-3 w-3 fill-current text-yellow-500" />
                    ))}
                    <Star className="h-3 w-3 text-gray-300 dark:text-gray-600" />
                  </div>
                  <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">(876)</span>
                </div>
                <p className="text-red-600 font-bold">4,499,000 so'm</p>
              </div>
            </div>

            {/* Product 4 */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
              <div className="relative h-48">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/homepod-mini-select-blue-202110?wid=1000&hei=1000&fmt=jpeg&qlt=95&.v=1632925511000"
                  alt="HomePod mini"
                  fill
                  className="object-contain p-4"
                />
              </div>
              <div className="p-4">
                <h3 className="font-medium text-gray-900 dark:text-white mb-2">HomePod mini</h3>
                <div className="flex items-center mb-2">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-3 w-3 fill-current text-yellow-500" />
                    ))}
                  </div>
                  <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">(932)</span>
                </div>
                <p className="text-red-600 font-bold">1,999,000 so'm</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
