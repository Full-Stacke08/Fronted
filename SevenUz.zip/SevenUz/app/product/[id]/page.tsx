"use client"

import { useParams } from "next/navigation"
import { ProductDetailView } from "@/components/product-detail-view"
import { getProductById } from "@/lib/product-data"

export default function ProductPage() {
  const params = useParams()
  const productId = params.id as string
  const product = getProductById(productId)

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-red-600"></h1>
      </div>
    )
  }

  return <ProductDetailView product={product} />
}
