"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import Link from "next/link"
import { Search, User, ShoppingCart, Menu, LogOut } from "lucide-react"
import { useAuth } from "./auth-provider"
import { useCart } from "./cart-provider"
import { LoginModal } from "./login-modal"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Input } from "@/components/ui/input"
import LoginNotification from "./login-notification"
import { useLanguage } from "./language-provider"
import { searchProducts } from "@/lib/product-data"
import { useRouter } from "next/navigation"
import { toast } from "sonner"

export default function Header() {
  const [showSearchInput, setShowSearchInput] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<any[]>([])
  const [showSearchResults, setShowSearchResults] = useState(false)
  const [showLoginModal, setShowLoginModal] = useState(false)
  const [showLoginNotification, setShowLoginNotification] = useState(false)
  const [hasShownNotification, setHasShownNotification] = useState(false)
  const [showUserMenu, setShowUserMenu] = useState(false)
  const [isAdmin, setIsAdmin] = useState(false)
  const { user, logout } = useAuth()
  const { cartItems } = useCart()
  const { translations } = useLanguage()
  const searchRef = useRef<HTMLDivElement>(null)
  const searchInputRef = useRef<HTMLInputElement>(null)
  const userMenuRef = useRef<HTMLDivElement>(null)
  const router = useRouter()

  // Admin ekanligini tekshirish
  useEffect(() => {
    const checkAdminStatus = () => {
      const adminStatus = localStorage.getItem("isAdmin") === "true"
      const currentUser = JSON.parse(localStorage.getItem("currentUser") || "{}")
      setIsAdmin(adminStatus && currentUser.isAdmin)
    }

    checkAdminStatus()
    // Storage o'zgarishlarini kuzatish
    window.addEventListener("storage", checkAdminStatus)

    return () => {
      window.removeEventListener("storage", checkAdminStatus)
    }
  }, [user])

  useEffect(() => {
    // Show login notification after 3 seconds if user is not logged in and hasn't been shown yet
    if (!user && !hasShownNotification && !isAdmin) {
      const timer = setTimeout(() => {
        setShowLoginNotification(true)
        setHasShownNotification(true)
        // Store in localStorage that notification has been shown
        localStorage.setItem("loginNotificationShown", "true")
      }, 3000)

      return () => clearTimeout(timer)
    }
  }, [user, hasShownNotification, isAdmin])

  // Check localStorage on component mount
  useEffect(() => {
    const hasBeenShown = localStorage.getItem("loginNotificationShown") === "true"
    setHasShownNotification(hasBeenShown)
  }, [])

  // Handle search input change
  useEffect(() => {
    if (searchQuery.trim().length > 1 && !isAdmin) {
      const results = searchProducts(searchQuery)
      setSearchResults(results.slice(0, 5)) // Limit to 5 results
      setShowSearchResults(true)
    } else {
      setSearchResults([])
      setShowSearchResults(false)
    }
  }, [searchQuery, isAdmin])

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim() && !isAdmin) {
      router.push(`/search?q=${encodeURIComponent(searchQuery)}`)
      setShowSearchResults(false)
    }
  }

  const handleProductClick = (productId: string) => {
    if (!isAdmin) {
      router.push(`/product/${productId}`)
      setSearchQuery("")
      setShowSearchResults(false)
    }
  }

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSearchResults(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setShowUserMenu(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  useEffect(() => {
    if (showSearchInput && searchInputRef.current) {
      searchInputRef.current.focus()
    }
  }, [showSearchInput])

  const handleOpenLoginModal = () => {
    setShowLoginModal(true)
  }

  const handleLogout = () => {
    logout()
    router.push("/")
    toast({
      title: "Tizimdan chiqdingiz",
      description: "Muvaffaqiyatli tizimdan chiqdingiz.",
    })
  }


  // Oddiy foydalanuvchilar uchun to'liq header
  return (
    <>
      <header
        className={
          `py-4 overflow-x-hidden w-full max-w-screen shadow-lg transition-all duration-300 z-50 ` +
          `bg-gray-900 text-white dark:bg-gray-900 dark:text-white`
        }
      >
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
                <div className="relative w-10 h-10 rounded-full overflow-hidden border-2 border-gray-200 dark:border-gray-700">
                  <Image src="https://i.postimg.cc/GmYZm8nq/IMG-20250525-003236-069.jpg" alt="Seven Logo" fill className="object-cover" />
                </div>
                <span className="ml-2 font-bold text-xl" style={{ color: "white" }}>
                  Seve<span className="text-white">n</span>
                </span>
            </div>

            <div className="flex items-center space-x-4">
              {/* Search */}
              <div ref={searchRef} className="relative hidden md:flex items-center">
                <form onSubmit={handleSearchSubmit} className="flex items-center">
                  <Input
                    type="text"
                    placeholder={translations.search + "..."}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-[200px] lg:w-[300px] h-9 pl-10 bg-white text-gray-900 dark:bg-red-600 dark:text-white"
                  />
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 dark:text-white" />
                  {showSearchResults && searchResults.length > 0 && (
                    <div className="absolute top-full left-0 right-0 mt-1 bg-white dark:bg-gray-800 shadow-lg rounded-md z-50 max-h-[400px] overflow-auto">
                      {searchResults.map((product) => (
                        <div
                          key={product.id}
                          className="p-3 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer flex items-center border-b border-gray-100 dark:border-gray-700"
                          onClick={() => handleProductClick(product.id)}
                        >
                          <div className="relative w-10 h-10 mr-3 flex-shrink-0">
                            <Image
                              src={product.image || "/placeholder.svg?height=40&width=40"}
                              alt={product.name}
                              fill
                              className="object-contain"
                            />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium text-gray-900 dark:text-white">{product.name}</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">${product.price}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </form>
              </div>

              {/* Mobile Search */}
              {showSearchInput ? (
                <form
                  onSubmit={handleSearchSubmit}
                  className="fixed top-22 right-6 z-50 lg:hidden md:hidden sm:inline flex items-center"
                >
                  <div className="relative">
                    <Input
                      ref={searchInputRef}
                      type="text"
                      placeholder={translations.search + "..."}
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-[200px] h-9 pl-8 pr-2 text-sm bg-white text-gray-900 dark:bg-red-600 dark:text-white shadow-md rounded-md"
                      onBlur={() => {
                        if (!searchQuery.trim()) {
                          setShowSearchInput(false)
                        }
                      }}
                    />
                    <Search className="absolute left-2 top-1/2 transform  -translate-y-1/2 h-4 w-4 text-gray-400 dark:text-white" />
                    {showSearchResults && searchResults.length > 0 && (
                      <div className="absolute top-full left-0 right-0 mt-1 bg-white dark:bg-gray-800 shadow-lg rounded-md z-50 max-h-[300px] overflow-auto">
                        {searchResults.map((product) => (
                          <div
                            key={product.id}
                            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer flex items-center border-b border-gray-100 dark:border-gray-700"
                            onClick={() => handleProductClick(product.id)}
                          >
                            <div className="relative w-8 h-8 mr-2 flex-shrink-0">
                              <Image
                                src={product.image || "/placeholder.svg?height=32&width=32"}
                                alt={product.name}
                                fill
                                className="object-contain"
                              />
                            </div>
                            <div className="flex-1">
                              <p className="text-xs font-medium text-gray-900 dark:text-white">{product.name}</p>
                              <p className="text-xs text-gray-500 dark:text-gray-400">${product.price}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </form>
              ) : (
                <button
                  onClick={() => setShowSearchInput(true)}
                  className="p-2 rounded-full hover:bg-gray-100 lg:hidden md:hidden dark:hover:bg-gray-800 transition-all duration-300"
                  aria-label={translations.search}
                >
                  <Search className="h-5 w-5 text-gray-700 dark:text-gray-300" />
                </button>
              )}

              {/* User Account */}
              {user ? (
                <div className="relative" ref={userMenuRef}>
                  <button
                    onClick={() => setShowUserMenu(!showUserMenu)}
                    className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-all duration-300 relative"
                    aria-label={translations.myAccount}
                  >
                    <User className="h-5 w-5 text-gray-700 dark:text-gray-300" />
                    {user && (
                      <span className="absolute -top-1 -right-1 bg-red-600 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                        2
                      </span>
                    )}
                  </button>
                  {showUserMenu && (
                    <div className="fixed right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg py-1 z-50 border border-gray-200 dark:border-gray-700">
                      <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-700">
                        <div className="flex items-center">
                          <div className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                            {user.avatar ? (
                              <Image
                                src={user.avatar || "/placeholder.svg"}
                                alt={user.firstName}
                                width={32}
                                height={32}
                                className="object-cover"
                              />
                            ) : (
                              <User className="h-4 w-4 text-gray-500 dark:text-gray-400" />
                            )}
                          </div>
                          <div className="ml-3">
                            <p className="text-sm font-medium text-gray-900 dark:text-white">
                              {user.firstName} {user.lastName}
                            </p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">{user.email || user.phone}</p>
                          </div>
                        </div>
                      </div>
                      <Link
                        href="/profile"
                        className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                      >
                        {translations.myAccount}
                      </Link>
                       
                      <button
                        onClick={handleLogout}
                        className="block w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                      >
                        {translations.logout}
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <button
                  onClick={() => setShowLoginModal(true)}
                  className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-all duration-300"
                  aria-label={translations.login}
                >
                  <User className="h-5 w-5 text-gray-700 dark:text-gray-300" />
                </button>
              )}

              {/* Shopping Cart */}
              <Link
                href="/cart"
                className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-all duration-300 relative"
                aria-label={translations.cart}
              >
                <ShoppingCart className="h-5 w-5 text-gray-700 dark:text-gray-300" />
                {cartItems.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-600 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                    {cartItems.length}
                  </span>
                )}
              </Link>

              {/* Mobile Menu */}
             <Sheet>
  <SheetTrigger asChild>
    <Button variant="ghost" size="icon" className="md:hidden text-white hover:bg-gray-800">
      <Menu className="h-5 w-5" />
      <span className="sr-only">Open menu</span>
    </Button>
  </SheetTrigger>

  <SheetContent
    side="right"
    className="w-[300px] p-4 bg-white dark:bg-gray-900 z-50 transform transition-transform duration-300 translate-x-full data-[state=open]:translate-x-0"
  >
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="flex items-center justify-between mb-6">
          <div className="relative w-8 h-8 rounded-full overflow-hidden border-2 border-gray-200 dark:border-gray-700">
            <Image src="https://i.postimg.cc/GmYZm8nq/IMG-20250525-003236-069.jpg" alt="Seven Logo" fill className="object-cover" />
          </div>
          <span className="ml-2 font-bold text-gray-800 dark:text-white text-lg">
            Seve<span className="text-red-600">n</span>
          </span>
      </div>

      {/* Navigation */}
      <nav className="mb-6">
        <ul className="space-y-4">
          <li><Link href="/company" className="block text-gray-700 dark:text-gray-300 hover:text-red-600">{translations.aboutCompany}</Link></li>
          <li><Link href="/category/smartphones" className="block text-gray-700 dark:text-gray-300 hover:text-red-600">{translations.smartphones}</Link></li>
          <li><Link href="/category/tablets" className="block text-gray-700 dark:text-gray-300 hover:text-red-600">{translations.tablets}</Link></li>
          <li><Link href="/category/laptops" className="block text-gray-700 dark:text-gray-300 hover:text-red-600">{translations.laptops}</Link></li>
          <li><Link href="/category/smartwatches" className="block text-gray-700 dark:text-gray-300 hover:text-red-600">{translations.smartwatches}</Link></li>
          <li><Link href="/category/headphones" className="block text-gray-700 dark:text-gray-300 hover:text-red-600">{translations.headphones}</Link></li>
          <li><Link href="/category/accessories" className="block text-gray-700 dark:text-gray-300 hover:text-red-600">{translations.accessories}</Link></li>
        </ul>
      </nav>

      {/* User info */}
      <div className="mt-auto pt-6 border-t border-gray-200 dark:border-gray-700">
        {user ? (
          <div className="space-y-4">
            <div className="flex items-center">
              <div className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                {user?.avatar ? (
                  <Image src={user.avatar} alt={user.firstName} width={32} height={32} className="object-cover" />
                ) : (
                  <User className="h-4 w-4 text-gray-500 dark:text-gray-400" />
                )}
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-900 dark:text-white">
                  {user.firstName} {user.lastName}
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400">{user.email || user.phone}</p>
              </div>
            </div>
            <div className="space-y-2">
              <Link href="/profile" className="block text-sm text-gray-700 dark:text-gray-300 hover:text-red-600">{translations.myAccount}</Link>
 
              <button onClick={handleLogout} className="block text-sm text-gray-700 dark:text-gray-300 hover:text-red-600">{translations.logout}</button>
            </div>
          </div>
        ) : (
          <Button onClick={() => setShowLoginModal(true)} className="w-full bg-red-600 hover:bg-red-700">
            {translations.login}
          </Button>
        )}
      </div>
    </div>
  </SheetContent>
</Sheet>

            </div>
          </div>
        </div>
      </header>

      {showLoginNotification && !user && !isAdmin && (
        <LoginNotification onClose={() => setShowLoginNotification(false)} onLogin={handleOpenLoginModal} />
      )}
      {showLoginModal && <LoginModal isOpen={showLoginModal} onClose={() => setShowLoginModal(false)} />}
    </>
  )
}
