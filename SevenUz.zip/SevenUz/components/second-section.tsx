"use client"

import type React from "react"

import { useState, useRef } from "react"
import { ShieldCheck, Truck, CreditCard, Headphones, Gift, CheckCircle2, ArrowLeft } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { useLanguage } from "./language-provider"

interface Feature {
  id: string
  icon: React.ReactNode
  title: string
  description: string
  longDescription: string
  benefits: string[]
}

// Update the SecondSection component to use translations

export default function SecondSection() {
  const { translations, language } = useLanguage()
  const [expandedFeature, setExpandedFeature] = useState<string | null>(null)
  const [showAll, setShowAll] = useState(false)
  const sectionRef = useRef<HTMLDivElement>(null)

  // Define translations for detailed content
  const featureDetails = {
    uz: {
      quality: {
        longDescription:
          "Seven Uz'da barcha mahsulotlar qattiq sifat nazoratidan o'tkaziladi. Har bir telefon batareya sog'lig'i, kamera ishlashi, ekran holati va boshqa jihatlardan tekshiriladi. Biz faqat sifatli mahsulotlarni taklif qilamiz va har bir mahsulotga 6 oylik kafolat beramiz.",
        benefits: [
          "Har bir qurilma 50+ nuqtadan tekshiriladi",
          "Batareya sog'lig'i 80% dan yuqori bo'lgan qurilmalar",
          "6 oylik kafolat barcha mahsulotlarga",
          "Ekran, kamera va boshqa qismlar alohida tekshiriladi",
          "Nosoz qurilmalar sotuvga qo'yilmaydi",
        ],
      },
      delivery: {
        longDescription:
          "Toshkent shahrida buyurtmalar 24 soat ichida yetkazib beriladi. Boshqa viloyatlarga 2-3 kun ichida yetkazib beriladi. Toshkent shahri bo'ylab yetkazib berish mutlaqo bepul. Mahsulot yetkazib berilgandan so'ng siz uni tekshirib, so'ng to'lovni amalga oshirasiz.",
        benefits: [
          "Toshkent bo'ylab bepul yetkazib berish",
          "24 soat ichida yetkazib berish",
          "Viloyatlarga 2-3 kun ichida yetkazib berish",
          "Mahsulotni tekshirgandan so'ng to'lov",
          "Yetkazib berish vaqtini o'zingiz tanlash imkoniyati",
        ],
      },
      payment: {
        longDescription:
          "Seven Uz'da to'lovni xohlagan usulda amalga oshirishingiz mumkin. Naqd pul, bank o'tkazmasi, Click, Payme, Uzcard va boshqa to'lov turlari mavjud. Bundan tashqari, bizda muddatli to'lov ham mavjud - boshlang'ich to'lov qilib, qolgan qismini 3, 6 yoki 12 oy davomida to'lashingiz mumkin.",
        benefits: [
          "Naqd pul, plastik karta orqali to'lov",
          "Click, Payme, Uzcard orqali to'lov",
          "3, 6 va 12 oylik muddatli to'lov",
          "Boshlang'ich to'lovsiz variantlar",
          "Korporativ mijozlar uchun maxsus shartlar",
        ],
      },
      support: {
        longDescription:
          "Bizning qo'llab-quvvatlash xizmatimiz haftaning 7 kuni, kunning 24 soati davomida ishlaydi. Har qanday savol yoki muammo bo'yicha bizga murojaat qilishingiz mumkin. Telegram kanal va guruhlarimiz, telefon raqamlarimiz orqali darhol javob olasiz. Mijozlar xizmati - bizning ustuvor vazifamiz.",
        benefits: [
          "24/7 telefon orqali qo'llab-quvvatlash",
          "Telegram guruh va kanallar orqali tezkor yordam",
          "Onlayn chat orqali maslahat",
          "Mahsulot ishlashini o'rgatish",
          "Texnik muammolarni hal qilishda yordam",
        ],
      },
      bonus: {
        longDescription:
          "Seven Uz'dan xarid qilsangiz, bonuslar to'playsiz. Har 10,000 so'mlik xarid uchun 200 bonus ball qo'shiladi. Keyingi xaridlarda bu ballarddan foydalanishingiz mumkin. Bundan tashqari, yangi mijozlar uchun maxsus aksiyalarimiz va sovg'alarimiz mavjud. Telegram kanalimizga a'zo bo'lib, yangi aksiyalar haqida birinchilardan bo'lib bilib turing.",
        benefits: [
          "Har 10,000 so'mga 200 bonus ball",
          "Bonuslarni keyingi xaridlarda ishlatish",
          "Yangi mijozlar uchun maxsus aksiyalar",
          "Har bir xarid bilan qo'shimcha aksessuarlar",
          "Telegram kanalda maxsus chegirmalar",
        ],
      },
      authenticity: {
        longDescription:
          "Biz sotadigan barcha iPhone'lar originaldir. Har bir qurilma IMEI raqami tekshirilgan va ularni ishlab chiqarilgan mamlakat, aktivatsiya sanasi va boshqa muhim ma'lumotlarni tekshirishingiz mumkin. Nusxa mahsulotlar sotmaymiz va har bir mahsulotning haqiqiyligini kafolatlaymiz.",
        benefits: [
          "Har bir qurilma IMEI raqami tekshirilgan",
          "Apple rasmiy ma'lumotlar bazasida tekshirilgan",
          "Ishlab chiqarilgan mamlakat va sana ma'lumotlari",
          "Aktivatsiya tarixi tekshirilgan",
          "Faqat original Apple mahsulotlari",
        ],
      },
    },
    ru: {
      quality: {
        longDescription:
          "В Seven Uz все продукты проходят строгий контроль качества. Каждый телефон проверяется на состояние батареи, работу камеры, состояние экрана и другие аспекты. Мы предлагаем только качественные продукты и предоставляем 6-месячную гарантию на каждый продукт.",
        benefits: [
          "Каждое устройство проверяется по 50+ пунктам",
          "Устройства с состоянием батареи выше 80%",
          "6-месячная гарантия на все продукты",
          "Экран, камера и другие части проверяются отдельно",
          "Неисправные устройства не выставляются на продажу",
        ],
      },
      delivery: {
        longDescription:
          "В Ташкенте заказы доставляются в течение 24 часов. В другие регионы доставка осуществляется в течение 2-3 дней. Доставка по Ташкенту абсолютно бесплатная. После доставки товара вы можете проверить его, а затем произвести оплату.",
        benefits: [
          "Бесплатная доставка по Ташкенту",
          "Доставка в течение 24 часов",
          "Доставка в регионы в течение 2-3 дней",
          "Оплата после проверки товара",
          "Возможность выбора времени доставки",
        ],
      },
      payment: {
        longDescription:
          "В Seven Uz вы можете произвести оплату любым удобным способом. Наличные, банковский перевод, Click, Payme, Uzcard и другие виды оплаты доступны. Кроме того, у нас есть рассрочка - вы можете внести первоначальный платеж и оплатить остаток в течение 3, 6 или 12 месяцев.",
        benefits: [
          "Оплата наличными, пластиковой картой",
          "Оплата через Click, Payme, Uzcard",
          "Рассрочка на 3, 6 и 12 месяцев",
          "Варианты без первоначального взноса",
          "Специальные условия для корпоративных клиентов",
        ],
      },
      support: {
        longDescription:
          "Наша служба поддержки работает 7 дней в неделю, 24 часа в сутки. Вы можете обратиться к нам по любому вопросу или проблеме. Вы получите немедленный ответ через наши Telegram каналы и группы, по телефону. Обслуживание клиентов - наш приоритет.",
        benefits: [
          "Поддержка по телефону 24/7",
          "Быстрая помощь через Telegram группы и каналы",
          "Консультация через онлайн-чат",
          "Обучение использованию продукта",
          "Помощь в решении технических проблем",
        ],
      },
      bonus: {
        longDescription:
          "При покупке в Seven Uz вы накапливаете бонусы. За каждые 10,000 сумов покупки добавляется 200 бонусных баллов. Вы можете использовать эти баллы при следующих покупках. Кроме того, у нас есть специальные акции и подарки для новых клиентов. Подпишитесь на наш Telegram канал, чтобы первыми узнавать о новых акциях.",
        benefits: [
          "200 бонусных баллов за каждые 10,000 сумов",
          "Использование бонусов при следующих покупках",
          "Специальные акции для новых клиентов",
          "Дополнительные аксессуары с каждой покупкой",
          "Специальные скидки в Telegram канале",
        ],
      },
      authenticity: {
        longDescription:
          "Все iPhone, которые мы продаем, оригинальные. Каждое устройство проверено по IMEI номеру, и вы можете проверить страну производства, дату активации и другую важную информацию. Мы не продаем копии и гарантируем подлинность каждого продукта.",
        benefits: [
          "Каждое устройство проверено по IMEI номеру",
          "Проверено в официальной базе данных Apple",
          "Информация о стране и дате производства",
          "Проверена история активации",
          "Только оригинальные продукты Apple",
        ],
      },
    },
    en: {
      quality: {
        longDescription:
          "At Seven Uz, all products undergo strict quality control. Each phone is checked for battery health, camera operation, screen condition, and other aspects. We offer only quality products and provide a 6-month warranty on each product.",
        benefits: [
          "Each device is checked at 50+ points",
          "Devices with battery health above 80%",
          "6-month warranty on all products",
          "Screen, camera, and other parts are checked separately",
          "Defective devices are not put up for sale",
        ],
      },
      delivery: {
        longDescription:
          "In Tashkent, orders are delivered within 24 hours. To other regions, delivery is made within 2-3 days. Delivery throughout Tashkent is absolutely free. After the product is delivered, you can check it and then make the payment.",
        benefits: [
          "Free delivery in Tashkent",
          "Delivery within 24 hours",
          "Delivery to regions within 2-3 days",
          "Payment after checking the product",
          "Ability to choose delivery time",
        ],
      },
      payment: {
        longDescription:
          "At Seven Uz, you can make a payment in any way you like. Cash, bank transfer, Click, Payme, Uzcard, and other payment types are available. In addition, we have installment payments - you can make an initial payment and pay the rest over 3, 6, or 12 months.",
        benefits: [
          "Payment by cash, plastic card",
          "Payment via Click, Payme, Uzcard",
          "3, 6, and 12-month installment payment",
          "Options without initial payment",
          "Special terms for corporate clients",
        ],
      },
      support: {
        longDescription:
          "Our support service works 7 days a week, 24 hours a day. You can contact us with any question or problem. You will receive an immediate response through our Telegram channels and groups, by phone. Customer service is our priority.",
        benefits: [
          "24/7 phone support",
          "Quick help via Telegram groups and channels",
          "Consultation via online chat",
          "Product usage training",
          "Help with technical issues",
        ],
      },
      bonus: {
        longDescription:
          "When you shop at Seven Uz, you accumulate bonuses. For every 10,000 soums of purchase, 200 bonus points are added. You can use these points in subsequent purchases. In addition, we have special promotions and gifts for new customers. Subscribe to our Telegram channel to be the first to know about new promotions.",
        benefits: [
          "200 bonus points for every 10,000 soums",
          "Use bonuses in subsequent purchases",
          "Special promotions for new customers",
          "Additional accessories with each purchase",
          "Special discounts in Telegram channel",
        ],
      },
      authenticity: {
        longDescription:
          "All iPhones we sell are original. Each device has been checked by IMEI number, and you can check the country of manufacture, activation date, and other important information. We do not sell copies and guarantee the authenticity of each product.",
        benefits: [
          "Each device is checked by IMEI number",
          "Checked in Apple's official database",
          "Country and date of manufacture information",
          "Activation history checked",
          "Only original Apple products",
        ],
      },
    },
  }

  const features: Feature[] = [
    {
      id: "quality",
      icon: <ShieldCheck className="h-10 w-10 text-red-600" />,
      title: translations.qualityGuarantee,
      description: translations.qualityDescription,
      longDescription: featureDetails[language].quality.longDescription,
      benefits: featureDetails[language].quality.benefits,
    },
    {
      id: "delivery",
      icon: <Truck className="h-10 w-10 text-red-600" />,
      title: translations.fastDelivery,
      description: translations.deliveryDescription,
      longDescription: featureDetails[language].delivery.longDescription,
      benefits: featureDetails[language].delivery.benefits,
    },
    {
      id: "payment",
      icon: <CreditCard className="h-10 w-10 text-red-600" />,
      title: translations.easyPayment,
      description: translations.paymentDescription,
      longDescription: featureDetails[language].payment.longDescription,
      benefits: featureDetails[language].payment.benefits,
    },
    {
      id: "support",
      icon: <Headphones className="h-10 w-10 text-red-600" />,
      title: translations.support,
      description: translations.supportDescription,
      longDescription: featureDetails[language].support.longDescription,
      benefits: featureDetails[language].support.benefits,
    },
    {
      id: "bonus",
      icon: <Gift className="h-10 w-10 text-red-600" />,
      title: translations.bonuses,
      description: translations.bonusesDescription,
      longDescription: featureDetails[language].bonus.longDescription,
      benefits: featureDetails[language].bonus.benefits,
    },
    {
      id: "authenticity",
      icon: <CheckCircle2 className="h-10 w-10 text-red-600" />,
      title: translations.authenticity,
      description: translations.authenticityDescription,
      longDescription: featureDetails[language].authenticity.longDescription,
      benefits: featureDetails[language].authenticity.benefits,
    },
  ]

  const handleFeatureClick = (id: string) => {
    setExpandedFeature(id)

    // Scroll to section top when feature is expanded
    if (sectionRef.current) {
      sectionRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }

  const closeExpandedFeature = () => {
    setExpandedFeature(null)
  }

  const toggleShowAll = () => {
    setShowAll(!showAll)
  }

  const selectedFeature = expandedFeature ? features.find((f) => f.id === expandedFeature) : null

  return (
    <section className="py-12 bg-white dark:bg-gray-900" ref={sectionRef}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{translations.whyChooseUs}</h2>
          {!expandedFeature && (
            <Button variant="link" className="text-red-600 dark:text-red-400" onClick={toggleShowAll}>
              {showAll
                ? language === "uz"
                  ? "Qisqartirish"
                  : language === "ru"
                    ? "Свернуть"
                    : "Collapse"
                : translations.viewAll}
            </Button>
          )}
        </div>

        <AnimatePresence mode="wait">
          {expandedFeature ? (
            <motion.div
              key="expanded"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="space-y-6"
            >
              <Button
                variant="ghost"
                size="sm"
                onClick={closeExpandedFeature}
                className="flex items-center text-gray-600 dark:text-gray-400 hover:text-red-600 dark:hover:text-red-400 mb-4"
              >
                <ArrowLeft className="h-4 w-4 mr-1" />
                <span>{language === "uz" ? "Orqaga" : language === "ru" ? "Назад" : "Back"}</span>
              </Button>

              {selectedFeature && (
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ duration: 0.5 }}
                  className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden"
                >
                  <div className="p-6">
                    <div className="flex items-center mb-4">
                      <div className="bg-red-50 dark:bg-red-900/20 p-3 rounded-full mr-4">{selectedFeature.icon}</div>
                      <h3 className="text-xl font-bold text-gray-900 dark:text-white">{selectedFeature.title}</h3>
                    </div>

                    <p className="text-gray-700 dark:text-gray-300 mb-6 leading-relaxed">
                      {selectedFeature.longDescription}
                    </p>

                    <div className="bg-gray-50 dark:bg-gray-900/50 rounded-lg p-4">
                      <h4 className="font-medium text-gray-900 dark:text-white mb-3">
                        {language === "uz" ? "Afzalliklar:" : language === "ru" ? "Преимущества:" : "Benefits:"}
                      </h4>
                      <ul className="space-y-2">
                        {selectedFeature.benefits.map((benefit, index) => (
                          <motion.li
                            key={index}
                            initial={{ x: -10, opacity: 0 }}
                            animate={{ x: 0, opacity: 1 }}
                            transition={{ delay: index * 0.1 }}
                            className="flex items-start"
                          >
                            <CheckCircle2 className="h-5 w-5 text-red-600 mr-2 flex-shrink-0 mt-0.5" />
                            <span className="text-gray-700 dark:text-gray-300">{benefit}</span>
                          </motion.li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </motion.div>
              )}
            </motion.div>
          ) : (
            <motion.div
              key="grid"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <AnimatePresence>
                  {features.slice(0, showAll ? features.length : 3).map((feature, index) => (
                    <motion.div
                      key={feature.id}
                      layout
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                      className="bg-white dark:bg-gray-800 rounded-lg shadow-sm hover:shadow-md transition-all duration-300 cursor-pointer"
                      onClick={() => handleFeatureClick(feature.id)}
                      whileHover={{ y: -5 }}
                    >
                      <div className="p-6">
                        <div className="flex flex-col items-center text-center">
                          <div className="bg-red-50 dark:bg-red-900/20 p-3 rounded-full">{feature.icon}</div>
                          <h3 className="mt-4 font-semibold text-lg text-gray-900 dark:text-white">{feature.title}</h3>
                          <p className="mt-2 text-gray-600 dark:text-gray-400 mb-4">{feature.description}</p>
                          <Button variant="ghost" size="sm" className="text-red-600 dark:text-red-400 mt-auto">
                            {language === "uz" ? "Batafsil" : language === "ru" ? "Подробнее" : "More Details"}
                          </Button>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              {!showAll && features.length > 3 && (
                <motion.div
                  className="flex justify-center mt-8"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.3 }}
                >
                  <Button onClick={toggleShowAll} className="bg-red-600 hover:bg-red-700">
                    {language === "uz" ? "Yana ko'rsatish" : language === "ru" ? "Показать еще" : "Show More"}
                  </Button>
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  )
}

// If this component uses featuredProducts, make sure it's compatible with the new data structure
// Check if it needs to be updated to work with the new Product interface
