import type { OrderDetails } from "@/lib/telegram"

export const submitOrder = async (
  orderData: Omit<OrderDetails, "orderId">,
): Promise<{ success: boolean; orderId?: string; message: string }> => {
  try {
    const response = await fetch("/api/orders", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(orderData),
    })

    const data = await response.json()

    if (!response.ok) {
      throw new Error(data.message || "Failed to submit order")
    }

    return {
      success: true,
      orderId: data.orderId,
      message: "Order submitted successfully",
    }
  } catch (error) {
    console.error("Error submitting order:", error)
    return {
      success: false,
      message: error instanceof Error ? error.message : "An unknown error occurred",
    }
  }
}

export const getOrderStatus = async (
  orderId: string,
): Promise<{ status: "pending" | "confirmed" | "rejected" | "unknown"; message: string }> => {
  try {
    const response = await fetch(`/api/orders/${orderId}`)
    const data = await response.json()

    if (!response.ok) {
      throw new Error(data.message || "Failed to get order status")
    }

    return {
      status: data.status,
      message: data.message,
    }
  } catch (error) {
    console.error("Error getting order status:", error)
    return {
      status: "unknown",
      message: "Failed to retrieve order status",
    }
  }
}
