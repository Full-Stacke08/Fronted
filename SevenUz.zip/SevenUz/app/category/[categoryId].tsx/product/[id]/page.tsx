"use client"

import { useParams } from "next/navigation"
import { ProductDetailView } from "@/components/product-detail-view"
import { getProductById } from "@/lib/product-data"
import { Breadcrumb } from "@/components/ui/breadcrumb"
import { useLanguage } from "@/hooks/use-language"

export default function CategoryProductPage() {
  const params = useParams()
  const productId = params.id as string
  const categoryId = params.categoryId as string
  const { language } = useLanguage()
  const product = getProductById(productId)

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-red-600">Mahsulot topilmadi</h1>
      </div>
    )
  }

  const breadcrumbItems = [
    { label: language === 'uz' ? 'Bosh sahifa' : 'Главная', href: '/' },
    { label: language === 'uz' ? 'Katalog' : 'Каталог', href: '/catalog' },
    { 
      label: language === 'uz' ? product.categoryUz || product.category : product.categoryRu || product.category, 
      href: `/category/${categoryId}` 
    },
    { label: language === 'uz' ? product.nameUz || product.name : product.nameRu || product.name }
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <Breadcrumb items={breadcrumbItems} />
      <ProductDetailView product={product} />
    </div>
  )
}
