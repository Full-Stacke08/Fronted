"use client"

import { useState } from "react"
import Image from "next/image"
import { motion } from "framer-motion"
import { Star, ShoppingCart, Heart, Share2, Truck, Shield, RotateCcw, Award } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useCart } from "@/components/cart-provider"
import { useToast } from "@/hooks/use-toast"
import { useLanguage } from "@/hooks/use-language"
import { getRelatedProducts } from "@/lib/product-data"
import type { Product } from "@/lib/types"

interface ProductDetailViewProps {
  product: Product
}

export function ProductDetailView({ product }: ProductDetailViewProps) {
  const [selectedImage, setSelectedImage] = useState(0)
  const [quantity, setQuantity] = useState(1)
  const [selectedColor, setSelectedColor] = useState(product.color || "")
  const { addToCart } = useCart()
  const { toast } = useToast()
  const { language, translations } = useLanguage()
  const relatedProducts = getRelatedProducts(product.id)

  const handleAddToCart = () => {
    addToCart({
      id: product.id,
      name: getProductField(product, "name", language),
      price: product.price,
      quantity,
      image: product.image || "",
    })

    toast({
      title: translations.productAdded,
      description: `${getProductField(product, "name", language)} ${translations.productAddedDesc}`,
      duration: 3000,
    })
  }

  function getProductField(product: Product, field: "name" | "description", language: string) {
    const langKey = field + language.charAt(0).toUpperCase() + language.slice(1)
    return (product as any)[langKey] || product[field] || ""
  }

  function getProductFeatures(product: Product, language: string) {
    const langKey = "features" + language.charAt(0).toUpperCase() + language.slice(1)
    return (product as any)[langKey] || product.features || []
  }

  function getProductSpecs(product: Product, language: string) {
    const langKey = "specifications" + language.charAt(0).toUpperCase() + language.slice(1)
    return (product as any)[langKey] || product.specifications || {}
  }

  const images = product.images || [product.image || ""]

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Product Images */}
          <div className="space-y-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="relative aspect-square bg-white dark:bg-gray-800 rounded-2xl p-8 overflow-hidden"
            >
              <Image
                src={images[selectedImage] || "/placeholder.svg"}
                alt={getProductField(product, "name", language)}
                fill
                className="object-contain"
              />
              {product.oldPrice && (
                <div className="absolute top-4 left-4 bg-red-600 text-white text-sm font-bold px-3 py-1 rounded-full">
                  {Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100)}% {translations.discount}
                </div>
              )}
              {product.isNew && (
                <Badge className="absolute top-4 right-4 bg-green-600 hover:bg-green-700">{translations.news}</Badge>
              )}
            </motion.div>

            {/* Thumbnail Images */}
            {images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto">
                {images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`relative w-20 h-20 bg-white dark:bg-gray-800 rounded-lg overflow-hidden border-2 transition-colors ${
                      selectedImage === index
                        ? "border-red-600"
                        : "border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600"
                    }`}
                  >
                    <Image
                      src={image || "/placeholder.svg"}
                      alt={`${getProductField(product, "name", language)} ${index + 1}`}
                      fill
                      className="object-contain p-2"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 dark:text-white mb-4">
                {getProductField(product, "name", language)}
              </h1>

              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${
                        i < Math.floor(product.rating || 5)
                          ? "text-yellow-400 fill-current"
                          : "text-gray-300 dark:text-gray-600"
                      }`}
                    />
                  ))}
                  <span className="text-sm text-gray-600 dark:text-gray-400 ml-2">
                    {product.rating || 5}.0 ({product.reviews || 0} {translations.reviews})
                  </span>
                </div>
                {product.isBestseller && (
                  <Badge
                    variant="secondary"
                    className="bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200"
                  >
                    {translations.bestSellers}
                  </Badge>
                )}
              </div>

              <p className="text-gray-600 dark:text-gray-300 text-lg mb-6">
                {getProductField(product, "description", language)}
              </p>

              <div className="flex items-end gap-4 mb-6">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{translations.price}:</p>
                  <div className="flex items-center gap-2">
                    <span className="text-4xl font-bold text-red-600 dark:text-red-400">${product.price}</span>
                    {product.oldPrice && (
                      <span className="text-xl text-gray-500 line-through">${product.oldPrice}</span>
                    )}
                  </div>
                </div>
                <p className="text-sm text-green-600 dark:text-green-400 font-medium">{translations.inStock}</p>
              </div>
            </motion.div>

            {/* Color Selection */}
            {product.color && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="space-y-3"
              >
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{translations.colors}:</h3>
                <div className="flex flex-wrap gap-2">
                  <button
                    className={`px-4 py-2 rounded-lg border-2 transition-colors ${
                      selectedColor === product.color
                        ? "border-red-600 bg-red-50 dark:bg-red-950 text-red-600"
                        : "border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600"
                    }`}
                  >
                    {product.color}
                  </button>
                </div>
              </motion.div>
            )}

            {/* Quantity and Add to Cart */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="space-y-4"
            >
              <div className="flex items-center gap-4">
                <div className="flex items-center border border-gray-300 dark:border-gray-600 rounded-lg">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  >
                    -
                  </button>
                  <span className="px-4 py-2 font-medium">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  >
                    +
                  </button>
                </div>
                <span className="text-sm text-gray-600 dark:text-gray-400">{translations.quantity}</span>
              </div>

              <div className="flex flex-wrap gap-4">
                <Button
                  size="lg"
                  onClick={handleAddToCart}
                  className="bg-red-600 hover:bg-red-700 text-white flex-1 sm:flex-none"
                >
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  {translations.addToCart}
                </Button>
                <Button size="lg" variant="outline" className="border-gray-300 dark:border-gray-600">
                  <Heart className="h-5 w-5 mr-2" />
                  {translations.addToWishlist}
                </Button>
                <Button size="lg" variant="outline" className="border-gray-300 dark:border-gray-600">
                  <Share2 className="h-5 w-5 mr-2" />
                  {translations.share}
                </Button>
              </div>
            </motion.div>

            {/* Features */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="grid grid-cols-2 gap-4 p-4 bg-gray-100 dark:bg-gray-800 rounded-lg"
            >
              <div className="flex items-center gap-2">
                <Truck className="h-5 w-5 text-green-600" />
                <span className="text-sm">{translations.freeShipping}</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-blue-600" />
                <span className="text-sm">{translations.warranty}</span>
              </div>
              <div className="flex items-center gap-2">
                <RotateCcw className="h-5 w-5 text-orange-600" />
                <span className="text-sm">{translations.returns}</span>
              </div>
              <div className="flex items-center gap-2">
                <Award className="h-5 w-5 text-purple-600" />
                <span className="text-sm">{translations.authenticity}</span>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Product Details Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="mt-16"
        >
          <Tabs defaultValue="features" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="features">{translations.features}</TabsTrigger>
              <TabsTrigger value="specifications">{translations.specifications}</TabsTrigger>
              <TabsTrigger value="reviews">{translations.reviews}</TabsTrigger>
            </TabsList>

            <TabsContent value="features" className="mt-6">
              <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
                <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">
                  {translations.productFeatures}
                </h3>
                <ul className="space-y-2">
                  {getProductFeatures(product, language).map((feature: string, index: number) => (
                    <li key={index} className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-red-600 rounded-full"></div>
                      <span className="text-gray-700 dark:text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </TabsContent>

            <TabsContent value="specifications" className="mt-6">
              <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
                <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">
                  {translations.technicalSpecs}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Object.entries(getProductSpecs(product, language)).map(([key, value]) => (
                    <div key={key} className="flex justify-between py-2 border-b border-gray-200 dark:border-gray-700">
                      <span className="font-medium text-gray-900 dark:text-white">{key}:</span>
                      <span className="text-gray-600 dark:text-gray-400">300</span>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="reviews" className="mt-6">
              <div className="bg-white dark:bg-gray-800 rounded-lg p-6">
                <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">
                  {translations.customerReviews}
                </h3>
                <div className="text-center py-8">
                  <p className="text-gray-600 dark:text-gray-400">{translations.reviews}</p>
                  <Button className="mt-4 bg-red-600 hover:bg-red-700 text-white">{translations.writeReview}</Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </motion.div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.7 }}
            className="mt-16"
          >
            <h2 className="text-2xl font-bold mb-8 text-gray-900 dark:text-white">{translations.relatedProducts}</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((relatedProduct) => (
                <div
                  key={relatedProduct.id}
                  className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="relative aspect-square mb-4">
                    <Image
                      src={relatedProduct.image || ""}
                      alt={getProductField(relatedProduct, "name", language)}
                      fill
                      className="object-contain rounded-lg"
                    />
                  </div>
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-2 line-clamp-2">
                    {getProductField(relatedProduct, "name", language)}
                  </h3>
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-bold text-red-600">${relatedProduct.price}</span>
                    <Button size="sm" variant="outline" asChild>
                      <a href={`/product/${relatedProduct.id}`}>{translations.view}</a>
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  )
}
