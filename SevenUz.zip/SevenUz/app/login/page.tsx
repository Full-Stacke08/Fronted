"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { Eye, EyeOff, Lock, Phone, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import Link from "next/link"
import { useAuth } from "@/components/auth-provider"
import { useToast } from "@/hooks/use-toast"

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [loginMethod, setLoginMethod] = useState<"email" | "phone">("email")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [password, setPassword] = useState("")
  const [firstName, setFirstName] = useState("")
  const [lastName, setLastName] = useState("")
  const [rememberMe, setRememberMe] = useState(false)

  const router = useRouter()
  const { login, register, loginError, registerError } = useAuth()
  const { toast } = useToast()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    console.log("🔐 Login form submitted")
    setIsLoading(true)

    try {
      const result = await login(
        loginMethod === "email" ? email.trim() : undefined,
        loginMethod === "phone" ? phone.trim() : undefined,
        password.trim(),
      )

      console.log("🔐 Login result:", result)

      if (result.success) {
        toast({
          title: "Muvaffaqiyatli kirish!",
          description: "Hisobingizga muvaffaqiyatli kirdingiz",
          duration: 3000,
        })

        // Check if admin
        const currentUser = JSON.parse(localStorage.getItem("sevenuz_currentUser") || "{}")
        if (currentUser.isAdmin) {
          console.log("👑 Redirecting admin to dashboard")
          router.push("/admin/dashboard")
        } else {
          console.log("👤 Redirecting user to profile")
          router.push("/profile")
        }
      } else {
        toast({
          title: "Kirish xatosi",
          description: result.message,
          variant: "destructive",
          duration: 5000,
        })
      }
    } catch (err) {
      console.error("❌ Login error:", err)
      toast({
        title: "Xatolik",
        description: "Kirishda xatolik yuz berdi",
        variant: "destructive",
        duration: 5000,
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    console.log("📝 Register form submitted")
    setIsLoading(true)

    try {
      const result = await register({
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        email: loginMethod === "email" ? email.trim() : undefined,
        phone: loginMethod === "phone" ? phone.trim() : undefined,
        password: password.trim(),
      })

      console.log("📝 Register result:", result)

      if (result.success) {
        toast({
          title: "Muvaffaqiyatli ro'yxatdan o'tish!",
          description: "Hisobingiz muvaffaqiyatli yaratildi",
          duration: 3000,
        })
        router.push("/profile")
      } else {
        toast({
          title: "Ro'yxatdan o'tish xatosi",
          description: result.message,
          variant: "destructive",
          duration: 5000,
        })
      }
    } catch (err) {
      console.error("❌ Register error:", err)
      toast({
        title: "Xatolik",
        description: "Ro'yxatdan o'tishda xatolik yuz berdi",
        variant: "destructive",
        duration: 5000,
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen w-full overflow-x-hidden flex items-center justify-center bg-gray-50 dark:bg-gray-900 px-4 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-md w-full space-y-8 bg-white dark:bg-gray-800 p-8 rounded-xl shadow-lg"
      >
        <Tabs defaultValue="login" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="login">Kirish</TabsTrigger>
            <TabsTrigger value="register">Ro'yxatdan o'tish</TabsTrigger>
          </TabsList>

          <TabsContent value="login">
            <div className="text-center">
              <motion.h2
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2, duration: 0.5 }}
                className="mt-2 text-3xl font-extrabold text-gray-900 dark:text-white"
              >
                Hisobingizga kiring
              </motion.h2>
            </div>

            <motion.form
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="mt-8 space-y-6"
              onSubmit={handleLogin}
            >
              <div className="space-y-4">
                <div className="flex justify-center mb-4">
                  <div className="inline-flex rounded-md shadow-sm" role="group">
                    <button
                      type="button"
                      onClick={() => setLoginMethod("email")}
                      className={`px-4 py-2 text-sm font-medium rounded-l-lg border ${
                        loginMethod === "email"
                          ? "bg-red-600 text-white border-red-600"
                          : "bg-white text-gray-700 border-gray-300 hover:bg-gray-100 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:hover:bg-gray-600"
                      }`}
                    >
                      <Mail className="h-4 w-4 inline mr-1" /> Email
                    </button>
                    <button
                      type="button"
                      onClick={() => setLoginMethod("phone")}
                      className={`px-4 py-2 text-sm font-medium rounded-r-lg border-t border-r border-b ${
                        loginMethod === "phone"
                          ? "bg-red-600 text-white border-red-600"
                          : "bg-white text-gray-700 border-gray-300 hover:bg-gray-100 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:hover:bg-gray-600"
                      }`}
                    >
                      <Phone className="h-4 w-4 inline mr-1" /> Telefon
                    </button>
                  </div>
                </div>

                {loginMethod === "email" ? (
                  <div>
                    <Label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Email manzili
                    </Label>
                    <div className="mt-1 relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Mail className="h-5 w-5 text-gray-400" />
                      </div>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        autoComplete="email"
                        className="pl-10 focus:ring-red-500 focus:border-red-500"
                        placeholder="Email manzilingiz"
                        required
                      />
                    </div>
                  </div>
                ) : (
                  <div>
                    <Label htmlFor="phone" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Telefon raqami
                    </Label>
                    <div className="mt-1 relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Phone className="h-5 w-5 text-gray-400" />
                      </div>
                      <Input
                        id="phone"
                        name="phone"
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        autoComplete="tel"
                        className="pl-10 focus:ring-red-500 focus:border-red-500"
                        placeholder="+998 90 123 45 67"
                        required
                      />
                    </div>
                  </div>
                )}

                <div>
                  <Label htmlFor="password" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Parol
                  </Label>
                  <div className="mt-1 relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Lock className="h-5 w-5 text-gray-400" />
                    </div>
                    <Input
                      id="password"
                      name="password"
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      autoComplete="current-password"
                      className="pl-10 focus:ring-red-500 focus:border-red-500"
                      placeholder="Parolingiz"
                      required
                    />
                    <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="text-gray-400 hover:text-gray-500 focus:outline-none"
                      >
                        {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {loginError && (
                <Alert variant="destructive">
                  <AlertDescription>{loginError}</AlertDescription>
                </Alert>
              )}

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Checkbox
                    id="remember-me"
                    checked={rememberMe}
                    onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                  />
                  <Label htmlFor="remember-me" className="ml-2 block text-sm text-gray-900 dark:text-gray-300">
                    Meni eslab qolish
                  </Label>
                </div>

                <div className="text-sm">
                  <Link href="/forgot-password" className="font-medium text-red-600 hover:text-red-500">
                    Parolni unutdingizmi?
                  </Link>
                </div>
              </div>

              <div>
                <Button type="submit" className="w-full bg-red-600 hover:bg-red-700 text-white" disabled={isLoading}>
                  {isLoading ? (
                    <div className="flex items-center justify-center">
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                      <span>Kirish...</span>
                    </div>
                  ) : (
                    "Kirish"
                  )}
                </Button>
              </div>

              {/* Test Accounts Info */}
             
            </motion.form>
          </TabsContent>

          <TabsContent value="register">
            <div className="text-center">
              <motion.h2
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2, duration: 0.5 }}
                className="mt-2 text-3xl font-extrabold text-gray-900 dark:text-white"
              >
                Ro'yxatdan o'tish
              </motion.h2>
            </div>

            <motion.form
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="mt-8 space-y-6"
              onSubmit={handleRegister}
            >
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Ism
                    </Label>
                    <Input
                      id="firstName"
                      name="firstName"
                      type="text"
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      autoComplete="given-name"
                      className="focus:ring-red-500 focus:border-red-500"
                      placeholder="Ismingiz"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="lastName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Familiya
                    </Label>
                    <Input
                      id="lastName"
                      name="lastName"
                      type="text"
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                      autoComplete="family-name"
                      className="focus:ring-red-500 focus:border-red-500"
                      placeholder="Familiyangiz"
                    />
                  </div>
                </div>

                <div className="flex justify-center mb-4">
                  <div className="inline-flex rounded-md shadow-sm" role="group">
                    <button
                      type="button"
                      onClick={() => setLoginMethod("email")}
                      className={`px-4 py-2 text-sm font-medium rounded-l-lg border ${
                        loginMethod === "email"
                          ? "bg-red-600 text-white border-red-600"
                          : "bg-white text-gray-700 border-gray-300 hover:bg-gray-100 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:hover:bg-gray-600"
                      }`}
                    >
                      <Mail className="h-4 w-4 inline mr-1" /> Email
                    </button>
                    <button
                      type="button"
                      onClick={() => setLoginMethod("phone")}
                      className={`px-4 py-2 text-sm font-medium rounded-r-lg border-t border-r border-b ${
                        loginMethod === "phone"
                          ? "bg-red-600 text-white border-red-600"
                          : "bg-white text-gray-700 border-gray-300 hover:bg-gray-100 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:hover:bg-gray-600"
                      }`}
                    >
                      <Phone className="h-4 w-4 inline mr-1" /> Telefon
                    </button>
                  </div>
                </div>

                {loginMethod === "email" ? (
                  <div>
                    <Label
                      htmlFor="register-email"
                      className="block text-sm font-medium text-gray-700 dark:text-gray-300"
                    >
                      Email manzili
                    </Label>
                    <div className="mt-1 relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Mail className="h-5 w-5 text-gray-400" />
                      </div>
                      <Input
                        id="register-email"
                        name="email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        autoComplete="email"
                        className="pl-10 focus:ring-red-500 focus:border-red-500"
                        placeholder="Email manzilingiz"
                        required
                      />
                    </div>
                  </div>
                ) : (
                  <div>
                    <Label
                      htmlFor="register-phone"
                      className="block text-sm font-medium text-gray-700 dark:text-gray-300"
                    >
                      Telefon raqami
                    </Label>
                    <div className="mt-1 relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Phone className="h-5 w-5 text-gray-400" />
                      </div>
                      <Input
                        id="register-phone"
                        name="phone"
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        autoComplete="tel"
                        className="pl-10 focus:ring-red-500 focus:border-red-500"
                        placeholder="+998 90 123 45 67"
                        required
                      />
                    </div>
                  </div>
                )}

                <div>
                  <Label
                    htmlFor="register-password"
                    className="block text-sm font-medium text-gray-700 dark:text-gray-300"
                  >
                    Parol
                  </Label>
                  <div className="mt-1 relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Lock className="h-5 w-5 text-gray-400" />
                    </div>
                    <Input
                      id="register-password"
                      name="password"
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      autoComplete="new-password"
                      className="pl-10 focus:ring-red-500 focus:border-red-500"
                      placeholder="Parolingiz (kamida 3 ta belgi)"
                      required
                      minLength={3}
                    />
                    <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="text-gray-400 hover:text-gray-500 focus:outline-none"
                      >
                        {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {registerError && (
                <Alert variant="destructive">
                  <AlertDescription>{registerError}</AlertDescription>
                </Alert>
              )}

              <div className="flex items-center">
                <Checkbox id="terms" required />
                <Label htmlFor="terms" className="ml-2 block text-sm text-gray-900 dark:text-gray-300">
                  Men{" "}
                  <Link href="/terms" className="text-red-600 hover:text-red-500">
                    foydalanish shartlari
                  </Link>{" "}
                  va{" "}
                  <Link href="/privacy" className="text-red-600 hover:text-red-500">
                    maxfiylik siyosati
                  </Link>{" "}
                  bilan tanishdim va roziman
                </Label>
              </div>

              <div>
                <Button type="submit" className="w-full bg-red-600 hover:bg-red-700 text-white" disabled={isLoading}>
                  {isLoading ? (
                    <div className="flex items-center justify-center">
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                      <span>Ro'yxatdan o'tish...</span>
                    </div>
                  ) : (
                    "Ro'yxatdan o'tish"
                  )}
                </Button>
              </div>
            </motion.form>
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  )
}
