"use client"

import { useState, useEffect, useMemo } from "react"
import Link from "next/link"
import { ShoppingCart, Filter, ChevronDown, ChevronUp, Check, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { useCart } from "@/components/cart-provider"
import { useParams } from "next/navigation"
import { getProductsByCategory, categories } from "@/lib/categories/index"
import { useToast } from "@/hooks/use-toast"
import { motion, AnimatePresence } from "framer-motion"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useLanguage } from "@/hooks/use-language"

export default function CategoryPage() {
  const params = useParams()
  const slug = params.slug as string
  const { addToCart } = useCart()
  const { toast } = useToast()
  const { translations, language } = useLanguage()

  // Function to get the correct category name based on language
  const getCategoryName = (category: any) => {
    if (language === "uz") {
      return category.nameUz || category.name
    } else if (language === "ru") {
      return category.nameRu || category.name
    } else {
      return category.name
    }
  }

  // Find the current category
  const currentCategory = useMemo(() => categories.find((cat) => cat.slug === slug || cat.id === slug), [slug])

  // Get products for this category
  const categoryProducts = useMemo(() => {
    const products = getProductsByCategory(slug)
    console.log("Products for category:", slug, products)
    return products
  }, [slug])

  // Calculate max price only once when products change
  const maxPrice = useMemo(() => Math.max(...categoryProducts.map((p) => p.price), 1000), [categoryProducts])

  const [priceRange, setPriceRange] = useState<[number, number]>([0, maxPrice])
  const [selectedMemories, setSelectedMemories] = useState<string[]>([])
  const [selectedColors, setSelectedColors] = useState<string[]>([])
  const [selectedBrands, setSelectedBrands] = useState<string[]>([])
  const [selectedConditions, setSelectedConditions] = useState<string[]>([])
  const [filteredProducts, setFilteredProducts] = useState(categoryProducts)
  const [showFilters, setShowFilters] = useState(false)
  const [sortBy, setSortBy] = useState<string>("price-asc")
  const [viewMode, setViewMode] = useState<string>("grid")
  const [addedProducts, setAddedProducts] = useState<{ [key: string]: boolean }>({})

  // Initialize price range only when category changes
  useEffect(() => {
    setPriceRange([0, maxPrice])
  }, [slug, maxPrice])

  // Update filtered products when category changes
  useEffect(() => {
    setFilteredProducts(categoryProducts)
  }, [categoryProducts])

  // Get unique colors
  const colors = useMemo(() => {
    const colorSet = new Set<string>()
    categoryProducts.forEach((product) => {
      if (product.color) colorSet.add(product.color)
      if (product.colorUz) colorSet.add(product.colorUz)
    })
    return Array.from(colorSet)
  }, [categoryProducts])

  // Get unique brands (extracted from product names)
  const brands = useMemo(() => {
    const brandSet = new Set<string>()
    categoryProducts.forEach((product) => {
      const nameParts = product.name.split(" ")
      if (nameParts.length > 0) {
        brandSet.add(nameParts[0])
      }
    })
    return Array.from(brandSet)
  }, [categoryProducts])

  // Get unique memory options
  const memories = useMemo(() => {
    const memorySet = new Set<string>()
    categoryProducts.forEach((product) => {
      if (product.memory) memorySet.add(product.memory)
    })
    return Array.from(memorySet)
  }, [categoryProducts])

  // Filter and sort products based on selected filters
  useEffect(() => {
    let filtered = [...categoryProducts]

    // Filter by price
    filtered = filtered.filter((product) => product.price >= priceRange[0] && product.price <= priceRange[1])

    // Filter by memory
    if (selectedMemories.length > 0) {
      filtered = filtered.filter((product) => selectedMemories.includes(product.memory || ""))
    }

    // Filter by color
    if (selectedColors.length > 0) {
      filtered = filtered.filter(
        (product) => selectedColors.includes(product.color || "") || selectedColors.includes(product.colorUz || ""),
      )
    }

    // Filter by brand
    if (selectedBrands.length > 0) {
      filtered = filtered.filter((product) => {
        const productBrand = product.name.split(" ")[0]
        return selectedBrands.includes(productBrand)
      })
    }

    // Sort products
    if (sortBy === "price-asc") {
      filtered.sort((a, b) => a.price - b.price)
    } else if (sortBy === "price-desc") {
      filtered.sort((a, b) => b.price - a.price)
    } else if (sortBy === "name-asc") {
      filtered.sort((a, b) => a.name.localeCompare(b.name))
    } else if (sortBy === "name-desc") {
      filtered.sort((a, b) => b.name.localeCompare(a.name))
    } else if (sortBy === "rating-desc") {
      filtered.sort((a, b) => (b.rating || 0) - (a.rating || 0))
    }

    setFilteredProducts(filtered)
  }, [categoryProducts, priceRange, selectedMemories, selectedColors, selectedBrands, sortBy])

  // Toggle memory selection
  const toggleMemory = (memory: string) => {
    setSelectedMemories((prev) => (prev.includes(memory) ? prev.filter((m) => m !== memory) : [...prev, memory]))
  }

  // Toggle color selection
  const toggleColor = (color: string) => {
    setSelectedColors((prev) => (prev.includes(color) ? prev.filter((c) => c !== color) : [...prev, color]))
  }

  // Toggle brand selection
  const toggleBrand = (brand: string) => {
    setSelectedBrands((prev) => (prev.includes(brand) ? prev.filter((b) => b !== brand) : [...prev, brand]))
  }

  // Handle add to cart
  const handleAddToCart = (product: any) => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      quantity: 1,
      image: product.image,
    })

    // Show animation
    setAddedProducts((prev) => ({ ...prev, [product.id]: true }))

    // Reset after animation
    setTimeout(() => {
      setAddedProducts((prev) => ({ ...prev, [product.id]: false }))
    }, 1500)

    // Show toast notification
    toast({
      title: language === "uz" ? "Savatga qo'shildi" : language === "ru" ? "Добавлено в корзину" : "Added to cart",
      description:
        language === "uz"
          ? `${product.name} savatga qo'shildi`
          : language === "ru"
            ? `${product.name} добавлен в корзину`
            : `${product.name} added to cart`,
      duration: 3000,
    })
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Category Header */}
      <div className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            {currentCategory ? getCategoryName(currentCategory) : translations.noProducts}
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            {filteredProducts.length} {translations.productsAvailable}
          </p>
        </div>
      </div>

      {/* Categories Navigation */}
      <div className="bg-gray-100 dark:bg-gray-850 py-3 border-b border-gray-200 dark:border-gray-700">
        <div className="container mx-auto px-4">
          <div className="flex overflow-x-auto gap-4 pb-2 scrollbar-hide">
            {categories.map((category) => (
              <Link
                key={category.id}
                href={`/category/${category.slug}`}
                className={`whitespace-nowrap px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  category.slug === slug
                    ? "bg-red-600 text-white"
                    : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700"
                }`}
              >
                {getCategoryName(category)}
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* Mobile Filter Toggle */}
      <div className="md:hidden container mx-auto px-4 py-3">
        <Button
          variant="outline"
          className="w-full flex items-center justify-between"
          onClick={() => setShowFilters(!showFilters)}
        >
          <div className="flex items-center">
            <Filter className="h-4 w-4 mr-2" />
            <span>{translations.filters}</span>
          </div>
          {showFilters ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </Button>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Filters Sidebar */}
          <aside className={`md:w-1/4 lg:w-1/5 ${showFilters ? "block" : "hidden"} md:block`}>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 sticky top-4">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">{translations.filters}</h2>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setPriceRange([0, maxPrice])
                    setSelectedMemories([])
                    setSelectedColors([])
                    setSelectedBrands([])
                    setSelectedConditions([])
                    setSortBy("price-asc")
                  }}
                  className="text-xs text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                >
                  {translations.resetFilters}
                </Button>
              </div>

              
             

              {/* Price Range Filter */}
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">{translations.priceRange}</h3>
                <Slider
                  max={maxPrice}
                  step={50}
                  value={priceRange}
                  onValueChange={(value) => setPriceRange(value as [number, number])}
                  className="mb-2"
                />
                <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400">
                  <span>${priceRange[0]}</span>
                  <span>${priceRange[1]}</span>
                </div>
              </div>

              {/* Brand Filter */}
              {brands.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">{translations.brand}</h3>
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-2">
                    {brands.map((brand) => (
                      <div key={brand} className="flex items-center">
                        <Checkbox
                          id={`brand-${brand}`}
                          checked={selectedBrands.includes(brand)}
                          onCheckedChange={() => toggleBrand(brand)}
                        />
                        <label
                          htmlFor={`brand-${brand}`}
                          className="ml-2 text-sm text-gray-600 dark:text-gray-400 cursor-pointer"
                        >
                          {brand}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Memory Filter */}
              {memories.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">{translations.memory}</h3>
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-2">
                    {memories.map((memory) => (
                      <div key={memory} className="flex items-center">
                        <Checkbox
                          id={`memory-${memory}`}
                          checked={selectedMemories.includes(memory)}
                          onCheckedChange={() => toggleMemory(memory)}
                        />
                        <label
                          htmlFor={`memory-${memory}`}
                          className="ml-2 text-sm text-gray-600 dark:text-gray-400 cursor-pointer"
                        >
                          {memory}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Color Filter */}
              {colors.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">{translations.color}</h3>
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-2">
                    {colors.map((color) => (
                      <div key={color} className="flex items-center">
                        <Checkbox
                          id={`color-${color}`}
                          checked={selectedColors.includes(color)}
                          onCheckedChange={() => toggleColor(color)}
                        />
                        <label
                          htmlFor={`color-${color}`}
                          className="ml-2 text-sm text-gray-600 dark:text-gray-400 cursor-pointer"
                        >
                          {color}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </aside>

          {/* Products Grid */}
          <div className="md:w-3/4 lg:w-4/5">
            {/* Top Bar with Sort and View Options */}
            <div className="bg-white dark:bg-gray-800 p-4 rounded-lg   mb-4 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center">
                <span className="text-sm text-gray-600 dark:text-gray-400 mr-2">{translations.sortBy}:</span>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder={translations.sortBy} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="price-asc">{translations.priceLowToHigh}</SelectItem>
                    <SelectItem value="price-desc">{translations.priceHighToLow}</SelectItem>
                    <SelectItem value="name-asc">{translations.nameAtoZ}</SelectItem>
                    <SelectItem value="name-desc">{translations.nameZtoA}</SelectItem>
                    <SelectItem value="rating-desc">
                      {language === "uz"
                        ? "Reyting: yuqoridan pastga"
                        : language === "ru"
                          ? "Рейтинг: по убыванию"
                          : "Rating: High to Low"}
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  {language === "uz" ? "Ko'rinish" : language === "ru" ? "Вид" : "View"}:
                </span>
                <div className="flex gap-1">
                  <Button
                    variant={viewMode === "grid" ? "default" : "outline"}
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => setViewMode("grid")}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <rect width="7" height="7" x="3" y="3" rx="1" />
                      <rect width="7" height="7" x="14" y="3" rx="1" />
                      <rect width="7" height="7" x="14" y="14" rx="1" />
                      <rect width="7" height="7" x="3" y="14" rx="1" />
                    </svg>
                  </Button>
                  <Button
                    variant={viewMode === "list" ? "default" : "outline"}
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => setViewMode("list")}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <line x1="8" x2="21" y1="6" y2="6" />
                      <line x1="8" x2="21" y1="12" y2="12" />
                      <line x1="8" x2="21" y1="18" y2="18" />
                      <line x1="3" x2="3" y1="6" y2="6" />
                      <line x1="3" x2="3" y1="12" y2="12" />
                      <line x1="3" x2="3" y1="18" y2="18" />
                    </svg>
                  </Button>
                </div>
              </div>
            </div>

            {filteredProducts.length > 0 ? (
              <>
                {viewMode === "grid" ? (
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {filteredProducts.map((product, index) => (
                      <motion.div
                        key={product.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.05 }}
                        className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300"
                      >
                          <div className="relative h-48 bg-gray-100 dark:bg-gray-700">
                            <img
                              src={product.image || "/placeholder.svg?height=200&width=200"}
                              alt={product.name}
                              className="object-contain w-full h-full p-2"
                            />
                            {product.oldPrice && (
                              <div className="absolute top-2 right-2 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded">
                                {language === "uz" ? "Chegirma" : language === "ru" ? "Скидка" : "Sale"}
                              </div>
                            )}
                          </div>

                        <div className="p-4">
                          <div className="flex items-center mb-1">
                            <div className="flex">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  className={`h-3 w-3 ${
                                    i < Math.floor(product.rating || 0)
                                      ? "text-yellow-400 fill-current"
                                      : "text-gray-300 dark:text-gray-600"
                                  }`}
                                />
                              ))}
                            </div>
                            <span className="text-xs text-gray-600 dark:text-gray-400 ml-1">{product.rating}</span>
                          </div>

                          <Link href={`/product/${product.id}`} className="block">
                            <h3 className="font-medium text-gray-900 dark:text-white mb-1 hover:text-red-600 dark:hover:text-red-400 transition-colors">
                              {language === "uz" && product.nameUz
                                ? product.nameUz
                                : language === "ru" && product.nameRu
                                  ? product.nameRu
                                  : product.name}
                            </h3>
                          </Link>

                          <div className="flex flex-wrap gap-1 mb-3">
                            {product.memory && (
                              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300">
                                {product.memory}
                              </span>
                            )}
                            {product.color && (
                              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300">
                                {language === "uz" && product.colorUz
                                  ? product.colorUz
                                  : language === "ru" && product.colorRu
                                    ? product.colorRu
                                    : product.color}
                              </span>
                            )}
                          </div>

                          <div className="flex items-center justify-between">
                            <div>
                              <span className="font-bold text-lg text-red-600 dark:text-red-400">${product.price}</span>
                              {product.oldPrice && (
                                <span className="text-sm text-gray-500 dark:text-gray-400 line-through ml-2">
                                  ${product.oldPrice}
                                </span>
                              )}
                            </div>
                            <AnimatePresence>
                              {addedProducts[product.id] ? (
                                <motion.div
                                  initial={{ scale: 0.8, opacity: 0 }}
                                  animate={{ scale: 1, opacity: 1 }}
                                  exit={{ scale: 0.8, opacity: 0 }}
                                  className="bg-green-600 text-white rounded-md px-3 py-1 flex items-center"
                                >
                                  <Check className="h-4 w-4 mr-1" />
                                  <span className="text-xs">
                                    {language === "uz" ? "Qo'shildi" : language === "ru" ? "Добавлено" : "Added"}
                                  </span>
                                </motion.div>
                              ) : (
                                <motion.div
                                  initial={{ scale: 0.8, opacity: 0 }}
                                  animate={{ scale: 1, opacity: 1 }}
                                  exit={{ scale: 0.8, opacity: 0 }}
                                >
                                                              <Button
                              size="sm"
                              onClick={() => handleAddToCart(product)}
                              className="bg-red-600 hover:bg-red-700 text-white flex items-center"
                            >
                              <ShoppingCart className="h-4 w-4" />
                              <span className="hidden lg:inline lg:ml-2">
                                {language === "uz" ? "Savatga" : language === "ru" ? "В корзину" : "Add"}
                              </span>
                            </Button>

                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {filteredProducts.map((product, index) => (
                      <motion.div
                        key={product.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.05 }}
                        className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300"
                      >
                        <div className="flex flex-col md:flex-row">
                          <Link href={`/product/${product.id}`} className="block md:w-1/4">
                            <div className="relative h-48 md:h-full bg-gray-100 dark:bg-gray-700">
                              <img
                                src={product.image || "/placeholder.svg?height=200&width=200"}
                                alt={product.name}
                                className="object-contain w-full h-full p-2"
                              />
                              {product.oldPrice && (
                                <div className="absolute top-2 right-2 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded">
                                  {language === "uz" ? "Chegirma" : language === "ru" ? "Скидка" : "Sale"}
                                </div>
                              )}
                            </div>
                          </Link>

                          <div className="p-4 md:w-3/4">
                            <div className="flex items-center mb-1">
                              <div className="flex">
                                {[...Array(5)].map((_, i) => (
                                  <Star
                                    key={i}
                                    className={`h-3 w-3 ${
                                      i < Math.floor(product.rating || 0)
                                        ? "text-yellow-400 fill-current"
                                        : "text-gray-300 dark:text-gray-600"
                                    }`}
                                  />
                                ))}
                              </div>
                              <span className="text-xs text-gray-600 dark:text-gray-400 ml-1">{product.rating}</span>
                            </div>

                            <Link href={`/product/${product.id}`} className="block">
                              <h3 className="font-medium text-gray-900 dark:text-white mb-1 hover:text-red-600 dark:hover:text-red-400 transition-colors">
                                {language === "uz" && product.nameUz
                                  ? product.nameUz
                                  : language === "ru" && product.nameRu
                                    ? product.nameRu
                                    : product.name}
                              </h3>
                            </Link>

                            <p className="text-sm text-gray-600 dark:text-gray-400 mb-3 line-clamp-2">
                              {language === "uz" && product.descriptionUz
                                ? product.descriptionUz
                                : language === "ru" && product.descriptionRu
                                  ? product.descriptionRu
                                  : product.description}
                            </p>

                            <div className="flex flex-wrap gap-1 mb-3">
                              {product.memory && (
                                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300">
                                  {product.memory}
                                </span>
                              )}
                              {product.color && (
                                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300">
                                  {language === "uz" && product.colorUz
                                    ? product.colorUz
                                    : language === "ru" && product.colorRu
                                      ? product.colorRu
                                      : product.color}
                                </span>
                              )}
                            </div>

                            <div className="flex items-center justify-between">
                              <div>
                                <span className="font-bold text-lg text-red-600 dark:text-red-400">
                                  ${product.price}
                                </span>
                                {product.oldPrice && (
                                  <span className="text-sm text-gray-500 dark:text-gray-400 line-through ml-2">
                                    ${product.oldPrice}
                                  </span>
                                )}
                              </div>
                              <AnimatePresence>
                                {addedProducts[product.id] ? (
                                  <motion.div
                                    initial={{ scale: 0.8, opacity: 0 }}
                                    animate={{ scale: 1, opacity: 1 }}
                                    exit={{ scale: 0.8, opacity: 0 }}
                                    className="bg-green-600 text-white rounded-md px-3 py-1 flex items-center"
                                  >
                                    <Check className="h-4 w-4 mr-1" />
                                    <span className="text-xs">
                                      {language === "uz" ? "Qo'shildi" : language === "ru" ? "Добавлено" : "Added"}
                                    </span>
                                  </motion.div>
                                ) : (
                                  <motion.div
                                    initial={{ scale: 0.8, opacity: 0 }}
                                    animate={{ scale: 1, opacity: 1 }}
                                    exit={{ scale: 0.8, opacity: 0 }}
                                  >
                                    <Button
                                      size="sm"
                                      onClick={() => handleAddToCart(product)}
                                      className="bg-red-600 hover:bg-red-700 text-white"
                                    >
                                      <ShoppingCart className="h-4 w-4 mr-1" />
                                      {language === "uz" ? "Savatg" : language === "ru" ? "В корзину" : "Add"}
                                    </Button>
                                  </motion.div>
                                )}
                              </AnimatePresence>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </>
            ) : (
              <div className="bg-white dark:bg-gray-800 rounded-lg p-8 text-center">
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">{translations.noProducts}</h3>
                <p className="text-gray-600 dark:text-gray-400">{translations.tryOtherFilters}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
