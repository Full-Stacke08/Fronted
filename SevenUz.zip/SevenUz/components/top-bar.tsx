"use client"
import { Phone, MapPin, Moon, Sun } from "lucide-react"
import { useLanguage } from "./language-provider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Link from "next/link"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { useEffect, useState } from "react"

export default function TopBar() {
  const { language, setLanguage, translations } = useLanguage()
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const handleLanguageChange = (value: string) => {
    setLanguage(value as "uz" | "ru" | "en")
  }

  if (!mounted) {
    return null
  }

  return (
    <div className="dark:bg-red-600  bg-gray-600 flex text-white py-0.5 text-sm">
      <div className="container mx-auto px-4">
        <div className="flex flex-wrap items-center justify-between">
          <div className="flex items-center space-x-4 md:space-x-6">
            <div className="flex items-center">
              <Phone className="h-3 w-3 mr-1.5 text-red-500" />
              <span>+998 98 777 11 33 </span>
            </div>
            <div className="hidden sm:flex items-center">
              <MapPin className="h-3 w-3 mr-1.5 text-red-500" />
              <span>{translations.address}</span>
            </div>
           <Link
  href="/company"
  className="hidden lg:inline md:inline text-white hover:text-gray-900 transition-colors"
>
  {translations.aboutCompany}
</Link>

          </div>

          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === "light" ? "dark" : "light")}
              className="p-1 rounded-full hover:bg-gray-800 hover:text-white transition-colors"
              aria-label={theme === "light" ? "Switch to dark mode" : "Switch to light mode"}
            >
              {theme === "light" ? (
                <Moon className="h-4 w-4" />
              ) : (
                <Sun className="h-4 w-4" />
              )}
            </Button>
            <Select value={language} onValueChange={handleLanguageChange}>
              <SelectTrigger className="w-[7] h-7 bg-transparent border-gray-700 text-white text-xs">
                <SelectValue placeholder={language.toUpperCase()} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="uz">uz</SelectItem>
                <SelectItem value="ru">ru</SelectItem>
                <SelectItem value="en">en</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
    </div>
  )
}
