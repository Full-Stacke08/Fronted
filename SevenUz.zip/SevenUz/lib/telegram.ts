// Telegram Bot Integration Service
interface TelegramMessage {
  chat_id: string | number
  text: string
  parse_mode: "HTML" | "MarkdownV2"
}

export interface OrderDetails {
  orderId: string
  customerName: string
  customerPhone: string
  customerEmail?: string
  products: {
    id: string
    name: string
    price: number
    quantity: number
    image?: string
  }[]
  totalPrice: number
  deliveryMethod: "pickup" | "courier"
  paymentMethod: "installment" | "cash" | "card"
  installmentMonths?: number
  address?: string
  additionalInfo?: string
}

// Bot tokens
const INSTALLMENT_BOT_TOKEN = "7980520509:AAFu7tzSlQ911THkQ7l6m4lS9lqN-2GFJ70"
const CASH_PICKUP_BOT_TOKEN = "7714658713:AAEnhoQW5SdOj7nhNVl9D0FzWn5jx5HsU78"
const ADMIN_CHAT_ID = "6866842284"

// Format currency
const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat("uz-UZ", {
    style: "currency",
    currency: "UZS",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}

// Create HTML message for Telegram
const createOrderMessage = (order: OrderDetails): string => {
  const isInstallment = order.paymentMethod === "installment"

  let message = `<b>🛒 NEW ORDER #${order.orderId}</b>\n\n`
  message += `<b>👤 Customer:</b> ${order.customerName}\n`
  message += `<b>📞 Phone:</b> ${order.customerPhone}\n`

  if (order.customerEmail) {
    message += `<b>📧 Email:</b> ${order.customerEmail}\n`
  }

  message += `\n<b>🚚 Delivery:</b> ${order.deliveryMethod === "pickup" ? "Pickup from store" : "Courier delivery"}\n`

  if (order.deliveryMethod === "courier" && order.address) {
    message += `<b>📍 Address:</b> ${order.address}\n`
  }

  message += `<b>💰 Payment:</b> ${
    order.paymentMethod === "installment"
      ? `Installment (${order.installmentMonths} months)`
      : order.paymentMethod === "cash"
        ? "Cash on delivery/pickup"
        : "Card payment"
  }\n\n`

  message += `<b>📦 Products:</b>\n`

  order.products.forEach((product, index) => {
    message += `${index + 1}. ${product.name} x${product.quantity} - ${formatCurrency(product.price * product.quantity)}\n`
  })

  message += `\n<b>💵 Total:</b> ${formatCurrency(order.totalPrice)}`

  if (isInstallment && order.installmentMonths) {
    const monthlyPayment = (order.totalPrice * 1.15) / order.installmentMonths
    message += `\n<b>📅 Monthly payment:</b> ${formatCurrency(monthlyPayment)} (15% interest)`
  }

  if (order.additionalInfo) {
    message += `\n\n<b>📝 Additional info:</b> ${order.additionalInfo}`
  }

  return message
}

// Send message to Telegram
export const sendOrderToTelegram = async (order: OrderDetails): Promise<boolean> => {
  try {
    const isInstallment = order.paymentMethod === "installment"
    const token = isInstallment ? INSTALLMENT_BOT_TOKEN : CASH_PICKUP_BOT_TOKEN

    const message: TelegramMessage = {
      chat_id: ADMIN_CHAT_ID,
      text: createOrderMessage(order),
      parse_mode: "HTML",
    }

    // For installment orders, add inline keyboard for confirmation
    let inlineKeyboard = null
    if (isInstallment) {
      inlineKeyboard = {
        inline_keyboard: [
          [
            { text: "✅ Approve", callback_data: `approve_${order.orderId}` },
            { text: "❌ Reject", callback_data: `reject_${order.orderId}` },
          ],
        ],
      }
    }

    const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        ...message,
        ...(inlineKeyboard && { reply_markup: JSON.stringify(inlineKeyboard) }),
      }),
    })

    const data = await response.json()
    return data.ok
  } catch (error) {
    console.error("Error sending Telegram notification:", error)
    return false
  }
}

// Handle Telegram webhook for bot responses
export const handleTelegramWebhook = async (req: Request): Promise<Response> => {
  try {
    const data = await req.json()

    // Handle callback queries (button clicks)
    if (data.callback_query) {
      const { callback_query } = data
      const { data: callbackData, message } = callback_query

      // Extract order ID and action
      const [action, orderId] = callbackData.split("_")

      if (action === "approve" || action === "reject") {
        // Update order status in database
        await updateOrderStatus(orderId, action === "approve" ? "confirmed" : "rejected")

        // Send notification to customer
        if (action === "approve") {
          await sendCustomerNotification(orderId)
        }

        // Update the Telegram message to remove buttons
        await fetch(`https://api.telegram.org/bot${INSTALLMENT_BOT_TOKEN}/editMessageReplyMarkup`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            chat_id: message.chat.id,
            message_id: message.message_id,
            reply_markup: JSON.stringify({ inline_keyboard: [] }),
          }),
        })

        // Send confirmation message
        await fetch(`https://api.telegram.org/bot${INSTALLMENT_BOT_TOKEN}/sendMessage`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            chat_id: message.chat.id,
            text: `Order #${orderId} has been ${action === "approve" ? "APPROVED ✅" : "REJECTED ❌"}`,
            parse_mode: "HTML",
          }),
        })
      }
    }

    return new Response(JSON.stringify({ success: true }), {
      headers: { "Content-Type": "application/json" },
    })
  } catch (error) {
    console.error("Error handling Telegram webhook:", error)
    return new Response(JSON.stringify({ success: false, error: "Internal server error" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}

// Update order status in database
const updateOrderStatus = async (orderId: string, status: "confirmed" | "rejected"): Promise<void> => {
  // This would connect to your database to update the order status
  // For now, we'll just log it
  console.log(`Updating order ${orderId} status to ${status}`)

  // In a real implementation, you would update your database
  // Example with a hypothetical database service:
  // await db.orders.update({ id: orderId }, { status: status });
}

// Send notification to customer
const sendCustomerNotification = async (orderId: string): Promise<void> => {
  // This would send an SMS or other notification to the customer
  // For now, we'll just log it
  console.log(`Sending notification to customer for order ${orderId}`)

  // In a real implementation, you would call an SMS service
  // Example with a hypothetical SMS service:
  // const order = await db.orders.findOne({ id: orderId });
  // await smsService.send(order.customerPhone, `Your order #${orderId} has been confirmed! Thank you for shopping with Seven.`);
}
