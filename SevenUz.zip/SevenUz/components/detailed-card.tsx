"use client"

import Image from "next/image"
import Link from "next/link"
import { ShoppingCart, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/components/cart-provider"
import { useToast } from "@/hooks/use-toast"
import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"

interface DetailedCardProps {
  id: string
  title: string
  description: string
  price: number
  oldPrice?: number
  image: string
  rating: number
  category: string
}

export default function DetailedCard({
  id,
  title,
  description,
  price,
  oldPrice,
  image,
  rating,
  category,
}: DetailedCardProps) {
  const { addToCart } = useCart()
  const { toast } = useToast()
  const [isAdded, setIsAdded] = useState(false)

  const handleAddToCart = () => {
    addToCart({
      id,
      name: title,
      price,
      quantity: 1,
      image,
    })

    setIsAdded(true)
    setTimeout(() => setIsAdded(false), 1500)

    toast({
      title: "Savatga qo'shildi",
      description: `${title} savatga qo'shildi`,
      duration: 3000,
    })
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300">
      <Link href={`/product/${id}`}>
        <div className="relative h-48 bg-gray-100 dark:bg-gray-700">
          <Image src={image || "https://via.placeholder.com/300"} alt={title} fill className="object-contain p-2" />
        </div>
      </Link>

      <div className="p-4">
        <Link href={`/product/${id}`}>
          <h3 className="font-medium text-gray-900 dark:text-white mb-1 hover:text-red-600 dark:hover:text-red-400 transition-colors">
            {title}
          </h3>
        </Link>

        <div className="flex items-center mb-2">
          <div className="flex items-center">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`h-3 w-3 ${i < Math.floor(rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
              />
            ))}
          </div>
          <span className="ml-1 text-xs text-gray-600 dark:text-gray-400">{rating}</span>
        </div>

        <p className="text-sm text-gray-600 dark:text-gray-400 mb-3 line-clamp-2">{description}</p>

        <div className="flex items-center justify-between">
          <div>
            <span className="font-bold text-red-600 dark:text-red-400">${price}</span>
            {oldPrice && <span className="ml-2 text-sm text-gray-500 line-through">${oldPrice}</span>}
          </div>

          <AnimatePresence>
            {isAdded ? (
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                className="bg-green-600 text-white rounded-md px-3 py-1 flex items-center"
              >
                <span className="text-xs">Qo'shildi</span>
              </motion.div>
            ) : (
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
              >
                <Button size="sm" onClick={handleAddToCart} className="bg-red-600 hover:bg-red-700 text-white">
                  <ShoppingCart className="h-4 w-4 mr-1" />
                  Qo'shish
                </Button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  )
}
