import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Check, ChevronRight, Star } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

export default function MacBookPro16Page() {
  return (
    <div className="bg-white dark:bg-gray-950">
      {/* Breadcrumb */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
          <Link href="/" className="hover:text-red-600 dark:hover:text-red-400">
            Bosh sahifa
          </Link>
          <ChevronRight className="h-4 w-4 mx-2" />
          <Link href="/category/laptops" className="hover:text-red-600 dark:hover:text-red-400">
            Noutbuklar
          </Link>
          <ChevronRight className="h-4 w-4 mx-2" />
          <span className="text-gray-900 dark:text-white">MacBook Pro 16-dyuym (2025)</span>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-b from-gray-100 to-white dark:from-gray-900 dark:to-gray-950 py-12 md:py-20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="w-full md:w-1/2 mb-8 md:mb-0">
              <Link href="/" className="inline-flex items-center text-red-600 mb-6 hover:underline">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Orqaga
              </Link>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-4">
                MacBook Pro 16-dyuym (2025)
              </h1>
              <div className="flex items-center mb-4">
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="h-5 w-5 fill-current text-yellow-500" />
                  ))}
                </div>
                <span className="ml-2 text-gray-600 dark:text-gray-400">4.9 (1,128 sharh)</span>
              </div>
              <p className="text-lg text-gray-700 dark:text-gray-300 mb-6">
                Apple'ning eng kuchli noutbuki. Yangi M4 Pro protsessori, Mini-LED displey va 24 soatgacha 
                batareya quvvati bilan professional foydalanuvchilar uchun.
              </p>
              <div className="flex items-center mb-6">
                <span className="text-3xl font-bold text-gray-900 dark:text-white">24,999,000 so'm</span>
                <Badge className="ml-3 bg-green-600">Muddatli to'lov mavjud</Badge>
              </div>
              <div className="flex flex-wrap gap-4">
                <Button size="lg" className="bg-red-600 hover:bg-red-700">
                  Savatga qo'shish
                </Button>
              </div>
            </div>
            <div className="w-full md:w-1/2 flex justify-center">
              <div className="relative h-[400px] w-[700px]">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/mbp16-spacegray-select-202301?wid=904&hei=840&fmt=jpeg&qlt=90&.v=1671304673202"
                  alt="MacBook Pro 16-dyuym"
                  fill
                  className="object-contain"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Product Details */}
      <div className="container mx-auto px-4 py-12">
        <Tabs defaultValue="features" className="w-full">
          <TabsList className="grid w-full md:w-auto grid-cols-3 mb-8">
            <TabsTrigger value="features">Xususiyatlar</TabsTrigger>
            <TabsTrigger value="specifications">Texnik ma'lumotlar</TabsTrigger>
            <TabsTrigger value="reviews">Sharhlar</TabsTrigger>
          </TabsList>
          <TabsContent value="features" className="space-y-12">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                  M4 Pro - Eng kuchli Apple protsessori
                </h2>
                <p className="text-gray-700 dark:text-gray-300 mb-4">
                  Yangi M4 Pro protsessori avvalgidan 40% tezroq va 30% energiya samaradorroq. 
                  Bu sizga eng murakkab vazifalarni ham tez va samarali bajarish imkonini beradi - 
                  video tahrirlash, 3D modellashtirish yoki kod yozish bo'ladimi.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">
                      12-yadroli CPU (8 samaradorlik + 4 quvvat yadrosi)
                    </span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">
                      30-yadroli GPU yuqori darajali grafik ishlash uchun
                    </span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">
                      32-yadroli Neural Engine sun'iy intellekt operatsiyalari uchun
                    </span>
                  </li>
                </ul>
              </div>
              <div className="relative h-[300px]">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/mbp-m2-hero-202301?wid=1090&hei=1000&fmt=jpeg&qlt=90&.v=1670959891740"
                  alt="M4 Pro Processor"
                  fill
                  className="object-contain"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div className="order-2 md:order-1 relative h-[300px]">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/mbp-14-16-compare-202301?wid=1090&hei=1000&fmt=jpeg&qlt=90&.v=1671641218099"
                  alt="Liquid Retina XDR Display"
                  fill
                  className="object-contain"
                />
              </div>
              <div className="order-1 md:order-2">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Liquid Retina XDR displey</h2>
                <p className="text-gray-700 dark:text-gray-300 mb-4">
                  16.2 dyuymli Liquid Retina XDR displey Mini-LED texnologiyasi bilan jihozlangan, 
                  bu esa 1000 nit doimiy va 1600 nit maksimal yorqinlikni ta'minlaydi. 
                  ProMotion texnologiyasi 120Hz gacha yangilanish tezligini ta'minlaydi.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">
                      3456 x 2234 piksel o'lchamli Retina displey
                    </span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">
                      ProMotion texnologiyasi 120Hz gacha yangilanish tezligi
                    </span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">
                      True Tone texnologiyasi va P3 keng rang gamuti
                    </span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Professional ulanish imkoniyatlari</h2>
                <p className="text-gray-700 dark:text-gray-300 mb-4">
                  MacBook Pro 16 barcha kerakli portlar bilan jihozlangan. HDMI, SDXC karta o'quvchisi, 
                  Thunderbolt 4 portlari va MagSafe 3 zaryadlash porti - barchasi sizning ishingizni 
                  osonlashtirish uchun.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">
                      3 ta Thunderbolt 4 (USB-C) porti
                    </span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">
                      HDMI porti 8K tashqi displeylarni qo'llab-quvvatlaydi
                    </span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">
                      SDXC karta o'quvchisi va MagSafe 3 zaryadlash porti
                    </span>
                  </li>
                </ul>
              </div>
              <div className="relative h-[300px]">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/mbp-16-silver-gallery1-202301?wid=4000&hei=3072&fmt=jpeg&qlt=90&.v=1670621047955"
                  alt="Connectivity"
                  fill
                  className="object-contain"
                />
              </div>
            </div>
          </TabsContent>
          <TabsContent value="specifications" className="space-y-6">
            <div className="border dark:border-gray-800 rounded-lg overflow-hidden">
              <div className="grid grid-cols-1 md:grid-cols-2">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">Displey</div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  16.2 dyuymli Liquid Retina XDR displey, 3456 x 2234 piksel, ProMotion texnologiyasi, 
                  1000 nit doimiy, 1600 nit maksimal yorqinlik
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  Protsessor
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  Apple M4 Pro, 12-yadroli CPU (8 samaradorlik + 4 quvvat yadrosi), 30-yadroli GPU, 
                  32-yadroli Neural Engine
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">Xotira</div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  32GB birlashtrilgan xotira, 1TB/2TB/4TB/8TB SSD saqlash xotirasi
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  Batareya
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  100Wh litiy-polimerli batareya, 24 soatgacha veb-brauzing, 22 soatgacha video ijro etish
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  Kamera
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  1080p FaceTime HD kamera, Center Stage qo'llab-quvvatlaydi
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  Audio
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  6 ta yuqori sifatli karnay, 3 ta studiya sifatidagi mikrofon, Dolby Atmos qo'llab-quvvatlaydi
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  Ulanish
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  3 ta Thunderbolt 4 (USB-C) porti, HDMI porti, SDXC karta o'quvchisi, MagSafe 3 zaryadlash porti, 
                  3.5 mm audio uyasi
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  Simsiz aloqa
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  Wi-Fi 6E (802.11ax), Bluetooth 5.3
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  O'lchamlari
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  355.7 x 248.1 x 16.8 mm, 2.15 kg
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="reviews" className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">Mijozlar sharhlari</h3>
              <Button>Sharh qoldirish</Button>
            </div>

            <div className="space-y-6">
              {/* Review 1 */}
              <div className="border dark:border-gray-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                      <span className="font-medium text-gray-700 dark:text-gray-300">DM</span>
                    </div>
                    <div className="ml-3">
                      <p className="font-medium text-gray-900 dark:text-white">Dilshod Mirzayev</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">18 May, 2025</p>
                    </div>
                  </div>
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-4 w-4 fill-current text-yellow-500" />
                    ))}
                  </div>
                </div>
                <p className="text-gray-700 dark:text-gray-300">
                  Men dasturchi sifatida bu noutbukni ishim uchun sotib oldim va juda mamnunman! 
                  M4 Pro protsessori hatto eng og'ir kod kompilyatsiyasi va virtual mashinalarni 
                  ham muammosiz ishlatadi. Batareya quvvati ajoyib - butun ish kuni davomida yetadi.
                </p>
              </div>

              {/* Review 2 */}
              <div className="border dark:border-gray-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                      <span className="font-medium text-gray-700 dark:text-gray-300">NA</span>
                    </div>
                    <div className="ml-3">
                      <p className="font-medium text-gray-900 dark:text-white">Nodira Azimova</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">5 May, 2025</p>
                    </div>
                  </div>
                  <div className="flex">
                    {[1, 2, 3, 4].map((star) => (
                      <Star key={star} className="h-4 w-4 fill-current text-yellow-500" />
                    ))}
                    <Star className="h-4 w-4 text-gray-300 dark:text-gray-600" />
                  </div>
                </div>
                <p className="text-gray-700 dark:text-gray-300">
                  Noutbuk juda yaxshi, lekin narxi biroz qimmat. Displey sifati va ishlash tezligi juda zo'r, 
                  ammo 32GB xotira ba'zi professional dasturlar uchun yetarli emas. Umumiy baholashim - yaxshi, 
                  lekin mukammal emas.
                </p>
              </div>

              {/* Review 3 */}
              <div className="border dark:border-gray-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                      <span className="font-medium text-gray-700 dark:text-gray-300">FT</span>
                    </div>
                    <div className="ml-3">
                      <p className="font-medium text-gray-900 dark:text-white">Farxod Toshmatov</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">22 April, 2025</p>
                    </div>
                  </div>
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-4 w-4 fill-current text-yellow-500" />
                    ))}
                  </div>
                </div>
                <p className="text-gray-700 dark:text-gray-300">
                  Men video montajchi sifatida bu noutbukni professional ishim uchun sotib oldim. 
                  4K va hatto 8K videolarni tahrirlash juda tez va silliq ishlaydi. Liquid Retina XDR 
                  displey ranglari juda aniq ko'rsatadi, bu esa rang gradatsiyasi bilan ishlashda juda muhim. 
                  Albatta tavsiya qilaman!
                </p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Related Products */}
      <div className="bg-gray-50 dark:bg-gray-900 py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-8">O'xshash mahsulotlar</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Product 1 */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
              <div className="relative h-48">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/macbook-air-space-gray-select-201810?wid=904&hei=840&fmt=jpeg&qlt=90&.v=1633027804000"
                  alt="MacBook Air"
                  fill
                  className="object-contain p-4"
                />
              </div>
              <div className="p-4">
                <h3 className="font-medium text-gray-900 dark:text-white mb-2">MacBook Air M3</h3>
                <div className="flex items-center mb-2">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-3 w-3 fill-current text-yellow-500" />
                    ))}
                  </div>
                  <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">(1532)</span>
                </div>
                <p className="text-red-600 font-bold">14,999,000 so'm</p>
              </div>
            </div>

            {/* Product 2 */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
              <div className="relative h-48">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/mbp14-spacegray-select-202301?wid=904&hei=840&fmt=jpeg&qlt=90&.v=1671304673229"
                  alt="MacBook Pro 14"
                  fill
                  className="object-contain p-4"
                />
              </div>
              <div className="p-4">
                <h3 className="font-medium text-gray-900 dark:text-white mb-2">MacBook Pro 14-dyuym</h3>
                <div className="flex items-center mb-2">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-3 w-3 fill-current text-yellow-500" />
                    ))}
                  </div>
                  <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">(1024)</span>
                </div>
                <p className="text-red-600 font-bold">19,999,000 so'm</p>
              </div>
            </div>

            {/* Product 3 */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
              <div className="relative h-48">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/mac-mini-hero-202301?wid=904&hei=840&fmt=jpeg&qlt=90&.v=1670038314708"
                  alt="Mac mini"
                  fill
                  className="object-contain p-4"
                />
              </div>
              <div className="p-4">
                <h3 className="font-medium text-gray-900 dark:text-white mb-2">Mac mini M3</h3>
                <div className="flex items-center mb-2">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-3 w-3 fill-current text-yellow-500" />
                    ))}
                  </div>
                  <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">(876)</span>
                </div>
                <p className="text-red-600 font-bold">9,999,000 so'm</p>
              </div>
            </div>

            {/* Product 4 */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
              <div className="relative h-48">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/ipad-pro-model-select-gallery-2-202403_GEO_US?wid=2560&hei=1440&fmt=p-jpg&qlt=95&.v=1708553495315"
                  alt="iPad Pro"
                  fill
                  className="object-contain p-4"
                />
              </div>
              <div className="p-4">
                <h3 className="font-medium text-gray-900 dark:text-white mb-2">iPad Pro M3</h3>
                <div className="flex items-center mb-2">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-3 w-3 fill-current text-yellow-500" />
                    ))}
                  </div>
                  <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">(932)</span>
                </div>
                <p className="text-red-600 font-bold">12,999,000 so'm</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
