"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Loader2, ShoppingBag, Clock, CheckCircle, XCircle, ArrowLeft } from "lucide-react"

// Mock data for requests - in a real app, this would come from an API
interface RequestItem {
  id: string
  date: string
  type: "order" | "warranty" | "return"
  status: "pending" | "confirmed" | "rejected"
  details: {
    items?: { name: string; quantity: number; price: number }[]
    totalAmount?: number
    paymentMethod?: string
    deliveryMethod?: string
    reason?: string
  }
}

// Mock data
const mockRequests: RequestItem[] = [
  {
    id: "ORD-123456",
    date: "2025-05-10T14:30:00",
    type: "order",
    status: "pending",
    details: {
      items: [
        { name: "iPhone 15 Pro", quantity: 1, price: 999 },
        { name: "AirPods Pro", quantity: 1, price: 249 },
      ],
      totalAmount: 1248,
      paymentMethod: "Installment (6 months)",
      deliveryMethod: "Courier",
    },
  },
  {
    id: "ORD-123455",
    date: "2025-05-08T10:15:00",
    type: "order",
    status: "confirmed",
    details: {
      items: [{ name: "MacBook Air M3", quantity: 1, price: 1299 }],
      totalAmount: 1299,
      paymentMethod: "Card",
      deliveryMethod: "Pickup",
    },
  },
  {
    id: "WAR-123454",
    date: "2025-05-05T09:45:00",
    type: "warranty",
    status: "rejected",
    details: {
      reason: "Product damage not covered by warranty",
    },
  },
]

export default function RequestsPage() {
  const router = useRouter()
  const { user } = useAuth()
  const [requests, setRequests] = useState<RequestItem[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if user is logged in
    if (!user) {
      router.push("/login?redirect=/account/requests")
      return
    }

    // Simulate API call to fetch requests
    const fetchRequests = async () => {
      try {
        // In a real app, this would be an API call
        // const response = await fetch('/api/account/requests')
        // const data = await response.html()

        // Using mock data for now
        setTimeout(() => {
          setRequests(mockRequests)
          setIsLoading(false)
        }, 1000)
      } catch (error) {
        console.error("Error fetching requests:", error)
        setIsLoading(false)
      }
    }

    fetchRequests()
  }, [user, router])

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="outline" className="bg-amber-50 text-amber-600 border-amber-200">
            Pending
          </Badge>
        )
      case "confirmed":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">
            Confirmed
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-600 border-red-200">
            Rejected
          </Badge>
        )
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="h-5 w-5 text-amber-500" />
      case "confirmed":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "rejected":
        return <XCircle className="h-5 w-5 text-red-500" />
      default:
        return null
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-16 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-red-600" />
          <p className="mt-4 text-gray-600 dark:text-gray-400">Loading your requests...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">My Requests</h1>
        <Link href="/account">
          <Button variant="outline" size="sm">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Account
          </Button>
        </Link>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="all">All Requests</TabsTrigger>
          <TabsTrigger value="pending">Pending</TabsTrigger>
          <TabsTrigger value="confirmed">Confirmed</TabsTrigger>
          <TabsTrigger value="rejected">Rejected</TabsTrigger>
        </TabsList>

        <TabsContent value="all">{renderRequestsList(requests)}</TabsContent>

        <TabsContent value="pending">
          {renderRequestsList(requests.filter((req) => req.status === "pending"))}
        </TabsContent>

        <TabsContent value="confirmed">
          {renderRequestsList(requests.filter((req) => req.status === "confirmed"))}
        </TabsContent>

        <TabsContent value="rejected">
          {renderRequestsList(requests.filter((req) => req.status === "rejected"))}
        </TabsContent>
      </Tabs>
    </div>
  )

  function renderRequestsList(requestsList: RequestItem[]) {
    if (requestsList.length === 0) {
      return (
        <div className="text-center py-12 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
          <ShoppingBag className="h-12 w-12 mx-auto text-gray-400" />
          <h3 className="mt-4 text-lg font-medium text-gray-900 dark:text-white">No requests found</h3>
          <p className="mt-2 text-gray-500 dark:text-gray-400">You don't have any requests in this category.</p>
        </div>
      )
    }

    return (
      <div className="space-y-6">
        {requestsList.map((request) => (
          <div key={request.id} className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  {getStatusIcon(request.status)}
                  <h3 className="ml-2 text-lg font-medium text-gray-900 dark:text-white">
                    {request.type === "order"
                      ? "Order"
                      : request.type === "warranty"
                        ? "Warranty Claim"
                        : "Return Request"}
                  </h3>
                </div>
                {getStatusBadge(request.status)}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Request ID</p>
                  <p className="font-medium text-gray-900 dark:text-white">{request.id}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Date</p>
                  <p className="font-medium text-gray-900 dark:text-white">{formatDate(request.date)}</p>
                </div>
              </div>

              {request.type === "order" && request.details.items && (
                <div className="mt-4">
                  <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Items</p>
                  <ul className="space-y-2">
                    {request.details.items.map((item, index) => (
                      <li key={index} className="flex justify-between text-sm">
                        <span className="text-gray-600 dark:text-gray-400">
                          {item.name} x{item.quantity}
                        </span>
                        <span className="font-medium text-gray-900 dark:text-white">${item.price.toFixed(2)}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">Total Amount</span>
                      <span className="font-bold text-gray-900 dark:text-white">
                        ${request.details.totalAmount?.toFixed(2)}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-4 text-sm">
                      <div>
                        <span className="text-gray-500 dark:text-gray-400">Payment Method:</span>
                        <span className="ml-1 text-gray-700 dark:text-gray-300">{request.details.paymentMethod}</span>
                      </div>
                      <div>
                        <span className="text-gray-500 dark:text-gray-400">Delivery Method:</span>
                        <span className="ml-1 text-gray-700 dark:text-gray-300">{request.details.deliveryMethod}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {request.type !== "order" && request.details.reason && (
                <div className="mt-4">
                  <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Reason</p>
                  <p className="text-gray-600 dark:text-gray-400 text-sm">{request.details.reason}</p>
                </div>
              )}
            </div>

            <div className="px-6 py-4 bg-gray-50 dark:bg-gray-800/50 border-t border-gray-200 dark:border-gray-700">
              <div className="flex justify-between items-center">
                <div className="text-sm text-gray-500 dark:text-gray-400">
                  {request.status === "pending"
                    ? "Your request is being reviewed"
                    : request.status === "confirmed"
                      ? "Your request has been approved"
                      : "Your request has been rejected"}
                </div>
                <Link href={`/account/requests/${request.id}`}>
                  <Button variant="outline" size="sm">
                    View Details
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    )
  }
}
