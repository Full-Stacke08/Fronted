import { sendOrderToTelegram } from "@/lib/telegram"
import { NextResponse } from "next/server"

export async function POST(req: Request) {
  try {
    const orderData = await req.json()

    // Generate a unique order ID
    const orderId = `ORD-${Date.now().toString().slice(-6)}`
    const orderWithId = { ...orderData, orderId }

    // Send order to Telegram
    const telegramSent = await sendOrderToTelegram(orderWithId)

    // Here you would also save the order to your database
    // const savedOrder = await db.orders.create(orderWithId);

    return NextResponse.json({
      success: true,
      message: "Order placed successfully",
      orderId,
      telegramSent,
    })
  } catch (error) {
    console.error("Error processing order:", error)
    return NextResponse.json({ success: false, message: "Failed to process order" }, { status: 500 })
  }
}
