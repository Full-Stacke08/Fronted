"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronLeft, ChevronRight, ShoppingCart, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/components/cart-provider"
import { useToast } from "@/hooks/use-toast"
import { useLanguage } from "@/hooks/use-language"
import { allProducts } from "@/lib/product-data"
import type { Product } from "@/lib/types"

export default function FeaturedProducts() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [selectedColor, setSelectedColor] = useState<string>("")
  const [autoplay, setAutoplay] = useState(true)
  const autoplayRef = useRef<NodeJS.Timeout | null>(null)
  const { addToCart } = useCart()
  const { toast } = useToast()
  const { language, translations } = useLanguage()

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % allProducts.length)
  }

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + allProducts.length) % allProducts.length)
  }

  const handleDotClick = (index: number) => {
    setCurrentIndex(index)
    setAutoplay(false)
    setTimeout(() => setAutoplay(true), 5000)
  }

  const handleAddToCart = () => {
    const product = allProducts[currentIndex]
    addToCart({
      id: product.id,
      name: getProductField(product, "name", language),
      price: product.price,
      quantity: 1,
      image: product.image || "",
    })

    toast({
      title: translations.productAdded,
      description: `${getProductField(product, "name", language)} ${translations.productAddedDesc}`,
      duration: 3000,
    })
  }

  useEffect(() => {
    if (autoplay) {
      autoplayRef.current = setInterval(nextSlide, 5000)
    }
    return () => {
      if (autoplayRef.current) {
        clearInterval(autoplayRef.current)
      }
    }
  }, [autoplay, currentIndex])

  useEffect(() => {
    // Reset selected color when product changes
    const currentProduct = allProducts[currentIndex]
    setSelectedColor(currentProduct.color || "")
  }, [currentIndex])

  function getProductField(product: Product, field: "name" | "description", language: string) {
    const langKey = field + language.charAt(0).toUpperCase() + language.slice(1)
    return (product as any)[langKey] || product[field] || ""
  }

  const currentProduct = allProducts[currentIndex]

  return (
    <section className="py-16 bg-gradient-to-b from-gray-100 to-white dark:from-gray-800 dark:to-gray-900">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 text-gray-900 dark:text-white">
          {translations.latestProducts}
        </h2>

        <div className="relative max-w-6xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center"
            >
              <div className="relative aspect-square bg-white dark:bg-gray-800 rounded-2xl p-8 flex items-center justify-center overflow-hidden">
                <motion.div
                  initial={{ scale: 0.8 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.5 }}
                  className="relative w-full h-full"
                >
                  <Image
                    src={currentProduct.image || ""}
                    alt={getProductField(currentProduct, "name", language)}
                    fill
                    className="object-contain"
                  />
                </motion.div>
                {currentProduct.oldPrice && (
                  <div className="absolute top-4 left-4 bg-red-600 text-white text-sm font-bold px-3 py-1 rounded-full">
                    {Math.round(((currentProduct.oldPrice - currentProduct.price) / currentProduct.oldPrice) * 100)}%{" "}
                    {translations.discount}
                  </div>
                )}
              </div>

              <div className="space-y-6">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <h3 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
                    {getProductField(currentProduct, "name", language)}
                  </h3>
                  <div className="flex items-center mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-5 w-5 ${
                          i < Math.floor(currentProduct.rating || 5)
                            ? "text-yellow-400 fill-current"
                            : "text-gray-300 dark:text-gray-600"
                        }`}
                      />
                    ))}
                    <span className="text-sm text-gray-600 dark:text-gray-400 ml-2">
                      {currentProduct.rating || 5}.0 ({currentProduct.reviews || 0}+ {translations.reviews})
                    </span>
                  </div>
                  <p className="text-gray-600 dark:text-gray-300 mb-6">
                    {getProductField(currentProduct, "description", language)}
                  </p>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.3 }}
                  className="space-y-4"
                >
                  {currentProduct.color && (
                    <div>
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        {translations.colors}:
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        <button
                          className={`px-3 py-1 rounded-full text-sm ${
                            selectedColor === currentProduct.color
                              ? "bg-red-600 text-white"
                              : "bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-600"
                          }`}
                        >
                          {currentProduct.color}
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="flex items-end">
                    <div className="mr-4">
                      <p className="text-sm text-gray-500 dark:text-gray-400">{translations.price}:</p>
                      <div className="flex items-center">
                        <span className="text-3xl font-bold text-red-600 dark:text-red-400">
                          ${currentProduct.price}
                        </span>
                        {currentProduct.oldPrice && (
                          <span className="ml-2 text-lg text-gray-500 line-through">${currentProduct.oldPrice}</span>
                        )}
                      </div>
                    </div>
                    <p className="text-sm text-green-600 dark:text-green-400">{translations.inStock}</p>
                  </div>

                  <div className="flex flex-wrap gap-4 pt-4">
                    <Button
                      size="lg"
                      onClick={handleAddToCart}
                      className="bg-red-600 hover:bg-red-700 text-white flex-1 sm:flex-none"
                    >
                      <ShoppingCart className="h-5 w-5 mr-2" />
                      {translations.addToCart}
                    </Button>
                    <Link href={`/product/${currentProduct.id}`}>
                      <Button
                        size="lg"
                        variant="outline"
                        className="border-red-600 text-red-600 hover:bg-red-50 dark:hover:bg-red-950 flex-1 sm:flex-none"
                      >
                        {translations.moreDetails}
                      </Button>
                    </Link>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Navigation arrows */}
          <button
            onClick={prevSlide}
            className="absolute left-0 top-1/2 lg:inline sm:hidden -translate-y-1/2 bg-white dark:bg-gray-800 rounded-full shadow p-2 z-10 hover:bg-gray-200 dark:hover:bg-gray-700 transition"
            aria-label={translations.previous}
            style={{ left: "-40px" }}
          >
          </button>

          {/* Dots for manual navigation */}
          <div className="flex justify-center mt-8 gap-2">
            {allProducts.map((_, idx) => (
              <button
                key={idx}
                onClick={() => handleDotClick(idx)}
                className={`w-3 h-3 rounded-full border-2 transition-all duration-200 ${
                  idx === currentIndex
                    ? "bg-red-600 border-red-600 scale-125"
                    : "bg-gray-300 dark:bg-gray-700 border-gray-300 dark:border-gray-700"
                }`}
                aria-label={`${translations.select} ${idx + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
