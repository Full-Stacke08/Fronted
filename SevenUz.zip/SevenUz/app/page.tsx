import Hero from "@/components/hero"
import FirstSection from "@/components/first-section"
import SecondSection from "@/components/second-section"
import ThirdSection from "@/components/third-section"
import CategoryList from "@/components/category-list"
import RecommendedProducts from "@/components/recommended-products"
 

export default function Home() {
  return (
    <main className="min-h-screen mx-auto ">
 
      <Hero />
      <div className="container mx-auto px-4">
        <CategoryList />
        <FirstSection />
        <SecondSection />
        <ThirdSection />
        <RecommendedProducts productId={""} />
        
      </div>
    </main>
  )
}
