"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { ArrowLeft, Building, Clock, Globe, MapPin, Phone, Shield, Award, Users, Mail } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { useLanguage } from "@/components/language-provider"

export default function CompanyPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("about")
  const { translations, language } = useLanguage()

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 },
  }

  // Til bo'yicha matnlar
  const companyTexts = {
    uz: {
      heroTitle: "Seven Uz",
      heroDescription: "O'zbekistondagi eng ishonchli va sifatli mobil qurilmalar hamda aksessuarlar sotuvchi do'kon",
      aboutTab: "Biz haqimizda",
      missionTab: "Maqsadimiz",
      historyTab: "Tarixchimiz",
      aboutTitle: "Seven Uz - Ishonchli smartfon do'koningiz",
      aboutText1:
        "Seven Uz 2020 yilda tashkil etilgan bo'lib, O'zbekistondagi eng ishonchli va sifatli mobil qurilmalar hamda aksessuarlar sotuvchi do'konlardan biri hisoblanadi. Bizning asosiy maqsadimiz mijozlarimizga eng yuqori sifatli mahsulotlarni qulay narxlarda taqdim etishdir.",
      aboutText2:
        "Biz faqat original va sifatli mahsulotlarni sotamiz. Barcha mahsulotlar kafolat bilan ta'minlanadi. Bizning do'konda Apple, Samsung, Xiaomi, Huawei va boshqa brendlarning eng so'nggi rusumli smartfonlari, planshetlari va aksessuarlarini topishingiz mumkin.",
      customers: "Mijozlar",
      satisfiedCustomers: "Mamnun mijozlar",
      stores: "Do'konlar",
      acrossTashkent: "Toshkent bo'ylab",
      missionTitle: "Bizning vazifamiz",
      missionText:
        "Seven Uz kompaniyasining asosiy vazifasi O'zbekiston aholisiga eng yuqori sifatli texnologik mahsulotlarni qulay narxlarda va muddatli to'lov imkoniyati bilan taqdim etishdir. Biz har bir mijozga alohida yondashib, uning ehtiyojlariga mos mahsulotni tanlashda yordam beramiz.",
      quality: "Sifat",
      qualityText: "Barcha mahsulotlar sifat nazoratidan o'tkaziladi",
      trust: "Ishonch",
      trustText: "Yillar davomida ishonchni oqlaganmiz",
      innovation: "Innovatsiya",
      innovationText: "Eng so'nggi texnologiyalarni taqdim etamiz",
      ourValues: "Bizning qadriyatlarimiz",
      value1: "Mijoz manfaati - Har doim mijoz manfaatini birinchi o'ringa qo'yamiz",
      value2: "Sifat - Faqat eng yuqori sifatli mahsulotlarni taqdim etamiz",
      value3: "Innovatsiya - Doimo yangiliklar va innovatsiyalarni izlaymiz",
      historyTitle: "Kompaniya tarixi",
      historyText1:
        "Seven Uz 2020 yilda kichik internet-do'kon sifatida o'z faoliyatini boshladi. Dastlab biz faqat Apple mahsulotlarini sotish bilan shug'ullangan bo'lsak, keyinchalik Samsung, Xiaomi va boshqa brendlarning mahsulotlarini ham sotishni yo'lga qo'ydik.",
      historyText2:
        "2022 yilga kelib biz Toshkent shahrida o'z do'konlarimizni ochdik va bugungi kunda 5 dan ortiq do'konlarimiz faoliyat yuritmoqda. Biz doimiy ravishda o'sib bormoqdamiz va yaqin kelajakda O'zbekistonning boshqa shaharlarida ham do'konlar ochishni rejalashtirganmiz.",
      timeline2020: "Seven Uz internet-do'koni sifatida faoliyatini boshladi",
      timeline2022: "Toshkent shahrida birinchi jismoniy do'konimiz ochildi",
      timeline2025: "O'zbekiston bo'ylab 10 dan ortiq do'konlar ochish rejasi",
      ourStores: "Bizning do'konlarimiz",
      chilonzorBranch: "Chilonzor filiali",
      yunusobodBranch: "Yunusobod filiali",
      sergeliBranch: "Sergeli filiali",
      viewOnMap: "Xaritada ko'rish",
      workingHours: "9:00 - 22:00 (har kuni)",
      // FAQ matnlari
      faqTitle: "Ko'p so'raladigan savollar",
      faqQuestion1: "Mahsulotlaringiz original va kafolatli ekanligiga qanday ishonch hosil qilishim mumkin?",
      faqAnswer1:
        "Barcha mahsulotlarimiz 100% original va rasmiy kafolat bilan ta'minlangan. Har bir mahsulot sotib olinganda kafolat taloni va chek beriladi. Shuningdek, mahsulotlarning seriya raqami orqali originalligini tekshirish mumkin.",
      faqQuestion2: "Mahsulotlarni muddatli to'lov orqali sotib olish mumkinmi?",
      faqAnswer2:
        "Ha, albatta. Biz bir nechta banklar bilan hamkorlik qilamiz va 3, 6, 9, 12 va 24 oylik muddatli to'lov imkoniyatini taqdim etamiz. Buning uchun pasport va INPS raqami talab qilinadi.",
      faqQuestion3: "Mahsulotlarni O'zbekistonning boshqa shaharlariga yetkazib berish xizmati mavjudmi?",
      faqAnswer3:
        "Ha, biz O'zbekistonning barcha viloyatlariga yetkazib berish xizmatini taqdim etamiz. Toshkent shahri bo'ylab yetkazib berish bepul, boshqa viloyatlarga esa kuryer xizmati orqali 1-3 kun ichida yetkazib beriladi.",
      faqQuestion4: "Agar sotib olingan mahsulot menga yoqmasa, uni qaytarib berishim mumkinmi?",
      faqAnswer4:
        "O'zbekiston Respublikasi qonunchiligiga muvofiq, sifatli mahsulotlarni 14 kun ichida qaytarib berish mumkin, agar mahsulot ishlatilmagan, zarar yetkazilmagan va barcha aksessuarlari, hujjatlari va o'rami saqlangan bo'lsa.",
      faqQuestion5: "Do'koningizda qanday to'lov usullari mavjud?",
      faqAnswer5:
        "Bizda naqd pul, bank kartasi (UZCARD, HUMO, VISA, Mastercard), QR-kod orqali to'lov, Click, Payme va boshqa elektron to'lov tizimlari orqali to'lov qilish imkoniyati mavjud.",
      contactDescription: "Savol va takliflar uchun biz bilan bog'laning",
      address: "Manzil:",
      phone: "Telefon:",
      email: "Email:",
      workTime: "Ish vaqti:",
      workTimeWeekdays: "Dushanba - Shanba: 9:00 - 22:00",
      workTimeSunday: "Yakshanba: 10:00 - 20:00",
      socialNetworks: "Ijtimoiy tarmoqlar:",
    },
    ru: {
      heroTitle: "Seven Uz",
      heroDescription: "Самый надежный и качественный магазин мобильных устройств и аксессуаров в Узбекистане",
      aboutTab: "О нас",
      missionTab: "Наша миссия",
      historyTab: "История",
      aboutTitle: "Seven Uz - Ваш надежный магазин смартфонов",
      aboutText1:
        "Seven Uz была основана в 2020 году и является одним из самых надежных и качественных магазинов мобильных устройств и аксессуаров в Узбекистане. Наша основная цель - предоставить нашим клиентам продукты высочайшего качества по доступным ценам.",
      aboutText2:
        "Мы продаем только оригинальные и качественные продукты. Все продукты поставляются с гарантией. В нашем магазине вы можете найти новейшие смартфоны, планшеты и аксессуары от Apple, Samsung, Xiaomi, Huawei и других брендов.",
      customers: "Клиенты",
      satisfiedCustomers: "Довольных клиентов",
      stores: "Магазины",
      acrossTashkent: "По Ташкенту",
      missionTitle: "Наша миссия",
      missionText:
        "Основная миссия компании Seven Uz - предоставить населению Узбекистана технологические продукты высочайшего качества по доступным ценам и с возможностью рассрочки. Мы подходим к каждому клиенту индивидуально и помогаем выбрать продукт, соответствующий его потребностям.",
      quality: "Качество",
      qualityText: "Все продукты проходят контроль качества",
      trust: "Доверие",
      trustText: "Мы оправдываем доверие годами",
      innovation: "Инновации",
      innovationText: "Предоставляем новейшие технологии",
      ourValues: "Наши ценности",
      value1: "Выгода клиента - Мы всегда ставим выгоду клиента на первое место",
      value2: "Качество - Предоставляем только продукты высочайшего качества",
      value3: "Инновации - Постоянно ищем новинки и инновации",
      historyTitle: "История компании",
      historyText1:
        "Seven Uz начала свою деятельность в 2020 году как небольшой интернет-магазин. Первоначально мы занимались только продажей продуктов Apple, но позже наладили продажу продуктов Samsung, Xiaomi и других брендов.",
      historyText2:
        "К 2022 году мы открыли свои магазины в Ташкенте, и сегодня у нас работает более 5 магазинов. Мы постоянно растем и планируем открыть магазины в других городах Узбекистана в ближайшем будущем.",
      timeline2020: "Seven Uz начала деятельность как интернет-магазин",
      timeline2022: "Открылся первый физический магазин в Ташкенте",
      timeline2025: "План открытия более 10 магазинов по Узбекистану",
      ourStores: "Наши магазины",
      chilonzorBranch: "Филиал Чиланзар",
      yunusobodBranch: "Филиал Юнусабад",
      sergeliBranch: "Филиал Сергели",
      viewOnMap: "Посмотреть на карте",
      workingHours: "9:00 - 22:00 (ежедневно)",
      // FAQ matnlari
      faqTitle: "Часто задаваемые вопросы",
      faqQuestion1: "Как я могу убедиться, что ваши продукты оригинальные и имеют гарантию?",
      faqAnswer1:
        "Все наши продукты 100% оригинальные и поставляются с официальной гарантией. При покупке каждого продукта выдается гарантийный талон и чек. Также можно проверить оригинальность по серийному номеру продукта.",
      faqQuestion2: "Можно ли купить товары в рассрочку?",
      faqAnswer2:
        "Да, конечно. Мы сотрудничаем с несколькими банками и предоставляем возможность рассрочки на 3, 6, 9, 12 и 24 месяца. Для этого требуется паспорт и номер ИНПС.",
      faqQuestion3: "Есть ли услуга доставки товаров в другие города Узбекистана?",
      faqAnswer3:
        "Да, мы предоставляем услугу доставки во все регионы Узбекистана. Доставка по Ташкенту бесплатная, в другие регионы доставляется курьерской службой в течение 1-3 дней.",
      faqQuestion4: "Могу ли я вернуть товар, если он мне не понравился?",
      faqAnswer4:
        "Согласно законодательству Республики Узбекистан, качественные товары можно вернуть в течение 14 дней, если товар не использовался, не поврежден и сохранены все аксессуары, документы и упаковка.",
      faqQuestion5: "Какие способы оплаты доступны в вашем магазине?",
      faqAnswer5:
        "У нас есть возможность оплаты наличными, банковской картой (UZCARD, HUMO, VISA, Mastercard), QR-кодом, Click, Payme и другими электронными платежными системами.",
      contactDescription: "Свяжитесь с нами для вопросов и предложений",
      address: "Адрес:",
      phone: "Телефон:",
      email: "Email:",
      workTime: "Время работы:",
      workTimeWeekdays: "Понедельник - Суббота: 9:00 - 22:00",
      workTimeSunday: "Воскресенье: 10:00 - 20:00",
      socialNetworks: "Социальные сети:",
    },
    en: {
      heroTitle: "Seven Uz",
      heroDescription: "The most reliable and quality mobile devices and accessories store in Uzbekistan",
      aboutTab: "About Us",
      missionTab: "Our Mission",
      historyTab: "History",
      aboutTitle: "Seven Uz - Your Trusted Smartphone Store",
      aboutText1:
        "Seven Uz was established in 2020 and is one of the most reliable and quality mobile devices and accessories stores in Uzbekistan. Our main goal is to provide our customers with the highest quality products at affordable prices.",
      aboutText2:
        "We sell only original and quality products. All products come with warranty. In our store you can find the latest smartphones, tablets and accessories from Apple, Samsung, Xiaomi, Huawei and other brands.",
      customers: "Customers",
      satisfiedCustomers: "Satisfied customers",
      stores: "Stores",
      acrossTashkent: "Across Tashkent",
      missionTitle: "Our Mission",
      missionText:
        "The main mission of Seven Uz company is to provide the people of Uzbekistan with the highest quality technological products at affordable prices and with installment options. We approach each customer individually and help choose a product that meets their needs.",
      quality: "Quality",
      qualityText: "All products undergo quality control",
      trust: "Trust",
      trustText: "We have been justifying trust for years",
      innovation: "Innovation",
      innovationText: "We provide the latest technologies",
      ourValues: "Our Values",
      value1: "Customer benefit - We always put customer benefit first",
      value2: "Quality - We provide only the highest quality products",
      value3: "Innovation - We constantly seek new products and innovations",
      historyTitle: "Company History",
      historyText1:
        "Seven Uz started its activity in 2020 as a small online store. Initially, we were only engaged in selling Apple products, but later we established the sale of Samsung, Xiaomi and other brands' products.",
      historyText2:
        "By 2022, we opened our stores in Tashkent, and today we have more than 5 stores operating. We are constantly growing and plan to open stores in other cities of Uzbekistan in the near future.",
      timeline2020: "Seven Uz started operating as an online store",
      timeline2022: "First physical store opened in Tashkent",
      timeline2025: "Plan to open more than 10 stores across Uzbekistan",
      ourStores: "Our Stores",
      chilonzorBranch: "Chilonzor Branch",
      yunusobodBranch: "Yunusobod Branch",
      sergeliBranch: "Sergeli Branch",
      viewOnMap: "View on Map",
      workingHours: "9:00 - 22:00 (daily)",
      // FAQ matnlari
      faqTitle: "Frequently Asked Questions",
      faqQuestion1: "How can I be sure that your products are original and have a warranty?",
      faqAnswer1:
        "All our products are 100% original and come with official warranty. When purchasing each product, a warranty card and receipt are provided. You can also check the originality by the product's serial number.",
      faqQuestion2: "Is it possible to buy products on installment?",
      faqAnswer2:
        "Yes, of course. We cooperate with several banks and provide installment options for 3, 6, 9, 12 and 24 months. This requires a passport and INPS number.",
      faqQuestion3: "Is there a delivery service to other cities of Uzbekistan?",
      faqAnswer3:
        "Yes, we provide delivery service to all regions of Uzbekistan. Delivery in Tashkent is free, to other regions it is delivered by courier service within 1-3 days.",
      faqQuestion4: "Can I return the product if I don't like it?",
      faqAnswer4:
        "According to the legislation of the Republic of Uzbekistan, quality goods can be returned within 14 days if the product has not been used, damaged and all accessories, documents and packaging are preserved.",
      faqQuestion5: "What payment methods are available in your store?",
      faqAnswer5:
        "We have the option to pay with cash, bank card (UZCARD, HUMO, VISA, Mastercard), QR code, Click, Payme and other electronic payment systems.",
      contactDescription: "Contact us for questions and suggestions",
      address: "Address:",
      phone: "Phone:",
      email: "Email:",
      workTime: "Working hours:",
      workTimeWeekdays: "Monday - Saturday: 9:00 - 22:00",
      workTimeSunday: "Sunday: 10:00 - 20:00",
      socialNetworks: "Social networks:",
    },
  }

  const currentTexts = companyTexts[language as keyof typeof companyTexts] || companyTexts.uz

  return (
    <div className="min-h-screen  mx-auto bg-gray-50 dark:bg-gray-900 pb-12">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-red-600 to-red-800 text-white">
        <div className="container mx-auto px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-4">{currentTexts.heroTitle}</h1>
            <p className="text-lg md:text-xl max-w-3xl mx-auto">{currentTexts.heroDescription}</p>
          </motion.div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3 }}
          className="mb-6 flex items-center"
        >
          <Button variant="ghost" size="icon" onClick={() => router.back()} className="mr-2">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-3xl font-bold text-gray-800 dark:text-white">{translations.aboutCompany}</h1>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <motion.div
            className="md:col-span-2"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid grid-cols-3 mb-8">
                <TabsTrigger value="about">{currentTexts.aboutTab}</TabsTrigger>
                <TabsTrigger value="mission">{currentTexts.missionTab}</TabsTrigger>
                <TabsTrigger value="history">{currentTexts.historyTab}</TabsTrigger>
              </TabsList>

              <TabsContent value="about" className="space-y-6">
                <motion.div variants={container} initial="hidden" animate="show" className="space-y-6">
                  <motion.div variants={item}>
                    <h2 className="text-2xl font-semibold mb-4 text-gray-800 dark:text-white">
                      {currentTexts.aboutTitle}
                    </h2>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">{currentTexts.aboutText1}</p>
                    <p className="text-gray-600 dark:text-gray-300">{currentTexts.aboutText2}</p>
                  </motion.div>

                  <motion.div variants={item} className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg flex items-center">
                          <Users className="h-5 w-5 mr-2 text-red-500" />
                          {currentTexts.customers}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-3xl font-bold">10,000+</p>
                        <p className="text-gray-500">{currentTexts.satisfiedCustomers}</p>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg flex items-center">
                          <Building className="h-5 w-5 mr-2 text-red-500" />
                          {currentTexts.stores}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-3xl font-bold">5+</p>
                        <p className="text-gray-500">{currentTexts.acrossTashkent}</p>
                      </CardContent>
                    </Card>
                  </motion.div>

                  <motion.div variants={item} className="mt-8">
                    <div className="aspect-video relative rounded-lg overflow-hidden">
                      <iframe
                        width="100%"
                        height="100%"
                        src="https://www.youtube.com/embed/dQw4w9WgXcQ"
                        title="Seven Uz haqida"
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                        className="absolute inset-0"
                      ></iframe>
                    </div>
                  </motion.div>
                </motion.div>
              </TabsContent>

              <TabsContent value="mission" className="space-y-6">
                <motion.div variants={container} initial="hidden" animate="show" className="space-y-6">
                  <motion.div variants={item}>
                    <h2 className="text-2xl font-semibold mb-4 text-gray-800 dark:text-white">
                      {currentTexts.missionTitle}
                    </h2>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">{currentTexts.missionText}</p>
                  </motion.div>

                  <motion.div variants={item} className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg flex items-center">
                          <Shield className="h-5 w-5 mr-2 text-red-500" />
                          {currentTexts.quality}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-600 dark:text-gray-300">{currentTexts.qualityText}</p>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg flex items-center">
                          <Award className="h-5 w-5 mr-2 text-red-500" />
                          {currentTexts.trust}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-600 dark:text-gray-300">{currentTexts.trustText}</p>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-lg flex items-center">
                          <Globe className="h-5 w-5 mr-2 text-red-500" />
                          {currentTexts.innovation}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-600 dark:text-gray-300">{currentTexts.innovationText}</p>
                      </CardContent>
                    </Card>
                  </motion.div>

                  <motion.div variants={item} className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="relative h-[300px] rounded-lg overflow-hidden">
                      <Image
                        src="https://images.unsplash.com/photo-1581287053822-fd7bf4f4bfec?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80"
                        alt="Seven Uz do'koni"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="space-y-4">
                      <h3 className="text-xl font-semibold text-gray-800 dark:text-white">{currentTexts.ourValues}</h3>
                      <ul className="space-y-2">
                        <li className="flex items-start">
                          <span className="h-6 w-6 rounded-full bg-red-100 dark:bg-red-900 text-red-600 dark:text-red-400 flex items-center justify-center mr-2 flex-shrink-0 mt-0.5">
                            1
                          </span>
                          <p className="text-gray-600 dark:text-gray-300">{currentTexts.value1}</p>
                        </li>
                        <li className="flex items-start">
                          <span className="h-6 w-6 rounded-full bg-red-100 dark:bg-red-900 text-red-600 dark:text-red-400 flex items-center justify-center mr-2 flex-shrink-0 mt-0.5">
                            2
                          </span>
                          <p className="text-gray-600 dark:text-gray-300">{currentTexts.value2}</p>
                        </li>
                        <li className="flex items-start">
                          <span className="h-6 w-6 rounded-full bg-red-100 dark:bg-red-900 text-red-600 dark:text-red-400 flex items-center justify-center mr-2 flex-shrink-0 mt-0.5">
                            3
                          </span>
                          <p className="text-gray-600 dark:text-gray-300">{currentTexts.value3}</p>
                        </li>
                      </ul>
                    </div>
                  </motion.div>
                </motion.div>
              </TabsContent>

              <TabsContent value="history" className="space-y-6">
                <motion.div variants={container} initial="hidden" animate="show" className="space-y-6">
                  <motion.div variants={item}>
                    <h2 className="text-2xl font-semibold mb-4 text-gray-800 dark:text-white">
                      {currentTexts.historyTitle}
                    </h2>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">{currentTexts.historyText1}</p>
                    <p className="text-gray-600 dark:text-gray-300">{currentTexts.historyText2}</p>
                  </motion.div>

                  <motion.div variants={item} className="mt-8">
                    <div className="relative h-[300px] w-full rounded-lg overflow-hidden">
                      <Image
                        src="https://images.unsplash.com/photo-1491933382434-500287f9b54b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80"
                        alt="Seven Uz tarixi"
                        fill
                        className="object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-6">
                        <p className="text-white text-lg font-semibold">Birinchi do'konimiz ochilishi (2022)</p>
                      </div>
                    </div>
                  </motion.div>

                  <motion.div variants={item} className="mt-8">
                    <div className="relative overflow-hidden rounded-lg">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm">
                          <div className="text-red-600 dark:text-red-400 text-2xl font-bold mb-2">2020</div>
                          <p className="text-gray-600 dark:text-gray-300">{currentTexts.timeline2020}</p>
                        </div>
                        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm">
                          <div className="text-red-600 dark:text-red-400 text-2xl font-bold mb-2">2022</div>
                          <p className="text-gray-600 dark:text-gray-300">{currentTexts.timeline2022}</p>
                        </div>
                        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm">
                          <div className="text-red-600 dark:text-red-400 text-2xl font-bold mb-2">2025</div>
                          <p className="text-gray-600 dark:text-gray-300">{currentTexts.timeline2025}</p>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                </motion.div>
              </TabsContent>
            </Tabs>
          </motion.div>

          <motion.div
            className="md:col-span-1"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Card className="h-full">
              <CardHeader>
                <CardTitle>{translations.contactUs}</CardTitle>
                <CardDescription>{currentTexts.contactDescription}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start">
                  <MapPin className="h-5 w-5 text-red-500 mr-3 mt-0.5" />
                  <div>
                    <p className="font-medium">{currentTexts.address}</p>
                    <p className="text-gray-600 dark:text-gray-300">Farg'ona, Sayilgoh ko'chasi, 29</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <Phone className="h-5 w-5 text-red-500 mr-3 mt-0.5" />
                  <div>
                    <p className="font-medium">{currentTexts.phone}</p>
                    <p className="text-gray-600 dark:text-gray-300">+998 98 777 11 33</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <Mail className="h-5 w-5 text-red-500 mr-3 mt-0.5" />
                  <div>
                    <p className="font-medium">{currentTexts.email}</p>
                    <p className="text-gray-600 dark:text-gray-300">info@seven.uz</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <Clock className="h-5 w-5 text-red-500 mr-3 mt-0.5" />
                  <div>
                    <p className="font-medium">{currentTexts.workTime}</p>
                    <p className="text-gray-600 dark:text-gray-300">{currentTexts.workTimeWeekdays}</p>
                    <p className="text-gray-600 dark:text-gray-300">{currentTexts.workTimeSunday}</p>
                  </div>
                </div>

                <div className="pt-4">
                  <p className="font-medium mb-2">{currentTexts.socialNetworks}</p>
                  <div className="flex space-x-3">
                    <Link
                      href="https://t.me/seven_uz"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-blue-500 hover:bg-blue-600 text-white p-2 rounded-full transition-colors"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d="M21.5 4.5L2.5 12.5L9.5 13.5L11.5 20.5L21.5 4.5Z"></path>
                      </svg>
                    </Link>
                    <Link
                      href="https://instagram.com/seven_uz"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-pink-500 hover:bg-pink-600 text-white p-2 rounded-full transition-colors"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                        <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                        <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                      </svg>
                    </Link>
                    <Link
                      href="https://facebook.com/sevenuz"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-full transition-colors"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                      </svg>
                    </Link>
                    <Link
                      href="https://youtube.com/sevenuz"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-red-600 hover:bg-red-700 text-white p-2 rounded-full transition-colors"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z"></path>
                        <polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"></polygon>
                      </svg>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* FAQ Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-16"
        >
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-8 text-center">{currentTexts.faqTitle}</h2>
          <div className="max-w-3xl mx-auto">
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger className="text-left">{currentTexts.faqQuestion1}</AccordionTrigger>
                <AccordionContent>{currentTexts.faqAnswer1}</AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-2">
                <AccordionTrigger className="text-left">{currentTexts.faqQuestion2}</AccordionTrigger>
                <AccordionContent>{currentTexts.faqAnswer2}</AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-3">
                <AccordionTrigger className="text-left">{currentTexts.faqQuestion3}</AccordionTrigger>
                <AccordionContent>{currentTexts.faqAnswer3}</AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-4">
                <AccordionTrigger className="text-left">{currentTexts.faqQuestion4}</AccordionTrigger>
                <AccordionContent>{currentTexts.faqAnswer4}</AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-5">
                <AccordionTrigger className="text-left">{currentTexts.faqQuestion5}</AccordionTrigger>
                <AccordionContent>{currentTexts.faqAnswer5}</AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </motion.div>

        {/* Store Locations */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="mt-16"
        >
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-8 text-center">
            {currentTexts.ourStores}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <div className="relative h-48">
                <Image
                  src="https://th.bing.com/th/id/OIP.L44U9CNkvkxwl-7BZtToiQHaE7?w=250&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7"
                  alt="Seven Uz Chilonzor"
                  fill
                  className="object-cover rounded-t-lg"
                />
              </div>
              <CardHeader>
                <CardTitle>{currentTexts.chilonzorBranch}</CardTitle>
                <CardDescription>Farg'ona, Sayilgoh ko'chasi, 29</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 text-red-500 mr-2" />
                    <span>{currentTexts.workingHours}</span>
                  </div>
                  <div className="flex items-center">
                    <Phone className="h-4 w-4 text-red-500 mr-2" />
                    <span>+998 98 777 11 33</span>
                  </div>
                  <Link
                    href="https://yandex.uz/navi?whatshere%5Bpoint%5D=71.78416774147561%2C40.38577267242549&whatshere%5Bzoom%5D=17.423103&ll=71.7841677414756%2C40.385772672052916&z=17.423103"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-red-600 hover:underline flex items-center mt-2"
                  >
                    <MapPin className="h-4 w-4 mr-2" />
                    {currentTexts.viewOnMap}
                  </Link>
                </div>
              </CardContent>
            </Card>

            <Card>
              <div className="relative h-48">
                <Image
                  src="https://images.unsplash.com/photo-1491933382434-500287f9b54b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80"
                  alt="Seven Uz Yunusobod"
                  fill
                  className="object-cover rounded-t-lg"
                />
              </div>
              <CardHeader>
                <CardTitle>{currentTexts.yunusobodBranch}</CardTitle>
                <CardDescription>Farg'ona, Yunusobod tumani, 4-mavze, 12-uy</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 text-red-500 mr-2" />
                    <span>{currentTexts.workingHours}</span>
                  </div>
                  <div className="flex items-center">
                    <Phone className="h-4 w-4 text-red-500 mr-2" />
                    <span>+998 99 987 65 43</span>
                  </div>
                  <Link
                    href="https://yandex.uz/navi?whatshere%5Bpoint%5D=71.78416774147561%2C40.38577267242549&whatshere%5Bzoom%5D=17.423103&ll=71.7841677414756%2C40.385772672052916&z=17.423103"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-red-600 hover:underline flex items-center mt-2"
                  >
                    <MapPin className="h-4 w-4 mr-2" />
                    {currentTexts.viewOnMap}
                  </Link>
                </div>
              </CardContent>
            </Card>

            <Card>
              <div className="relative h-48">
                <Image
                  src="https://images.unsplash.com/photo-1581287053822-fd7bf4f4bfec?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2340&q=80"
                  alt="Seven Uz Sergeli"
                  fill
                  className="object-cover rounded-t-lg"
                />
              </div>
              <CardHeader>
                <CardTitle>{currentTexts.sergeliBranch}</CardTitle>
                <CardDescription>Farg'ona, Sergeli tumani, 4-mavze, 12-uy</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 text-red-500 mr-2" />
                    <span>{currentTexts.workingHours}</span>
                  </div>
                  <div className="flex items-center">
                    <Phone className="h-4 w-4 text-red-500 mr-2" />
                    <span>+998 99 456 78 90</span>
                  </div>
                  <Link
                    href="https://yandex.uz/navi?whatshere%5Bpoint%5D=71.78416774147561%2C40.38577267242549&whatshere%5Bzoom%5D=17.423103&ll=71.7841677414756%2C40.385772672052916&z=17.423103"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-red-600 hover:underline flex items-center mt-2"
                  >
                    <MapPin className="h-4 w-4 mr-2" />
                    {currentTexts.viewOnMap}
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
