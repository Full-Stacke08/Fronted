"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useCart } from "@/components/cart-provider"
import { useAuth } from "@/components/auth-provider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { CreditCard, Calendar, Clock, MapPin, Truck, CheckCircle2, ArrowLeft, Loader2 } from "lucide-react"
import { submitOrder } from "@/components/order-service"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

type DeliveryMethod = "pickup" | "courier"
type PaymentMethod = "installment" | "cash" | "card"
type OrderStatus = "idle" | "submitting" | "success" | "error" | "pending_review"

export default function CheckoutPage() {
  const router = useRouter()
  const { cartItems, totalPrice, clearCart } = useCart()
  const { user } = useAuth()
  const [deliveryMethod, setDeliveryMethod] = useState<DeliveryMethod>("pickup")
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("card")
  const [installmentMonths, setInstallmentMonths] = useState(3)
  const [cardNumber, setCardNumber] = useState("")
  const [cardExpiry, setCardExpiry] = useState("")
  const [cardName, setCardName] = useState("")
  const [promoCode, setPromoCode] = useState("")
  const [discount, setDiscount] = useState(0)
  const [orderStatus, setOrderStatus] = useState<OrderStatus>("idle")
  const [orderId, setOrderId] = useState<string | null>(null)
  const [errorMessage, setErrorMessage] = useState("")

  // Customer information
  const [name, setName] = useState(user?.name || "")
  const [phone, setPhone] = useState(user?.phone || "")
  const [email, setEmail] = useState(user?.email || "")
  const [address, setAddress] = useState("")
  const [additionalInfo, setAdditionalInfo] = useState("")

  const handleApplyPromoCode = () => {
    if (promoCode === "L256O20") {
      const discountAmount = totalPrice * 0.2
      setDiscount(discountAmount)
    } else {
      setDiscount(0)
      // Show error message
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (cartItems.length === 0) {
      setErrorMessage("Your cart is empty")
      setOrderStatus("error")
      return
    }

    setOrderStatus("submitting")

    // Calculate final price
    const finalPrice = paymentMethod === "installment" ? totalPrice * 1.15 - discount : totalPrice - discount

    // Prepare order data
    const orderData = {
      customerName: name,
      customerPhone: phone,
      customerEmail: email,
      products: cartItems.map((item) => ({
        id: item.id,
        name: item.name,
        price: item.price,
        quantity: item.quantity,
        image: item.image,
      })),
      totalPrice: finalPrice,
      deliveryMethod,
      paymentMethod,
      ...(paymentMethod === "installment" && { installmentMonths }),
      ...(deliveryMethod === "courier" && { address }),
      ...(additionalInfo && { additionalInfo }),
    }

    try {
      const result = await submitOrder(orderData)

      if (result.success) {
        setOrderId(result.orderId || null)

        // For installment payments, show "pending review" status
        if (paymentMethod === "installment") {
          setOrderStatus("pending_review")
        } else {
          setOrderStatus("success")
          clearCart()

          // Redirect to success page after a delay for non-installment orders
          setTimeout(() => {
            router.push("/")
          }, 3000)
        }
      } else {
        setErrorMessage(result.message)
        setOrderStatus("error")
      }
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : "An unknown error occurred")
      setOrderStatus("error")
    }
  }

  if (cartItems.length === 0 && orderStatus !== "success" && orderStatus !== "pending_review") {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="max-w-md mx-auto">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Your Cart is Empty</h1>
          <p className="text-gray-600 dark:text-gray-400 mb-8">
            You need to add products to your cart before checkout.
          </p>
          <Link href="/">
            <Button className="bg-red-600 hover:bg-red-700">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Continue Shopping
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  if (orderStatus === "success") {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="max-w-md mx-auto">
          <div className="mb-6 text-green-500 dark:text-green-400 flex justify-center">
            <CheckCircle2 className="h-16 w-16" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Order Completed!</h1>
          <p className="text-gray-600 dark:text-gray-400 mb-8">
            Thank you for your purchase. Your order has been successfully placed.
          </p>
          <Link href="/">
            <Button className="bg-red-600 hover:bg-red-700">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Return to Home
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  if (orderStatus === "pending_review") {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="max-w-md mx-auto">
          <div className="mb-6 text-amber-500 dark:text-amber-400 flex justify-center">
            <Clock className="h-16 w-16" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Order Under Review</h1>
          <p className="text-gray-600 dark:text-gray-400 mb-8">
            Thank you for your order! Your installment payment request is being reviewed by our team. We will process
            your request within 5 minutes.
          </p>
          <p className="text-gray-600 dark:text-gray-400 mb-8">
            Order ID: <span className="font-medium">{orderId}</span>
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/">
              <Button className="bg-red-600 hover:bg-red-700 w-full">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Return to Home
              </Button>
            </Link>
            <Link href="/account/requests">
              <Button variant="outline" className="w-full">
                View My Requests
              </Button>
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-8">Checkout</h1>

      {orderStatus === "error" && (
        <Alert variant="destructive" className="mb-6">
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>
            {errorMessage || "There was an error processing your order. Please try again."}
          </AlertDescription>
        </Alert>
      )}

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            {/* Delivery Method */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
              <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Delivery Method</h2>

              <RadioGroup
                value={deliveryMethod}
                onValueChange={(value) => setDeliveryMethod(value as DeliveryMethod)}
                className="space-y-4"
              >
                <div className="flex items-center space-x-2 border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                  <RadioGroupItem value="pickup" id="pickup" />
                  <Label htmlFor="pickup" className="flex items-center cursor-pointer">
                    <MapPin className="h-5 w-5 mr-2 text-gray-500 dark:text-gray-400" />
                    <div>
                      <span className="font-medium">Pickup Point</span>
                      <span className="ml-2 text-sm text-green-600 dark:text-green-400">Free</span>
                    </div>
                  </Label>
                </div>

                <div className="flex items-center space-x-2 border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                  <RadioGroupItem value="courier" id="courier" />
                  <Label htmlFor="courier" className="flex items-center cursor-pointer">
                    <Truck className="h-5 w-5 mr-2 text-gray-500 dark:text-gray-400" />
                    <div>
                      <span className="font-medium">Courier Delivery</span>
                      <span className="ml-2 text-sm text-green-600 dark:text-green-400">Free</span>
                    </div>
                  </Label>
                </div>
              </RadioGroup>

                            {deliveryMethod === "pickup" && (
                  <div className="mt-4">
                    <div className="aspect-video w-full h-64 rounded-lg overflow-hidden mt-4 bg-gray-100 dark:bg-gray-700">
                      <iframe
                        src="https://yandex.uz/map-widget/v1/?um=constructor%3Ayour_constructor_id_here&amp;source=constructor"
                        width="100%"
                        height="100%"
                        style={{ border: 0 }}
                        allowFullScreen
                        loading="lazy"
                        referrerPolicy="no-referrer-when-downgrade"
                      ></iframe>
                    </div>
                  </div>
                )}

            </div>

            {/* Customer Information */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
              <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Customer Information</h2>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Full Name</Label>
                  <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
                </div>

                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input id="phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} required />
                </div>

                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
                </div>

                {deliveryMethod === "courier" && (
                  <div>
                    <Label htmlFor="address">Delivery Address</Label>
                    <Input
                      id="address"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      required={deliveryMethod === "courier"}
                    />
                  </div>
                )}

                <div>
                  <Label htmlFor="additionalInfo">Additional Information (Optional)</Label>
                  <Textarea
                    id="additionalInfo"
                    value={additionalInfo}
                    onChange={(e) => setAdditionalInfo(e.target.value)}
                    placeholder="Any special instructions or notes for your order"
                    className="resize-none"
                  />
                </div>
              </div>
            </div>

            {/* Payment Method */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
              <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Payment Method</h2>

              <RadioGroup
                value={paymentMethod}
                onValueChange={(value) => setPaymentMethod(value as PaymentMethod)}
                className="space-y-4"
              >
                <div className="flex items-center space-x-2 border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                  <RadioGroupItem value="installment" id="installment" />
                  <Label htmlFor="installment" className="flex items-center cursor-pointer">
                    <Calendar className="h-5 w-5 mr-2 text-gray-500 dark:text-gray-400" />
                    <span className="font-medium">Installment Payment</span>
                  </Label>
                </div>

                <div className="flex items-center space-x-2 border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                  <RadioGroupItem value="cash" id="cash" />
                  <Label htmlFor="cash" className="flex items-center cursor-pointer">
                    <Clock className="h-5 w-5 mr-2 text-gray-500 dark:text-gray-400" />
                    <span className="font-medium">Cash on Delivery</span>
                  </Label>
                </div>

                <div className="flex items-center space-x-2 border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                  <RadioGroupItem value="card" id="card" />
                  <Label htmlFor="card" className="flex items-center cursor-pointer">
                    <CreditCard className="h-5 w-5 mr-2 text-gray-500 dark:text-gray-400" />
                    <span className="font-medium">Credit/Debit Card</span>
                  </Label>
                </div>
              </RadioGroup>

              {paymentMethod === "installment" && (
                <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                  <h3 className="text-sm font-medium text-gray-900 dark:text-white mb-3">Choose Installment Period</h3>

                  <div className="grid grid-cols-3 gap-3">
                    {[3, 6, 12].map((months) => (
                      <div key={months}>
                        <input
                          type="radio"
                          id={`months-${months}`}
                          name="installmentMonths"
                          value={months}
                          checked={installmentMonths === months}
                          onChange={() => setInstallmentMonths(months)}
                          className="sr-only"
                        />
                        <label
                          htmlFor={`months-${months}`}
                          className={`block text-center p-3 rounded-lg cursor-pointer border ${
                            installmentMonths === months
                              ? "border-red-600 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400"
                              : "border-gray-200 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800"
                          }`}
                        >
                          <span className="block font-medium">{months} months</span>
                          <span className="block text-sm mt-1">${((totalPrice * 1.15) / months).toFixed(2)}/month</span>
                        </label>
                      </div>
                    ))}
                  </div>

                  <div className="mt-4 space-y-3">
                    <div>
                      <Label htmlFor="card-number">Card Number</Label>
                      <Input
                        id="card-number"
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value)}
                        required={paymentMethod === "installment"}
                        placeholder="1234 5678 9012 3456"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label htmlFor="card-expiry">Expiry Date</Label>
                        <Input
                          id="card-expiry"
                          value={cardExpiry}
                          onChange={(e) => setCardExpiry(e.target.value)}
                          required={paymentMethod === "installment"}
                          placeholder="MM/YY"
                        />
                      </div>

                      <div>
                        <Label htmlFor="card-name">Cardholder Name</Label>
                        <Input
                          id="card-name"
                          value={cardName}
                          onChange={(e) => setCardName(e.target.value)}
                          required={paymentMethod === "installment"}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {paymentMethod === "card" && (
                <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg space-y-3">
                  <div>
                    <Label htmlFor="card-number-full">Card Number</Label>
                    <Input
                      id="card-number-full"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      required={paymentMethod === "card"}
                      placeholder="1234 5678 9012 3456"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label htmlFor="card-expiry-full">Expiry Date</Label>
                      <Input
                        id="card-expiry-full"
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        required={paymentMethod === "card"}
                        placeholder="MM/YY"
                      />
                    </div>

                    <div>
                      <Label htmlFor="card-name-full">Cardholder Name</Label>
                      <Input
                        id="card-name-full"
                        value={cardName}
                        onChange={(e) => setCardName(e.target.value)}
                        required={paymentMethod === "card"}
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 sticky top-20">
              <h2 className="text-lg font-medium text-gray-900 dark:text-white mb-6">Order Summary</h2>

              <div className="max-h-64 overflow-y-auto mb-4">
                <ul className="space-y-3">
                  {cartItems.map((item) => (
                    <li key={item.id} className="flex items-center">
                      <div className="h-16 w-16 flex-shrink-0 rounded-md overflow-hidden border border-gray-200 dark:border-gray-700">
                        <Image
                          src={item.image || "/placeholder.svg"}
                          alt={item.name}
                          width={64}
                          height={64}
                          className="h-full w-full object-cover"
                        />
                      </div>
                      <div className="ml-3 flex-1">
                        <p className="text-sm font-medium text-gray-900 dark:text-white">{item.name}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Qty: {item.quantity}</p>
                      </div>
                      <p className="text-sm font-medium text-gray-900 dark:text-white">
                        ${(item.price * item.quantity).toFixed(2)}
                      </p>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between">
                  <p className="text-gray-600 dark:text-gray-400">Subtotal</p>
                  <p className="font-medium text-gray-900 dark:text-white">${totalPrice.toFixed(2)}</p>
                </div>

                <div className="flex justify-between">
                  <p className="text-gray-600 dark:text-gray-400">Shipping</p>
                  <p className="font-medium text-green-600 dark:text-green-400">Free</p>
                </div>

                {paymentMethod === "installment" && (
                  <div className="flex justify-between">
                    <p className="text-gray-600 dark:text-gray-400">Interest (15%)</p>
                    <p className="font-medium text-gray-900 dark:text-white">${(totalPrice * 0.15).toFixed(2)}</p>
                  </div>
                )}

                {discount > 0 && (
                  <div className="flex justify-between">
                    <p className="text-gray-600 dark:text-gray-400">Discount (20%)</p>
                    <p className="font-medium text-red-600 dark:text-red-400">-${discount.toFixed(2)}</p>
                  </div>
                )}

                <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
                  <div className="flex justify-between">
                    <p className="text-lg font-medium text-gray-900 dark:text-white">Total</p>
                    <p className="text-lg font-bold text-gray-900 dark:text-white">
                      $
                      {(paymentMethod === "installment" ? totalPrice * 1.15 - discount : totalPrice - discount).toFixed(
                        2,
                      )}
                    </p>
                  </div>

                  {paymentMethod === "installment" && (
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 text-right">
                      ${((totalPrice * 1.15 - discount) / installmentMonths).toFixed(2)} × {installmentMonths} months
                    </p>
                  )}
                </div>
              </div>

              <div className="mt-6">
                <div className="flex items-center space-x-2 mb-4">
                  <Input
                    type="text"
                    placeholder="Promo code"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    className="flex-1"
                  />
                  <Button type="button" onClick={handleApplyPromoCode} variant="outline">
                    Apply
                  </Button>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-red-600 hover:bg-red-700"
                  disabled={orderStatus === "submitting"}
                >
                  {orderStatus === "submitting" ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    "Complete Order"
                  )}
                </Button>

                <div className="mt-4 text-center">
                  <Link href="/cart" className="text-sm text-red-600 dark:text-red-400 hover:underline">
                    <ArrowLeft className="inline h-4 w-4 mr-1" />
                    Back to Cart
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  )
}
