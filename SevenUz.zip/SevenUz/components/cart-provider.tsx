"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

interface CartItem {
  id: string
  name: string
  price: number
  quantity: number
  image: string
}

interface CartContextType {
  cartItems: CartItem[]
  addToCart: (item: CartItem) => void
  removeFromCart: (id: string) => void
  updateQuantity: (id: string, quantity: number) => void
  clearCart: () => void
  totalItems: number
  totalPrice: number
  promoCode: string
  discount: number
  setPromoCode: (code: string) => void
  applyPromoCode: () => boolean
}

const CartContext = createContext<CartContextType>({
  cartItems: [],
  addToCart: () => {},
  removeFromCart: () => {},
  updateQuantity: () => {},
  clearCart: () => {},
  totalItems: 0,
  totalPrice: 0,
  promoCode: "",
  discount: 0,
  setPromoCode: () => {},
  applyPromoCode: () => false,
})

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [cartItems, setCartItems] = useState<CartItem[]>([])
  const [totalItems, setTotalItems] = useState(0)
  const [totalPrice, setTotalPrice] = useState(0)
  const [promoCode, setPromoCode] = useState("")
  const [discount, setDiscount] = useState(0)
  const [appliedPromo, setAppliedPromo] = useState(false)

  useEffect(() => {
    const savedCart = localStorage.getItem("cart")
    const savedPromo = localStorage.getItem("promoCode")
    const savedDiscount = localStorage.getItem("discount")

    if (savedCart) {
      try {
        const parsedCart = JSON.parse(savedCart)
        setCartItems(parsedCart)
      } catch (error) {
        console.error("Failed to parse cart data:", error)
        localStorage.removeItem("cart")
      }
    }

    if (savedPromo) {
      setPromoCode(savedPromo)
      setAppliedPromo(true)
    }

    if (savedDiscount) {
      setDiscount(Number.parseFloat(savedDiscount))
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cartItems))

    const items = cartItems.reduce((total, item) => total + item.quantity, 0)
    setTotalItems(items)

    const price = cartItems.reduce((total, item) => total + item.price * item.quantity, 0)
    setTotalPrice(price)
  }, [cartItems])

  const addToCart = (item: CartItem) => {
    setCartItems((prevItems) => {
      const existingItem = prevItems.find((i) => i.id === item.id)

      if (existingItem) {
        return prevItems.map((i) => (i.id === item.id ? { ...i, quantity: i.quantity + item.quantity } : i))
      }

      return [...prevItems, item]
    })
  }

  const removeFromCart = (id: string) => {
    setCartItems((prevItems) => prevItems.filter((item) => item.id !== id))
  }

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(id)
      return
    }

    setCartItems((prevItems) => prevItems.map((item) => (item.id === id ? { ...item, quantity } : item)))
  }

  const clearCart = () => {
    setCartItems([])
  }

  const applyPromoCode = () => {
    if (promoCode === "L256O20" && !appliedPromo) {
      const discountAmount = totalPrice * 0.2
      setDiscount(discountAmount)
      setAppliedPromo(true)
      localStorage.setItem("promoCode", promoCode)
      localStorage.setItem("discount", discountAmount.toString())
      return true
    }
    return false
  }

  return (
    <CartContext.Provider
      value={{
        cartItems,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        totalItems,
        totalPrice,
        promoCode,
        discount,
        setPromoCode,
        applyPromoCode,
      }}
    >
      {children}
    </CartContext.Provider>
  )
}

export const useCart = () => useContext(CartContext)
