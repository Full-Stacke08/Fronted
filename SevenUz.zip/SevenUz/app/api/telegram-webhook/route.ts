import { handleTelegramWebhook } from "@/lib/telegram"

export async function POST(req: Request) {
  return handleTelegramWebhook(req)
}
