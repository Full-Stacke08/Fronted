"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { Mail, Phone, MapPin, Calendar, Package, Heart, LogOut, Edit, Trash, Plus, Tag, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useAuth } from "@/components/auth-provider"
import { useToast } from "@/hooks/use-toast"

export default function ProfilePage() {
  const { user, logout, updateUser, addAddress, removeAddress } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  const [newAddress, setNewAddress] = useState({
    street: "",
    city: "",
    postalCode: "",
    country: "O'zbekiston",
  })

  const [editMode, setEditMode] = useState(false)
  const [editedUser, setEditedUser] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
  })

  useEffect(() => {
    // Redirect if not logged in
    if (!user) {
      router.push("/login")
      return
    }

    // Initialize edit form with current user data
    setEditedUser({
      firstName: user.firstName || "",
      lastName: user.lastName || "",
      email: user.email || "",
      phone: user.phone || "",
    })
  }, [user, router])

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600"></div>
      </div>
    )
  }

  const handleLogout = () => {
    logout()
    router.push("/")
    toast({
      title: "Tizimdan chiqdingiz",
      description: "Muvaffaqiyatli tizimdan chiqdingiz.",
    })
  }

  const handleSaveProfile = () => {
    updateUser({
      firstName: editedUser.firstName,
      lastName: editedUser.lastName,
      email: editedUser.email,
      phone: editedUser.phone,
    })
    setEditMode(false)
    toast({
      title: "Profil yangilandi",
      description: "Sizning profil ma'lumotlaringiz muvaffaqiyatli yangilandi.",
    })
  }

  const handleAddAddress = () => {
    if (!newAddress.street || !newAddress.city) {
      toast({
        title: "Xatolik",
        description: "Iltimos, barcha majburiy maydonlarni to'ldiring.",
        variant: "destructive",
      })
      return
    }

    addAddress(newAddress)
    setNewAddress({
      street: "",
      city: "",
      postalCode: "",
      country: "O'zbekiston",
    })

    toast({
      title: "Manzil qo'shildi",
      description: "Yangi manzil muvaffaqiyatli qo'shildi.",
    })
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("uz-UZ", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(date)
  }

  const getInitials = (firstName: string, lastName: string) => {
    return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase()
  }

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 },
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 lg:grid-cols-3 gap-8"
      >
        {/* Profile Sidebar */}
        <motion.div variants={item} className="lg:col-span-1">
          <Card>
            <CardHeader className="text-center">
              <Avatar className="w-24 h-24 mx-auto">
                <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.firstName} />
                <AvatarFallback className="text-xl bg-red-600 text-white">
                  {getInitials(user.firstName, user.lastName)}
                </AvatarFallback>
              </Avatar>
              <CardTitle className="mt-4 text-2xl">
                {user.firstName} {user.lastName}
              </CardTitle>
              <CardDescription>Ro'yxatdan o'tgan: {formatDate(user.dateJoined)}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {user.email && (
                <div className="flex items-center space-x-3">
                  <Mail className="h-5 w-5 text-gray-500" />
                  <span>{user.email}</span>
                </div>
              )}
              {user.phone && (
                <div className="flex items-center space-x-3">
                  <Phone className="h-5 w-5 text-gray-500" />
                  <span>{user.phone}</span>
                </div>
              )}
              <div className="flex items-center space-x-3">
                <Calendar className="h-5 w-5 text-gray-500" />
                <span>Oxirgi kirish: {formatDate(user.lastLogin)}</span>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" onClick={() => setEditMode(true)}>
                <Edit className="mr-2 h-4 w-4" /> Profilni tahrirlash
              </Button>
            </CardFooter>
          </Card>

        </motion.div>

        {/* Main Content */}
        <motion.div variants={item} className="lg:col-span-2">
          {editMode ? (
            <Card>
              <CardHeader>
                <CardTitle>Profilni tahrirlash</CardTitle>
                <CardDescription>Profil ma'lumotlaringizni yangilang</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">Ism</Label>
                    <Input
                      id="firstName"
                      value={editedUser.firstName}
                      onChange={(e) => setEditedUser({ ...editedUser, firstName: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Familiya</Label>
                    <Input
                      id="lastName"
                      value={editedUser.lastName}
                      onChange={(e) => setEditedUser({ ...editedUser, lastName: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={editedUser.email}
                    onChange={(e) => setEditedUser({ ...editedUser, email: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Telefon</Label>
                  <Input
                    id="phone"
                    value={editedUser.phone}
                    onChange={(e) => setEditedUser({ ...editedUser, phone: e.target.value })}
                  />
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={() => setEditMode(false)}>
                  Bekor qilish
                </Button>
                <Button onClick={handleSaveProfile}>Saqlash</Button>
              </CardFooter>
            </Card>
          ) : (
            <Tabs defaultValue="addresses">
              <TabsList className="grid grid-cols-3 mb-8">
                <TabsTrigger value="addresses">Manzillar</TabsTrigger>
                <TabsTrigger value="orders">Buyurtmalar</TabsTrigger>
                <TabsTrigger value="promo">Promo kodlar</TabsTrigger>
              </TabsList>

              <TabsContent value="addresses">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>Mening manzillarim</CardTitle>
                      <CardDescription>Yetkazib berish uchun manzillaringizni boshqaring</CardDescription>
                    </div>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button size="sm">
                          <Plus className="mr-2 h-4 w-4" /> Manzil qo'shish
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Yangi manzil qo'shish</DialogTitle>
                          <DialogDescription>Yetkazib berish uchun yangi manzil qo'shing</DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <div className="space-y-2">
                            <Label htmlFor="street">Ko'cha manzili *</Label>
                            <Input
                              id="street"
                              placeholder="Ko'cha, uy, kvartira"
                              value={newAddress.street}
                              onChange={(e) => setNewAddress({ ...newAddress, street: e.target.value })}
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label htmlFor="city">Shahar *</Label>
                              <Input
                                id="city"
                                placeholder="Shahar"
                                value={newAddress.city}
                                onChange={(e) => setNewAddress({ ...newAddress, city: e.target.value })}
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="postalCode">Pochta indeksi</Label>
                              <Input
                                id="postalCode"
                                placeholder="Pochta indeksi"
                                value={newAddress.postalCode}
                                onChange={(e) => setNewAddress({ ...newAddress, postalCode: e.target.value })}
                              />
                            </div>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="country">Davlat</Label>
                            <Input
                              id="country"
                              value={newAddress.country}
                              onChange={(e) => setNewAddress({ ...newAddress, country: e.target.value })}
                            />
                          </div>
                        </div>
                        <DialogFooter>
                          <Button onClick={handleAddAddress}>Qo'shish</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </CardHeader>
                  <CardContent>
                    {user.addresses.length === 0 ? (
                      <div className="text-center py-8 text-gray-500">
                        <MapPin className="mx-auto h-12 w-12 text-gray-400" />
                        <h3 className="mt-2 text-sm font-semibold">Manzillar yo'q</h3>
                        <p className="mt-1 text-sm">Hali hech qanday manzil qo'shilmagan.</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {user.addresses.map((address, index) => (
                          <Card key={index}>
                            <CardContent className="p-4">
                              <div className="flex justify-between items-start">
                                <div className="space-y-1">
                                  <div className="font-medium">{address.street}</div>
                                  <div className="text-sm text-gray-500">
                                    {address.city}
                                    {address.postalCode ? `, ${address.postalCode}` : ""}, {address.country}
                                  </div>
                                </div>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="text-red-500 hover:text-red-700 hover:bg-red-50"
                                  onClick={() => {
                                    removeAddress(index)
                                    toast({
                                      title: "Manzil o'chirildi",
                                      description: "Manzil muvaffaqiyatli o'chirildi.",
                                    })
                                  }}
                                >
                                  <Trash className="h-4 w-4" />
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="orders">
                <Card>
                  <CardHeader>
                    <CardTitle>Mening buyurtmalarim</CardTitle>
                    <CardDescription>Barcha buyurtmalaringiz tarixi</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {user.orders.length === 0 ? (
                      <div className="text-center py-8 text-gray-500">
                        <Package className="mx-auto h-12 w-12 text-gray-400" />
                        <h3 className="mt-2 text-sm font-semibold">Buyurtmalar yo'q</h3>
                        <p className="mt-1 text-sm">Siz hali hech narsa buyurtma qilmagansiz.</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {user.orders.map((order) => (
                          <Card key={order.id}>
                            <CardContent className="p-4">
                              <div className="flex justify-between items-center mb-2">
                                <div className="font-medium">Buyurtma #{order.id}</div>
                                <Badge
                                  variant={
                                    order.status === "delivered"
                                      ? "default"
                                      : order.status === "shipped"
                                        ? "secondary"
                                        : order.status === "processing"
                                          ? "outline"
                                          : order.status === "cancelled"
                                            ? "destructive"
                                            : "default"
                                  }
                                >
                                  {order.status === "delivered"
                                    ? "Yetkazilgan"
                                    : order.status === "shipped"
                                      ? "Yo'lda"
                                      : order.status === "processing"
                                        ? "Jarayonda"
                                        : order.status === "cancelled"
                                          ? "Bekor qilingan"
                                          : "Kutilmoqda"}
                                </Badge>
                              </div>
                              <div className="text-sm text-gray-500 mb-2">{formatDate(order.date)}</div>
                              <Separator className="my-2" />
                              <div className="space-y-2">
                                {order.products.map((product) => (
                                  <div key={product.id} className="flex justify-between items-center">
                                    <div>
                                      <div className="font-medium">{product.name}</div>
                                      <div className="text-sm text-gray-500">Miqdori: {product.quantity}</div>
                                    </div>
                                    <div className="font-medium">{product.price.toLocaleString()} so'm</div>
                                  </div>
                                ))}
                              </div>
                              <Separator className="my-2" />
                              <div className="flex justify-between items-center font-bold">
                                <div>Jami:</div>
                                <div>{order.total.toLocaleString()} so'm</div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="promo">
                <Card>
                  <CardHeader>
                    <CardTitle>Promo kodlar</CardTitle>
                    <CardDescription>Sizning promo kodlaringiz va chegirmalaringiz</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {user.promoCodes.length === 0 ? (
                      <div className="text-center py-8 text-gray-500">
                        <Tag className="mx-auto h-12 w-12 text-gray-400" />
                        <h3 className="mt-2 text-sm font-semibold">Promo kodlar yo'q</h3>
                        <p className="mt-1 text-sm">Sizda hali hech qanday promo kod yo'q.</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {user.promoCodes.map((promo, index) => (
                          <Card key={index}>
                            <CardContent className="p-4">
                              <div className="flex justify-between items-center">
                                <div>
                                  <div className="font-medium text-lg">{promo.code}</div>
                                  <div className="text-sm text-gray-500">{promo.discount}% chegirma</div>
                                  {promo.used && promo.dateUsed && (
                                    <div className="text-xs text-gray-400">
                                      Ishlatilgan: {formatDate(promo.dateUsed)}
                                    </div>
                                  )}
                                </div>
                                {promo.used ? (
                                  <Badge variant="outline" className="bg-gray-100">
                                    <Check className="mr-1 h-3 w-3" /> Ishlatilgan
                                  </Badge>
                                ) : (
                                  <Badge variant="default" className="bg-green-600">
                                    Faol
                                  </Badge>
                                )}
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          )}
        </motion.div>
      </motion.div>
    </div>
  )
}
