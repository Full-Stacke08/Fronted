export interface Product {
  featureSections?: any
  id: string
  name: string
  nameUz?: string
  nameRu?: string
  price: number
  oldPrice?: number
  description?: string
  descriptionUz?: string
  descriptionRu?: string
  image?: string
  images?: string[]
  category: string
  categoryUz?: string
  categoryRu?: string
  categoryId?: string
  rating?: number
  reviews?: number
  isNew?: boolean
  isBestseller?: boolean
  isOnSale?: boolean
  memory?: string
  color?: string
  colorUz?: string
  colorRu?: string
  condition?: string
  conditionUz?: string
  conditionRu?: string
  availability?: string
  availabilityUz?: string
  availabilityRu?: string
  features?: string[]
  featuresUz?: string[]
  featuresRu?: string[]
  specifications?: Record<string, string>
  specificationsUz?: Record<string, string>
  specificationsRu?: Record<string, string>
}

export interface ProductVariant {
  id: string
  name: string
  price: number
  color?: string
  storage?: string
  image?: string
}

export interface Category {
  id: string
  name: string
  nameUz?: string
  nameRu?: string
  slug: string
  image?: string
  subCategories?: Category[]
}

export interface CartItem {
  id: string
  name: string
  price: number
  quantity: number
  image?: string
}

export interface Order {
  id: string
  items: CartItem[]
  total: number
  status: string
  date: string
  customer: {
    name: string
    email: string
    phone: string
    address: string
  }
}

export type OrderStatus = "pending" | "processing" | "shipped" | "delivered" | "cancelled"

export type PaymentMethod = "cash" | "card" | "installment"

export interface ShippingAddress {
  fullName: string
  address: string
  city: string
  postalCode?: string
  phone: string
}

export interface User {
  id: string
  name: string
  email: string
  phone: string
  address?: string
  orders?: Order[]
}

export interface LoginCredentials {
  email: string
  password: string
}

export interface RegistrationData {
  name: string
  email: string
  password: string
  phone?: string
}

export interface ReviewData {
  productId: string
  userId: string
  rating: number
  comment: string
  date: Date
}
