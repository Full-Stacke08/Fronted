import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Check, ChevronRight, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

export default function IPhone16ProMaxPage() {
  return (
    <div className="bg-white dark:bg-gray-950">
      {/* Breadcrumb */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
          <Link href="/" className="hover:text-red-600 dark:hover:text-red-400">
            Bosh sahifa
          </Link>
          <ChevronRight className="h-4 w-4 mx-2" />
          <Link href="/category/smartphones" className="hover:text-red-600 dark:hover:text-red-400">
            Smartfonlar
          </Link>
          <ChevronRight className="h-4 w-4 mx-2" />
          <span className="text-gray-900 dark:text-white">iPhone 16 Pro Max</span>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-b from-gray-100 to-white dark:from-gray-900 dark:to-gray-950 py-12 md:py-20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="w-full md:w-1/2 mb-8 md:mb-0">
              <Link href="/" className="inline-flex items-center text-red-600 mb-6 hover:underline">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Orqaga
              </Link>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-4">
                iPhone 16 Pro Max (2025)
              </h1>
              <div className="flex items-center mb-4">
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="h-5 w-5 fill-current text-yellow-500" />
                  ))}
                </div>
                <span className="ml-2 text-gray-600 dark:text-gray-400">4.9 (1,256 sharh)</span>
              </div>
              <p className="text-lg text-gray-700 dark:text-gray-300 mb-6">
                Apple'ning eng yangi va eng kuchli smartfoni. Yangi A19 Pro protsessori, yangilangan kamera tizimi va
                yanada ko'proq xotira bilan.
              </p>
              <div className="flex items-center mb-6">
                <span className="text-3xl font-bold text-gray-900 dark:text-white">14,999,000 so'm</span>
                <Badge className="ml-3 bg-green-600">Muddatli to'lov mavjud</Badge>
              </div>
              <div className="flex flex-wrap gap-4">
                <Button size="lg" className="bg-red-600 hover:bg-red-700">
                 Savatga qo'shish
                </Button>
                 
              </div>
            </div>
            <div className="w-full md:w-1/2 flex justify-center">
              <div className="relative h-[400px] w-[700px]">
                <Image
                  src="https://th.bing.com/th/id/OIP.jx_EnIpqYd1WF3fsxDULNwHaEK?w=324&h=182&c=7&r=0&o=5&dpr=1.3&pid=1.7"
                  alt="iPhone 16 Pro Max"
                  fill
                  className="object-contain"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Product Details */}
      <div className="container mx-auto px-4 py-12">
        <Tabs defaultValue="features" className="w-full">
          <TabsList className="grid w-full md:w-auto grid-cols-3 mb-8">
            <TabsTrigger value="features">Xususiyatlar</TabsTrigger>
            <TabsTrigger value="specifications">Texnik ma'lumotlar</TabsTrigger>
            <TabsTrigger value="reviews">Sharhlar</TabsTrigger>
          </TabsList>
          <TabsContent value="features" className="space-y-12">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                  A19 Pro - Eng kuchli protsessor
                </h2>
                <p className="text-gray-700 dark:text-gray-300 mb-4">
                  Yangi A19 Pro protsessori avvalgidan 40% tezroq va 30% energiya samaradorroq. Bu sizga kunning
                  oxirigacha batareya quvvatini saqlagan holda eng talabchan ilovalarni ham muammosiz ishlatish imkonini
                  beradi.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">
                      5nm texnologiyasi asosida ishlab chiqarilgan
                    </span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">
                      16-yadroli Neural Engine sun'iy intellekt operatsiyalari uchun
                    </span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">
                      Yangilangan grafik protsessor o'yinlar va AR uchun
                    </span>
                  </li>
                </ul>
              </div>
              <div className="relative h-[300px]">
                <Image
                  src="https://macbro.uz/cdn/shop/files/iphone_16_pro_max_desert_2_596x_crop_center.png?v=1747058732"
                  alt="A19 Pro Processor"
                  fill
                  className="object-contain"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div className="order-2 md:order-1 relative h-[300px]">
                <Image
                  src="https://th.bing.com/th/id/OIP.E47SONail_v-ReNcWnPy5AHaE7?w=277&h=184&c=7&r=0&o=5&dpr=1.3&pid=1.7"
                  alt="Camera System"
                  fill
                  className="object-contain"
                />
              </div>
              <div className="order-1 md:order-2">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Professional kamera tizimi</h2>
                <p className="text-gray-700 dark:text-gray-300 mb-4">
                  Yangilangan kamera tizimi har qanday sharoitda ajoyib suratlar olish imkonini beradi. 48MP asosiy
                  kamera, 12MP ultra keng burchakli kamera va 12MP telefoto kamera bilan jihozlangan.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">
                      Kechasi suratga olish rejimi yanada yaxshilandi
                    </span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">Cinematic rejimi 4K 60fps da video yozish</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">
                      ProRAW va ProRes video yozish qo'llab-quvvatlanadi
                    </span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Yangilangan dizayn va displey</h2>
                <p className="text-gray-700 dark:text-gray-300 mb-4">
                  6.9 dyuymli Super Retina XDR OLED displey yanada yorqinroq va energiya tejamkor. ProMotion
                  texnologiyasi 1Hz dan 120Hz gacha yangilanish tezligini ta'minlaydi.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">Always-On displey funksiyasi</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">Ceramic Shield himoya qatlami</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">IP68 suv va changdan himoya</span>
                  </li>
                </ul>
              </div>
              <div className="relative h-[300px]">
                <Image
                  src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAsJCQcJCQcJCQkJCwkJCQkJCQsJCwsMCwsLDA0QDBEODQ4MEhkSJRodJR0ZHxwpKRYlNzU2GioyPi0pMBk7IRP/2wBDAQcICAsJCxULCxUsHRkdLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCz/wAARCADqAYkDASIAAhEBAxEB/8QAHAAAAgMBAQEBAAAAAAAAAAAAAgMBBAUGAAcI/8QATxAAAgEDAQMGCAkJBQYHAAAAAQIAAwQRBRIhMRMiQVFhcQYUcoGRkqGyIyQyNFJ0sbPRFTNCQ2Jjc8HSRFNUk/AWNYKiwuElRWR1g8Px/8QAGQEBAQEBAQEAAAAAAAAAAAAAAQACAwQF/8QAHxEBAQADAAMBAQEBAAAAAAAAAAECETESITJBE1ED/9oADAMBAAIRAxEAPwD5UBDAkgQwIEIEYBPBYYWZSAIwCeCwwJJABhgGSBDCySADCAMMLCCxQQDDAMILDCyQADCAMMLDCxAADCAMZsqqszEKi72ZiFUDtJmZX1m1pPsUabVgMhnLbCk/sjGcRTRAMMIZjDXwP7IP80/0wh4QD/Bj/OP9MQ2QhxCCGesKvjtrSuNjY2zUGztbWArFeJlwUppKmwZIQy4KXZJFLsiyp7Bntgy5yPZPcj2SSnsGe2D7Jc5HsnuS7JqBRKGQVMuGkeqCaXZEKeyZ7YMtClx3STRYbypA7d32xSmUMgoZbK0xxekO+on4wCqHg6HyXU/YZbiUipgkGW3pHjg4iis0yqlTAIMslYJWKViDBIMsFYBWR2rkGARHlYJURMquRAIjyogFZWEnHGCRHFYBENEoiCRGEQSJnRKME8Y0iARMkBEjB6oW/M9M6RoEMLJCxgWeZsIWMCyQsMLIoCxgWSFhhZJAWGFkgdkYB2SQQsMLDVYYXskgBYYWGE4Qbiva2iB7ioEzvVRvqN5KzUgEEJOAMnqG8+iU7vUrOz2kzytcD83TIwp/bf8AkPZMq81i5uA1KiDQoncQp+Efy34+aZcdBaur66vCDVfmgnZprupr3CVZ6eiHpIViVVQSzEKoXeSTwAAkT7d4E+Clvo9nY3dWglXXb6klfbqqGNhRcZWnSzwbHyzx346N5bpOc8HtD1z8l2gfTbtGzWJFanyRwahIOKpBwe6a40TV8lfEqmV486l/VO1uq+nW61mqu9fkzivWeqtG3Vyfkmo+4numXT1bR7ouLdbSrsnncjecrs+UaZOJnzrWowfyJq3TZ1PWpf1T35F1Uf2Op61L+qdNyluf7Io/+epv9H+vtnh4uf7KMZ48vUPo3S88l4xzQ0bVOi0f1qX9Un8i6r/hKnrUv6ptXBqJlqSuoHEbZce0AybS8WttI2Q67iCY/wBMl4xifkXVf8HU9al/VBOiat/gqnrUv6p1YMPzw/rkPCVxVfS9Qt0epXtK6oilmKLyhwOpaRJPonHX3hLSptUpWloxZSVNS8BXBH7pd/pPmn2bf/8Au/7Zyfhb4LW2rWte7taSpqVFC6sowawXfsNj2Rn/AFt6vDT5fU1fV7gkNdVFU/o0MUl/5Bn2xQFSocuzMTxLszH2mJpL2YxkYPRL9JNw3TW6Hrewr3TslBKeUQO7VGSmiAnZGWfdk9EZW0XUUp1qoW1ZaVN6rilc0nfYQZYhBv3DJ807TRNO0/Tmsn1Gnt+NVHa552UASm2wi5A3DOeHGaevP4MnRtW8ToBLkW7mkw3HOywYjzZHnmPK7a8XyHl69I5pVaqeQ7L9hlmlrOo08B3Wso6KwyfWGDM4kmenTdY1HS22rWVwVR80KhwAHOaZPY4/mJfK+0AjHT3Ti5o2Gp1rUhKmaluSMqd5XtQmdMc/9ZuP+OgKwCsej061NKtNtqm4yrDpxxz2jpnmWdo5qhWAVlorFlYpVKwSssFYsrIq5WAVlgrFlZGUgiARHlYsiWjskiCRGlYBENEoiRiMIkTFh2sgRgE8FjAs8W3VAEYFngojQstoIWMVTJVYwLIoCwwsJVjAskEAxgWSFjQsUy9VvLixpUTQVA1VnXlG3mmVAPNU7s75zFSrVqsz1HZ3Y5ZmJJPnM6zW6HKadVbiaFSlVHcTsH7ROQm4xXp6emrp2iX1/sVMcjbk/nagPOH7teJ/1viGYqO7KqKzMxwqqCWJ6gBvh16Fe1rVKFdClamQHQ4ypIBwcT6BYaVY2C4oU81MYes+DVbdv39A7BOP8IhjWtTHVVX3FklTTqaVtQ0yi4ylW8taTjHFXqqpn6OarsUb2orbNStWp2aMP0FY84jPZ/rdu/Omlf700jBx8fs944j4Zd8/QFUsbdwMZF9zc8CQmRmYzaj454T61daxqVwgZlsLSq9vY24/NpTQ7G3s8CzYJJ7Zk0WubSrTrUKj0a9IhkdDssp48eGOsTR13S6+l39yXRha161SpbVuKc47XJs2Mba5IOcdfAyjSSrdOlCgvKVX3ALzjw4t2TpjrQfS9F1Z720targK1SkGZRwV1JR1HZkHHfOmsbqlTqoahUDBUF/kg9pnD6LbtRFrbUs1OTQUgV4VKrOWYr2ZOB3Z4HAbrPhXYaXVq2NnbrfXdFilzWqVClrTqDjTphOcxHSczlOl2uqXNk9S1pWzo7jlGq8mQwVCAAGI3ZzMar8FWoXCbvhBTqY4ENwnLad4Y061ZKN5bUrXlGVEqUnY0AxO4VeU5wzwznHDIA3jpqtZHoADcTcUSAflAqSCCJVpv0zkAxmZXonmL3R2ZzRmZK4JAxkHAI64vMJM7ad4kXw7U7fkdd1qzpIzGnqN0iJSVmbZ5QkYVRmadroWs1Fy1qaSYLHl3RDgAnOzna9k6RhTo6rq7Iqh6l9cmo+AHduUO9jxmqh2qdTAJ+CqHA4nCk7p6Zj6242+1HWOXuaOm1qqCnUr1KrbC8AEXkxjvAB88xa9pUNpqQAZm8RuNkftFdkb89s6TUaTH8jUGqLVanTrMz09yttnoA9HmlStbL4pqR52VtXbAYjJDLxnCddPx8mq29xQOK1J0J4bSkA9x4RU71ESopR1V0YHKsAVOew7pjapoGyj3NiCQoL1aGSSFxktTzvx2T0XFz25uenp6ZLS0q/NpV5Oofi9UgP1I3AOO7pnUlfR0d04SdZolybm05NzmrbEIc8TTPyD9o83bOuGX4xlP1bKxZWWisWVnZzVSsWVlorFlYpVKxbLLLKYsqZJWIiyssssWVEjtXIiyssERZEmtkESMGMIkYhpLgEMCeAjQJ816EARgEkCMAkXlEYBPKsaqxKFEYqyVWNVZbFQqwwsJV4RgWOwVWoCvQuaBx8NRq0xnrKkD24nCWtjeXtTk7ekzsPlngiDrdjuE+iquMEdG+TSo0qS7FKmlNMltmmAqkk5JOOmMosYuneD1na7NS52bi4GDhh8Ch47lO8959E3gv8ArskhYxVjtaeRZ8+8JRjXNVH75fu1n0hVnz3wkTOu6uP3qfdrKXQ1tQ0nP5U0f/3Gy++Wffqh+Bqj/wBf/wDXPhGmU8ajpB6tQsfvln3Z99Mrn5V+PamJm3ZkZV1ZG6FUhCQN1Rt2xjjh9rm+mYR0xF2wnJrSyA/ICktM79wc0Rj0zl/CnwhvdVvq9rRd106hXa3tLemSq1Sh2DVq44kneOqYtpdX1jW5W3d6Nam2G2c7LYOClRDuIPSJuY3Wxv8AH1C2otaJVekPhko1+S3DdU5JgmMdOcYnyYFjsswZ8nNQBtlmJyTzu+fUNL1Bb62t6wGxytNagUHPJsCUZQ3HcRze8Tn9Y8GQ9epcWTpS5Ri9Si6tyO0d5amyAkZ4kFTvzv6AY3VVclUprSwoqLVBphiy7WBtDOzzukTv7GrVNPSVqE7ZpUOUzx2xTTOZgWWgvTqJVuWSsVIK06W1yeRvBd2A3dgBz2cZ1FKgw8XqHoqZJPWxEsstqOuo/IXujoij8he6OnJsYMJDz08oRWYdPe6eUJJxd4EGq35UAbVYscdLHeT55o0M7Dgcdh8eqZQut+p3p/ekejdNCgMI/wDDcnrwFM9U+XG9JJo40w0GDU/FqxQk54PUz7Y66y1nqecbtMPAY37S74ApGnb6TtLTVhbXSkUlIQc92GFO/p3wqxza6pv46WT6WWeeddLHKURvl5ARsnq3+eVqI3iXVG6eyODivCPTVtK6XdBcULliGUDAp1gMkYHQeI8/VMGfSdWsxd6bfUsZdaRrUuypS549O8eefNzMZYtSomroNfktQpITzbhWpN1ZxtKfZMqNoVDSrUKo406tOoP+FgZmdNd8ViystFRxHA7x3GKKz1OKsy8YpllorFsskqssWyywyxbCKViIoiWWWLKySsRFESyRFsJFXYQcRxEHEiuKI0CQBGKOE+W9SQI1VkKI1VkXlWMC9klVjVWSQF4bo0LJVRGACKQqiNCyVURgUSCAojAskLGhYgAWMVYQWMVRFPKonBeENPOuascfrk+7WfQ1UThteTOtaof3yfdrDJSM7T6eL7Szjhf2ZH+as+wXVVqTleg1VqLnhtDdifK7Gn8c0444Xtp94s+rXlFa/KoektiBfHNZ0+tYahXpOGFOpVqVrWoQcVKTNtbj1jg3Vjt3pX4VKNvRpZqlgMqp2nZjwxxJM+jX9rXZWpV7anc0yckOqtkjgSHBGeo7j2zJpWSUS3I2IohgVY0USmxB4guMtjrwROvn60xozRaLW1K2oZyaKbDkbxyrMajjd1E480Lwo1O+02zs1tDydS7q1VqV9kFkWmqsEQkYBPXNO0S3pKu0GXAGFC8JYuE0u8ovb3VLlqLEEpUQkZHAgjeD2zJ05rwVvrzVPyjQvSa/i60WWu4G0RVJXYqEAdWROtq0AtOxXHOr1eVUHjya7skdXVFWFHR7CnyFlYnk9rb5JFKU2cgDaqMSWPVxl+mlerWNzcsGqsMDAwtNehEHVC0yLabgoh5MAbsSczLQ8wkJ2k7xF5koeenlCH4HI1N+o6l9buB5tszUojKPx303G7r2TiUK+/UbwnH508ABw3ZmnbDcJ6pxxvWfbV6tYWQqsjsvKDapHKEEHgfYZduFAstUIABNlUA6DgFcRdejSo1KLUkVFY1MKgChSKZJIA65Nck2up5JIGm8CT9JZws1XTfpzdAbxL6LulKgN4mlTWeuOAdkYI3bwykHqIIM5hvA+y3/AB246f1dP8Z1uyIBAinJf7IWX+NuP8un+ME+CVmP7Zcf5afjOsKiLZZeMW6pinsIiZLbKKm0cAtgYycQWWWioiis2yqskUyiWiItlkFUqIorLTLFMsQqssUVlphFMsUrMsUwllhFFZFXYQcRrCDiRXFEaBBURoE+U9glWNUSFEaqySVWOVYKiOUSTyrGqshVjVEUkLDCyVEaFikBYwLJCxgEQgLGBZ4LGKsQlV+ycZraZ1nU/wCKn3azuFWchrCZ1fUj+9T7tYZGK2nUVa+sAwJUXFJjg4+SQRPpj72fvM+faemLuzOOFamfbO/Y85u+ZhQVU8QIBo0/oj0Q8z2YoApUx0CTyafRELM9mQQFUcAIWZE9mSFmezBzPZkRZhJudPKEDMlTzk7WAknNOQ2oXnZWqL5wxE1rdTgYGeicvqV7Xt9Vv6NDZUcqHLEB2LOAzfK3eyEl1fVF59zXPD9MgehcT048ee10N4r5tdxG09UDI/dmKqhvFdSJBA/J2zv6W2lyJi6e1Q3lRmZ2IpkjbZm4AnpM2b1z+TtaAABGk12yMg7RA3gzln9Ok4w6CnI3emaKDcJwtveX9Ig07msvZtlh6GzNe31+/pbIrU6Ndek45N8d67vZPVI47dRswSsq2er6ZeFUWpyNZuFK4wpJ6kf5J9Il8qRxHskNqzCLIllh2RZEYlYiLKyyy8YorFKzLFMstMsUyxZVmWJYcZaYcYllilYrFMJZZYplilZliiJZYRLCAV2HGBgRzCDiJXFEaogqI5RPkvcJVjVEFRGqJISiNUcJCiNUSQlHCNCyAOEYBEJUcI0CeVYYEUkCMVeE8FjAsU8FjFWeAjFE1AlROV1ZM6rqH8VfcWdcq9k5nU0zqd+f3i+4JnLixJskxcWx4Yqpx7CJ2jHnN3zkaCc+icfrqIPridW557+VDFUU9AzPZmkORug5i6lZKe7eW44EgaWCgknAHEyVZWAYHcd4lJ61OqoDBxg5IGN/njaVdXIUKRu3Y3jHbLSWcz0DMnMkLMJTzl7xF5kqecvePtgnCatj8t34BzhqYPqyzRHNlG92n1zWVAZ38fuFCqCxwGwBhd82rawv3TItnGcfLKp7GOZ6sXC9JsRi5qHo5N8+qZqXZHiGtjP/AJPW9oBlelZXdrcU3rIqo5ZFwytltkkg4lu8/wB260AMk6dXUY49AAE45/Tpjx81pA7pZC7huiaakEAggjoO4iXFXcJ68XCq7Ju4Z79809P1u6sytK4269qMDBJNWmP2GPEDqMplIpknTTLu6dWjcUqdehUWpSqDKMvT2HtnmE43TdRq6bXBwz21QjxikOkcOUXo2hOzVqdWnTq0mD06iq6MuMMrDIMxZpqUll4xbLLBEWRIqxEWwlhhFMJBWYRTLLLL2RTCIVmESwllhEsIpWYRTDfLLCJYb5BXYcYGI5hBxJLiiNUb4CjhHKJ8p7xKI5RAURyiSEojlEFRGqJIQEaogqI1RJCUbhGgQVEao4d0Q8BGgSAIwCaTyiNUSFEYBEJUTndSX/xK+/iL7izplH2TAv1+P3nlr7gmcjiTRTfTP7yn7wnQOee3eZjU1wFP7Se8JrMec3lGWKyTmTmBmezNsjzKdfJqNnslnMVWXPPUbxxHWJBXxLNswAcfpbj5ogK537J9EZSQ7W0dwHDPSZJazPZgZnsyQ8yQd694i8zwO9e8STIpoov9QZVALXdcsRxY7Z4mb1uOb5piUh8cvfrVf3zN6gOaO6d5xzqtqAx4kf37/dypV+aaj9Vqe8suamMCxPXcVPupSq/NdQ+rP7yzll9NzjCFrb3PNq01bqYbmHc0q3Wk1rUcrTzVodJH5yn5Y6u2adsOdNikBgDoxv6fSJ6Y4uFKj/v0YMSyzodX00WzC4ori3qtgqP1VQ9HceiYrLxnXG7c6ous2vB6/KO2nVTzH2qlqT0Pxan5+I8/XMt14xOalNkqUzs1KbLUpnqdTtD/ALxs2pdO+IiiIdtXp3dvb3CABa1NXwf0W4MvmOR5pLCc21ZhFsJYIimHGIViOMUwlkjjEsIhWYRTCWWESwklZhEsJZYRTCSVmEHEaw4wcRC2ojVG+AojlE+S+gNRHKICiOUSQ1EaogKI5ZASiNUQVEaoihACMAgqI0CIEBGAQQIwCaQgIxRBURgEQJRMO9X4/d+WvuCb6iYt2M3115S+4JnI4gVeaO9T/wAwl1s7TeUZXC/Bnsx9oj2PObvMsBknJnsmBmezNsjyZG+RmRmKFvPGTAzPZghZMnJgZnsyQt8lSQV7xAzJB3jvEko0h8cvfrNb3zN63G4d0wqHzu8+s1vfM6C3G4d07TjnVTVxhNO+tVPupn1Pmt8OnxZveWaOu82hYsOIuK3HrFEzGpu7WuohjnFucE7+LLOeX03OK1sOdNikNw7pk2w502aQ3Cd3IVWhTuKNWhU+RVQoT9Eng3mODOHr0XpPUpuMPTZkYdqnE74DdOX12gEvWqAbq9NKv/EOYfsnTCsVgMsrVFl51leovGdWW54N1tq2urZuNvV206RsVhk+0H0zaYTmfB9ymovT/vraqO8oQw/nOpYTnl1rHiuRFMJYIiWECrsOMURxlgjjFMIhXYRLCWGEUwiFZhEsJYaJYb5JXYQcRrCDiSWljlEBRHLPlPeNRGqICgxyiSMURoHCLURyiQGsaogKI5RFJURqwQIxRFCURoEFRGARAgIxRBGYxYoaiY12MXtz5S+6Jtr0zHux8cufKHuiGSj2Pg348Bw7xPMec3fCORScjq/mIpjzj3xwZqcz2YOZ7M2BZnswcz2ZIWZ7MHM9mSFmezBzPZkhZkqd694gZngd694giaHzq7+sVvfM6G24LMC3+c3X1it75nQW43L3TvOMVR8IPm1l9Yr/AHJmJR+b6h22/wD1rNzwg+bWX1it9yZh0vm9/wDwB76zll1qcBbDnTZpDcO6ZNqOdNmlwHdO7kaBumH4QpzbB+nNen5uaw+0zfA3eaY/hAByFl18tV9GwJrHrN45V1ld14y44ldxOzA9I5uq2B63qr5jTadewnJaWudU07HRWc+YU3nYMJjLpx4rsIphHtFMJlpXYRTCWGEUwmgrsIlhHsIlsxSuwimEewimEgrsOMHEYwg75JaURyiLWNWfKe81RGqItY5ZIxeEaoi1jh0SRiiNEWsasQYsaIteMaJIYAjBAEaJoCEYogCMWKGomTdD45c9490TXWZV0Pjlx5S+6IZKPN+ZqeSPeEqMec3lGXH/ADNXyR9olFjzm7zHBmpzPZgZnszbI8yciBmRmSHmezAzJzJCzPZEDM9mSGTPA717xAzJB3jvEkm1Pxi5/j1ffM6K34DunPWn5+4/j1ffM6K34DunWcYrP8IMm2sQOJua33Mw6QPi96d+DQ4Hy1m7r35nTvrdT7kzGP5m6/g/9azll9NzgbX5U2KI3CY9qOdNmlwHdPQ5X2sDh55h6+fmVPPBatQjyiq/yM3d/QN85rVqoq3lbZ+TRAoL/wAHH25mses1jOJXccZbcSvUHGdmDtGpl9UtiBup069Q9mF2f5zqmBmH4P0c1r2uRuSmlFfKc7R+ybpnPLrUJaKYRzcYphxgSGAimj2iWjAQ0U0c0U0UQ0Q0sNEtEEN0wIxumDJLKxy9EUsconyXvNWOWJWOURRqxq9EWoMaskavRHLFL0RoiDBGrwHdFKI0AyRgjF6IABjFmgMRiwBGCKMWZdz88uPKX3RNRZl3Pzu48pfdEMjEP+YreR/MTNY85u8zRqH4CsepD6dxEzDxPfmODGScz0ienRlM9InpJM9mRPSSZ7MiekkyRxHeIM8DgjvEEfZj4av/AB6vvmdFQ+SO6c9Y5NWqeHw1XPrmdFQ4CdZxms7X/wAxp31up9yZi/qrr+D/ANazV8Jn5O1018gfHXGT/BM51LhnFVdtN6AfJO/nr2zll9NTi/a/KmzS4DumPbfK8810ZERnqMFRBz2bgs9Ec6K5uBa29Wr+ljZpDrqEbvRx805R8nOc5OSSekneZevbtruoGAK0qYIoqeIU9Ldp6ZScGdJNMVWcStU3Z7BLTyLa2N5c0qH6JO1Vb6NNd7engO+b2y29IochYUiRz65a4bO487cvsxLhjSAAABgAYAHQBFmc7fbRTdMU0a0URxkiWiWj2iT0xBDRTRzdMS0US0S3THMIppAhoMNhxgYMUsiOSJEck+S95yxyxKxyxRyxoiVjl6JI1eiOWJXojlkDFjViljVijRGCKEaJoUYjFixGCKMEyro/G7jyh7omqO6ZF187ufKX3RCmIqZNGso3k03x34yJmhgwDDgQDNIMRwmfVpPRqNgfAOcgj9WTxXu6pYVnKInpOy3EKxHWASPZPbL/AEH9U/hOjCJ6TsP9B/Vae2Kn0H9VpFE9J2H+g3qtPbD/AEG9VpAMmTsP9BvVae2Kn0H9UyQZP+u6TydTBPJtgccgge2UrmttZo0jkndUdd6gdKgjpjraXtLrUn37agliSGODkknpnT0Pkju804y1pbON02aL1FUBWYbuhiJ1YF4VULi5tNLo0FLVGvqhAH7NAkzlxp2p2jJWrU2WnytFHLYwA7gTfvrzU6Atrm2WpcVaFYkUydrC1EKM2DM+41Xwh1Cn4ncWTUqFSpTeoxUABaZ2+M5ZS+Tc4ct1bUSedyjj9Glw87cPti6t1XucbZAprnYpr8kdp6z2ytyOzjA7YxVM9EjltJ/lFvGEce6Kc46D5t59Am2aQ/nJJwAOJPUBOg02x8Tok1B8YrbLVeHNGObTHd0wNO000itzcr8LxpUzg8nn9Jv2urq+zSbjC3akLYGKbMa0U0CU0W0Y0U3TEFNEtHN0xLSRTRLZjmiWmgS0U0a0U3GSJaDvhNBkD1HCOWJUxqz5b3nLHLErHLJHLwjViVjlkjl6I1YlY5Yg1YwRYjBJGiMEUIxTwmgaIwRQjBJGCY92cXlz5S+6JrjoiKlhQrVHqtUqBnwSFK44Y6RK+zKzAZPHjNIaZb/3lb0p/TCGnW/95W9Kf0zMlG1ajY0ntkYKAxNTeu4/LPVFNZEE739dvxmzRpJSprTUsQpJBbido56J5qQPVOs9RljeJn6T+u34zws+1/Xb8Zr8kOoSRSHVEMgWfa3rt+MnxIdb+u34zX5IT3J9kQyPEh1v67fjK9fTq5w1KrW3Ha2DUfAPWu+dByQkGkIhyFS2qklarVGIPCoztjzE4gLagdHDh/2nXvb0qgw6Bh28fTKj6ZTJ+DdgOphtD08YwViJTAxLSbgJbOm3A+Sabdxx7DB8SvBwp584/GbgVW4xbb9xls2d6f1Lelfxg+IXp/VqvlOv8pplnui7/TEsuN81xpddjz6tNexAXP8AKPTTLNMFw1VuPwh5vqjdNbGmFStri5OKKbQ6XbdTUdrTWtNOoW2KjkVa/HaIwqfw1P2zQwFACgADcAowB3AQTLaLMW0YYpoQgbpimjGimiC2ij0xjRTRRbRLRrRR6ZAlopo1umJaIKbpiW4xrRLRRbQZLQZA9Y5YpeiOWfKe8xY5YtY1ZI1TGqeEWscsUNY5YtY5ZIaxgMBYwRBiw16JC8DGDjNBIjBIEMSSRDE8IYiHge2GJAjBFBEKEOEmaAcSQIwSRIF7InsRsmMBOJ7EbPTQJIkECPgmII3SI2CeMQWYBIjTBMUUfsgExpgGIJJgExxizEEtFN0x7RbRRBijHtFmIIaKbhHtEtJEMe2KPTHnpim6YhXaJaPaJaIIaKYx7RTSSu0HPbGNBin/2Q=="
                  alt="Display"
                  fill
                  className="object-contain"
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="specifications" className="space-y-6">
            <div className="border dark:border-gray-800 rounded-lg overflow-hidden">
              <div className="grid grid-cols-1 md:grid-cols-2">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">Displey</div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  6.9" Super Retina XDR OLED, 120Hz, HDR10, Dolby Vision, 1200 nits
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  Protsessor
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  Apple A19 Pro, 6-yadroli CPU, 16-yadroli Neural Engine
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">Xotira</div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  8GB RAM, 256GB/512GB/1TB saqlash xotirasi
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  Asosiy kamera
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  48MP (keng) + 12MP (ultra keng) + 12MP (telefoto)
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  Old kamera
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  12MP, f/1.9, Face ID sensori
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  Batareya
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  4,800 mAh, 35W tezkor zaryadlash, 15W simsiz zaryadlash
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  Operatsion tizim
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">iOS 19</div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">Aloqa</div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  5G, Wi-Fi 7, Bluetooth 5.3, NFC, USB Type-C
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  O'lchamlari
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  160.7 x 77.6 x 8.25 mm, 221 g
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="reviews" className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">Mijozlar sharhlari</h3>
              <Button>Sharh qoldirish</Button>
            </div>

            <div className="space-y-6">
              {/* Review 1 */}
              <div className="border dark:border-gray-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                      <span className="font-medium text-gray-700 dark:text-gray-300">AO</span>
                    </div>
                    <div className="ml-3">
                      <p className="font-medium text-gray-900 dark:text-white">Aziz Olimov</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">12 May, 2025</p>
                    </div>
                  </div>
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-4 w-4 fill-current text-yellow-500" />
                    ))}
                  </div>
                </div>
                <p className="text-gray-700 dark:text-gray-300">
                  Juda ajoyib telefon! Batareya quvvati butun kun davomida yetadi, kamera sifati ham a'lo darajada. iOS
                  19 tizimi juda tez va qulay ishlaydi. Oldingi iPhone 14 Pro modelidan yangiladim va farqi sezilarli
                  darajada.
                </p>
              </div>

              {/* Review 2 */}
              <div className="border dark:border-gray-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                      <span className="font-medium text-gray-700 dark:text-gray-300">MK</span>
                    </div>
                    <div className="ml-3">
                      <p className="font-medium text-gray-900 dark:text-white">Malika Karimova</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">5 May, 2025</p>
                    </div>
                  </div>
                  <div className="flex">
                    {[1, 2, 3, 4].map((star) => (
                      <Star key={star} className="h-4 w-4 fill-current text-yellow-500" />
                    ))}
                    <Star className="h-4 w-4 text-gray-300 dark:text-gray-600" />
                  </div>
                </div>
                <p className="text-gray-700 dark:text-gray-300">
                  Telefon juda yaxshi, lekin narxi biroz qimmat. Kamera sifati va ishlash tezligi juda zo'r, ammo
                  batareya quvvati kutganimdan kamroq chidaydi. Umumiy baholashim - yaxshi, lekin mukammal emas.
                </p>
              </div>

              {/* Review 3 */}
              <div className="border dark:border-gray-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                      <span className="font-medium text-gray-700 dark:text-gray-300">JT</span>
                    </div>
                    <div className="ml-3">
                      <p className="font-medium text-gray-900 dark:text-white">Jasur Toshmatov</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">28 April, 2025</p>
                    </div>
                  </div>
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-4 w-4 fill-current text-yellow-500" />
                    ))}
                  </div>
                </div>
                <p className="text-gray-700 dark:text-gray-300">
                  Eng zo'r iPhone! A19 Pro protsessori haqiqatan ham juda kuchli, hatto eng og'ir o'yinlar ham muammosiz
                  ishlaydi. Kamera sifati professional darajada, ayniqsa kechasi suratga olish rejimi juda yaxshilangan.
                  USB Type-C portiga o'tish ham juda qulay bo'ldi. Albatta tavsiya qilaman!
                </p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Related Products */}
      <div className="bg-gray-50 dark:bg-gray-900 py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-8">O'xshash mahsulotlar</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Product 1 */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
              <div className="relative h-48">
                <Image
                  src="https://th.bing.com/th/id/OIP.vVXqffIBu2_k-WF1jAcO3gHaEK?w=262&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7"
                  alt="iPhone 16"
                  fill
                  className="object-contain p-4"
                />
              </div>
              <div className="p-4">
                <h3 className="font-medium text-gray-900 dark:text-white mb-2">iPhone 16</h3>
                <div className="flex items-center mb-2">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-3 w-3 fill-current text-yellow-500" />
                    ))}
                  </div>
                  <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">(845)</span>
                </div>
                <p className="text-red-600 font-bold">10,999,000 so'm</p>
              </div>
            </div>

            {/* Product 2 */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
              <div className="relative h-48">
                <Image
                  src="https://th.bing.com/th/id/OIP.jG-6E7Z6l9UC6kC59PFTtgHaGY?w=189&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7"
                  alt="iPhone 16 Pro"
                  fill
                  className="object-contain p-4"
                />
              </div>
              <div className="p-4">
                <h3 className="font-medium text-gray-900 dark:text-white mb-2">iPhone 16 Pro</h3>
                <div className="flex items-center mb-2">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-3 w-3 fill-current text-yellow-500" />
                    ))}
                  </div>
                  <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">(1024)</span>
                </div>
                <p className="text-red-600 font-bold">12,999,000 so'm</p>
              </div>
            </div>

            {/* Product 3 */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
              <div className="relative h-48">
                <Image
                  src="https://th.bing.com/th/id/OIP.FFR0Pix5Qobq_msENNvGSAHaJo?w=115&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7"
                  alt="iPhone 15 Pro Max"
                  fill
                  className="object-contain p-4"
                />
              </div>
              <div className="p-4">
                <h3 className="font-medium text-gray-900 dark:text-white mb-2">iPhone 15 Pro Max</h3>
                <div className="flex items-center mb-2">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-3 w-3 fill-current text-yellow-500" />
                    ))}
                  </div>
                  <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">(1876)</span>
                </div>
                <p className="text-red-600 font-bold">11,499,000 so'm</p>
              </div>
            </div>

            {/* Product 4 */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
              <div className="relative h-48">
                <Image
                  src="https://th.bing.com/th/id/OIP.eFyw1ZdZAvMjDg1r9f9bNQHaFQ?w=278&h=197&c=7&r=0&o=5&dpr=1.3&pid=1.7"
                  alt="Apple Watch Series 9"
                  fill
                  className="object-contain p-4"
                />
              </div>
              <div className="p-4">
                <h3 className="font-medium text-gray-900 dark:text-white mb-2">Apple Watch Series 9</h3>
                <div className="flex items-center mb-2">
                  <div className="flex">
                    {[1, 2, 3, 4].map((star) => (
                      <Star key={star} className="h-3 w-3 fill-current text-yellow-500" />
                    ))}
                    <Star className="h-3 w-3 text-gray-300 dark:text-gray-600" />
                  </div>
                  <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">(632)</span>
                </div>
                <p className="text-red-600 font-bold">4,999,000 so'm</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
