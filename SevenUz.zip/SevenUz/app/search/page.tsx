"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { ShoppingCart, Star, Filter, ChevronDown, ChevronUp, Check, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { useCart } from "@/components/cart-provider"
import { useToast } from "@/hooks/use-toast"
import { searchProducts } from "@/lib/product-data"
import { useRouter } from "next/navigation"

export default function SearchPage() {
  const searchParams = useSearchParams()
  const query = searchParams.get("q") || ""
  const router = useRouter()
  const { addToCart } = useCart()
  const { toast } = useToast()
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 3000])
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [showFilters, setShowFilters] = useState(false)
  const [sortBy, setSortBy] = useState<string>("price-asc")
  const [searchResults, setSearchResults] = useState<any[]>([])
  const [filteredResults, setFilteredResults] = useState<any[]>([])
  const [addedProducts, setAddedProducts] = useState<{ [key: string]: boolean }>({})

  // Get search results
  useEffect(() => {
    if (query) {
      const results = searchProducts(query)
      setSearchResults(results)
      setFilteredResults(results)

      // Set initial price range based on results
      if (results.length > 0) {
        const prices = results.map((product) => product.price)
        const minPrice = Math.min(...prices)
        const maxPrice = Math.max(...prices)
        setPriceRange([minPrice, maxPrice])
      }
    }
  }, [query])

  // Get unique categories
  const categories = [...new Set(searchResults.map((p) => p.category))]

  // Filter and sort products based on selected filters
  useEffect(() => {
    let filtered = [...searchResults]

    // Filter by category
    if (selectedCategories.length > 0) {
      filtered = filtered.filter((product) => selectedCategories.includes(product.category))
    }

    // Filter by price
    filtered = filtered.filter((product) => product.price >= priceRange[0] && product.price <= priceRange[1])

    // Sort products
    if (sortBy === "price-asc") {
      filtered.sort((a, b) => a.price - b.price)
    } else if (sortBy === "price-desc") {
      filtered.sort((a, b) => b.price - a.price)
    } else if (sortBy === "name-asc") {
      filtered.sort((a, b) => a.name.localeCompare(b.name))
    } else if (sortBy === "name-desc") {
      filtered.sort((a, b) => b.name.localeCompare(a.name))
    } else if (sortBy === "rating-desc") {
      filtered.sort((a, b) => (b.rating || 0) - (a.rating || 0))
    }

    setFilteredResults(filtered)
  }, [searchResults, priceRange, selectedCategories, sortBy])

  // Toggle category selection
  const toggleCategory = (category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category) ? prev.filter((c) => c !== category) : [...prev, category],
    )
  }

  // Handle add to cart
  const handleAddToCart = (product: any) => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      quantity: 1,
      image: product.image,
    })

    // Show animation
    setAddedProducts((prev) => ({ ...prev, [product.id]: true }))

    // Reset after animation
    setTimeout(() => {
      setAddedProducts((prev) => ({ ...prev, [product.id]: false }))
    }, 1500)

    // Show toast notification
    toast({
      title: "Mahsulot savatga qo'shildi",
      description: `${product.name} savatga qo'shildi`,
      duration: 3000,
    })
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pb-12">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center">
            <Button variant="ghost" size="icon" onClick={() => router.back()} className="mr-2">
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">
              Qidiruv natijalari: "{query}" ({filteredResults.length})
            </h1>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4  py-8">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-lg font-medium text-gray-900 dark:text-white">Topilgan mahsulotlar</h2>
            <p className="text-sm text-gray-500 dark:text-gray-400">{filteredResults.length} ta mahsulot topildi</p>
          </div>

          {/* Mobile Filter Toggle */}
          <div className="md:hidden">
            <Button
              variant="outline"
              size="sm"
              className="flex items-center"
              onClick={() => setShowFilters(!showFilters)}
            >
              <Filter className="h-4 w-4 mr-2" />
              <span>Filtrlar</span>
              {showFilters ? <ChevronUp className="h-4 w-4 ml-2" /> : <ChevronDown className="h-4 w-4 ml-2" />}
            </Button>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-6">
          {/* Filters Sidebar */}
          <aside className={`md:w-1/4 lg:w-1/5 ${showFilters ? "block" : "hidden"} md:block`}>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 sticky top-4">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">Filtrlar</h2>

              

              

              {/* Category Filter */}
              {categories.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Kategoriya</h3>
                  <div className="space-y-2">
                    {categories.map((category) => (
                      <div key={category} className="flex items-center">
                        <Checkbox
                          id={`category-${category}`}
                          checked={selectedCategories.includes(category)}
                          onCheckedChange={() => toggleCategory(category)}
                        />
                        <label
                          htmlFor={`category-${category}`}
                          className="ml-2 text-sm text-gray-600 dark:text-gray-400 cursor-pointer"
                        >
                          {category}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Reset Filters */}
              <Button
                variant="outline"
                size="sm"
                className="w-full"
                onClick={() => {
                  setPriceRange([0, 3000])
                  setSelectedCategories([])
                  setSortBy("price-asc")
                }}
              >
                Filtrlarni tozalash
              </Button>
            </div>
          </aside>

          {/* Products Grid */}
          <div className="md:w-3/4 lg:w-4/5">
            {filteredResults.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredResults.map((product, index) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                    whileHover={{ y: -5 }}
                    className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all duration-300"
                  >
                    <Link href={`/product/${product.id}`} className="block">
                      <div className="relative h-48 bg-gray-100 dark:bg-gray-700">
                        <Image
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          fill
                          className="object-contain w-full h-full"
                        />
                        {product.oldPrice && (
                          <div className="absolute top-2 right-2 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded">
                            Chegirma
                          </div>
                        )}
                      </div>
                    </Link>

                    <div className="p-4">
                      <div className="flex items-center mb-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-3 w-3 ${
                              i < Math.floor(product.rating || 0)
                                ? "text-yellow-400 fill-current"
                                : "text-gray-300 dark:text-gray-600"
                            }`}
                          />
                        ))}
                        <span className="text-xs text-gray-600 dark:text-gray-400 ml-1">{product.rating}</span>
                      </div>

                      <Link href={`/product/${product.id}`} className="block">
                        <h3 className="font-medium text-gray-900 dark:text-white mb-1 hover:text-red-600 dark:hover:text-red-400 transition-colors">
                          {product.name}
                        </h3>
                      </Link>

                      <p className="text-xs text-gray-600 dark:text-gray-400 mb-2 line-clamp-2">
                        {product.description}
                      </p>

                      <div className="flex flex-wrap gap-1 mb-3">
                        {product.memory && (
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300">
                            {product.memory}
                          </span>
                        )}
                        {product.batteryHealth && (
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300">
                            {product.batteryHealth}
                          </span>
                        )}
                        {product.condition && (
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300">
                            {product.condition}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="font-bold text-lg text-red-600 dark:text-red-400">${product.price}</span>
                        {addedProducts[product.id] ? (
                          <motion.div
                            initial={{ scale: 0.8, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className="bg-green-600 text-white rounded-md px-3 py-1 flex items-center"
                          >
                            <Check className="h-4 w-4 mr-1" />
                            <span className="text-xs">Qo'shildi</span>
                          </motion.div>
                        ) : (
                          <Button
                            size="sm"
                            onClick={() => handleAddToCart(product)}
                            className="bg-red-600 hover:bg-red-700 text-white"
                          >
                            <ShoppingCart className="h-4 w-4 mr-1" />
                            Savatga
                          </Button>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="bg-white dark:bg-gray-800 rounded-lg p-8 text-center">
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Mahsulotlar topilmadi</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  "{query}" bo'yicha hech qanday mahsulot topilmadi. Boshqa so'zlar bilan qidirib ko'ring.
                </p>
                <Button className="mt-4" onClick={() => router.push("/")}>
                  Bosh sahifaga qaytish
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
