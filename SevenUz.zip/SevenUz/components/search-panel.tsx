"use client"

import { useState, useEffect, useRef } from "react"
import { Search, X } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import Link from "next/link"

// Mock search results
const mockProducts = [
  {
    id: "1",
    name: "iPhone 15 Pro",
    category: "Smartphones",
    price: 999,
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    id: "2",
    name: "Samsung Galaxy S24",
    category: "Smartphones",
    price: 899,
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    id: "3",
    name: "MacBook Pro M3",
    category: "Laptops",
    price: 1999,
    image: "/placeholder.svg?height=80&width=80",
  },
]

export function SearchPanel() {
  const [query, setQuery] = useState("")
  const [results, setResults] = useState<typeof mockProducts>([])
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus()
    }
  }, [])

  useEffect(() => {
    if (query.length > 1) {
      // In a real app, this would be an API call
      const filtered = mockProducts.filter((product) => product.name.toLowerCase().includes(query.toLowerCase()))
      setResults(filtered)
    } else {
      setResults([])
    }
  }, [query])

  return (
    <div className="absolute top-full right-0 mt-2 w-[350px] md:w-[400px] bg-white dark:bg-gray-900 rounded-lg shadow-lg border border-gray-200 dark:border-gray-800 z-50 overflow-hidden animate-fadeIn">
      <div className="p-4">
        <div className="relative">
          <Input
            ref={inputRef}
            type="text"
            placeholder="Search products..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-10 pr-10"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          {query && (
            <button onClick={() => setQuery("")} className="absolute right-3 top-1/2 transform -translate-y-1/2">
              <X className="h-4 w-4 text-gray-400" />
            </button>
          )}
        </div>
      </div>

      {results.length > 0 && (
        <div className="max-h-96 overflow-y-auto p-4 border-t border-gray-200 dark:border-gray-800">
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Search Results</h3>
          <ul className="space-y-2">
            {results.map((product) => (
              <li key={product.id}>
                <Link
                  href={`/product/${product.id}`}
                  className="flex items-center p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                >
                  <div className="w-16 h-16 relative rounded overflow-hidden bg-gray-100 dark:bg-gray-800 mr-3 flex-shrink-0">
                    <Image src={product.image || "/placeholder.svg"} alt={product.name} fill className="object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 dark:text-white truncate">{product.name}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{product.category}</p>
                    <p className="text-sm font-bold text-red-600 dark:text-red-400">${product.price}</p>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      )}

      {query && results.length === 0 && (
        <div className="p-4 text-center border-t border-gray-200 dark:border-gray-800">
          <p className="text-gray-500 dark:text-gray-400">No results found</p>
        </div>
      )}

      <div className="p-3 bg-gray-50 dark:bg-gray-800/50 border-t border-gray-200 dark:border-gray-800">
        <Button variant="ghost" size="sm" className="w-full text-gray-500 dark:text-gray-400">
          View all results
        </Button>
      </div>
    </div>
  )
}
