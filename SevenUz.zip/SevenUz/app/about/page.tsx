"use client"

import { Badge } from "@/components/ui/badge"

import type React from "react"

import { useState, useRef } from "react"
import Image from "next/image"
import { motion, AnimatePresence } from "framer-motion"
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  Users,
  Award,
  Target,
  ChevronRight,
  Calendar,
  Shield,
  Info,
  FileText,
  Building,
  Check,
  AlertTriangle,
  Truck,
  MailOpen,
  Facebook,
  Instagram,
  MessageCircle,
  Send,
  Tag,
  Eye,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function AboutPage() {
  const [activeTab, setActiveTab] = useState<"history" | "mission" | "team">("history")
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  })
  const [formSuccess, setFormSuccess] = useState(false)
  const formRef = useRef<HTMLDivElement>(null)

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Simulate form submission
    setTimeout(() => {
      setFormSuccess(true)
      // Reset form
      setFormData({
        name: "",
        email: "",
        phone: "",
        subject: "",
        message: "",
      })
      // Hide success message after 3 seconds
      setTimeout(() => setFormSuccess(false), 3000)
    }, 500)
  }

  const scrollToContact = () => {
    if (formRef.current) {
      formRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }

  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  }

  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-red-600 to-red-700 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <motion.div initial="hidden" animate="visible" variants={fadeIn} className="max-w-xl">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">Kompaniya haqida</h1>
              <p className="text-lg mb-6">
                Seven - O'zbekistondagi eng ishonchli va tez rivojlanayotgan elektron tijorat kompaniyasi. Biz
                2018-yildan beri mijozlarimizga yuqori sifatli mahsulotlar va ajoyib xizmatlarni taqdim etib
                kelmoqdamiz.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button onClick={scrollToContact} className="bg-white text-red-600 hover:bg-gray-100">
                  <Phone className="h-4 w-4 mr-2" /> Biz bilan bog'lanish
                </Button>
                <Button variant="outline" className="border-white text-white hover:bg-white/10">
                  <Info className="h-4 w-4 mr-2" /> Ko'proq ma'lumot
                </Button>
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6 }}
              className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden shadow-xl"
            >
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Seven kompaniyasi binosi"
                fill
                className="object-cover"
              />
            </motion.div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 w-full h-16 bg-white dark:bg-gray-900 clip-path-wave"></div>
      </section>

      {/* Tabs Navigation Section */}
      <section className="py-16 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4">
          <Tabs defaultValue="company" className="w-full">
            <TabsList className="grid w-full grid-cols-1 md:grid-cols-5 h-auto">
              <TabsTrigger
                value="company"
                className="data-[state=active]:bg-red-50 dark:data-[state=active]:bg-red-900/20 data-[state=active]:text-red-600 dark:data-[state=active]:text-red-400 py-3"
              >
                <Building className="h-5 w-5 mr-2" />
                <span>Kompaniya</span>
              </TabsTrigger>
              <TabsTrigger
                value="warranty"
                className="data-[state=active]:bg-red-50 dark:data-[state=active]:bg-red-900/20 data-[state=active]:text-red-600 dark:data-[state=active]:text-red-400 py-3"
              >
                <Shield className="h-5 w-5 mr-2" />
                <span>Garantiya</span>
              </TabsTrigger>
              <TabsTrigger
                value="delivery"
                className="data-[state=active]:bg-red-50 dark:data-[state=active]:bg-red-900/20 data-[state=active]:text-red-600 dark:data-[state=active]:text-red-400 py-3"
              >
                <Truck className="h-5 w-5 mr-2" />
                <span>Yetkazib berish</span>
              </TabsTrigger>
              <TabsTrigger
                value="news"
                className="data-[state=active]:bg-red-50 dark:data-[state=active]:bg-red-900/20 data-[state=active]:text-red-600 dark:data-[state=active]:text-red-400 py-3"
              >
                <FileText className="h-5 w-5 mr-2" />
                <span>Yangiliklar</span>
              </TabsTrigger>
              <TabsTrigger
                value="contact"
                className="data-[state=active]:bg-red-50 dark:data-[state=active]:bg-red-900/20 data-[state=active]:text-red-600 dark:data-[state=active]:text-red-400 py-3"
              >
                <MessageCircle className="h-5 w-5 mr-2" />
                <span>Bog'lanish</span>
              </TabsTrigger>
            </TabsList>

            {/* Company Tab Content */}
            <TabsContent value="company" className="mt-8">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div className="md:col-span-1">
                  <div className="sticky top-24 space-y-2">
                    <button
                      onClick={() => setActiveTab("history")}
                      className={`w-full text-left px-4 py-3 rounded-lg transition-colors flex items-center ${
                        activeTab === "history"
                          ? "bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 font-medium"
                          : "hover:bg-gray-100 dark:hover:bg-gray-800"
                      }`}
                    >
                      <Calendar className="h-5 w-5 mr-2" />
                      Kompaniya tarixi
                    </button>
                    <button
                      onClick={() => setActiveTab("mission")}
                      className={`w-full text-left px-4 py-3 rounded-lg transition-colors flex items-center ${
                        activeTab === "mission"
                          ? "bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 font-medium"
                          : "hover:bg-gray-100 dark:hover:bg-gray-800"
                      }`}
                    >
                      <Target className="h-5 w-5 mr-2" />
                      Missiya va qadriyatlar
                    </button>
                    <button
                      onClick={() => setActiveTab("team")}
                      className={`w-full text-left px-4 py-3 rounded-lg transition-colors flex items-center ${
                        activeTab === "team"
                          ? "bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 font-medium"
                          : "hover:bg-gray-100 dark:hover:bg-gray-800"
                      }`}
                    >
                      <Users className="h-5 w-5 mr-2" />
                      Bizning jamoa
                    </button>
                  </div>
                </div>

                <div className="md:col-span-3">
                  <AnimatePresence mode="wait">
                    {activeTab === "history" && (
                      <motion.div
                        key="history"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        transition={{ duration: 0.3 }}
                        className="space-y-8"
                      >
                        <div>
                          <h2 className="text-3xl font-bold mb-4 text-gray-900 dark:text-white">Kompaniya tarixi</h2>
                          <p className="text-gray-600 dark:text-gray-400 mb-4">
                            Seven kompaniyasi 2018-yil 15-martda Andijon shahrida Abdulaziz Toshpo'latov tomonidan
                            tashkil etilgan. Dastlab, kompaniya kichik elektron do'kon sifatida faoliyat boshlagan
                            bo'lib, asosan smartfonlar va aksessuarlar savdosi bilan shug'ullangan.
                          </p>
                          <p className="text-gray-600 dark:text-gray-400 mb-4">
                            Kompaniyaning nomi "Seven" (Yetti) raqami bilan bog'liq bo'lib, bu raqam ko'p madaniyatlarda
                            omad va muvaffaqiyat ramzi hisoblanadi. Shuningdek, bu nom oson esda qoladigan va talaffuz
                            qilinadigan bo'lgani uchun ham tanlangan.
                          </p>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg">
                            <h3 className="text-xl font-semibold mb-3 text-gray-900 dark:text-white flex items-center">
                              <Calendar className="h-5 w-5 text-red-600 dark:text-red-400 mr-2" />
                              2018: Tashkil topishi
                            </h3>
                            <p className="text-gray-600 dark:text-gray-400">
                              Andijon shahrida birinchi do'kon ochildi. Dastlabki jamoada atigi 5 nafar xodim bo'lgan.
                            </p>
                          </div>
                          <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg">
                            <h3 className="text-xl font-semibold mb-3 text-gray-900 dark:text-white flex items-center">
                              <Calendar className="h-5 w-5 text-red-600 dark:text-red-400 mr-2" />
                              2019: Kengayish
                            </h3>
                            <p className="text-gray-600 dark:text-gray-400">
                              Toshkent va Samarqand shaharlarida yangi filiallar ochildi. Mahsulotlar assortimenti
                              kengaytirildi.
                            </p>
                          </div>
                          <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg">
                            <h3 className="text-xl font-semibold mb-3 text-gray-900 dark:text-white flex items-center">
                              <Calendar className="h-5 w-5 text-red-600 dark:text-red-400 mr-2" />
                              2020: Onlayn platforma
                            </h3>
                            <p className="text-gray-600 dark:text-gray-400">
                              Pandemiya davrida kompaniya to'liq onlayn platformaga o'tdi va yetkazib berish xizmatini
                              yo'lga qo'ydi.
                            </p>
                          </div>
                          <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg">
                            <h3 className="text-xl font-semibold mb-3 text-gray-900 dark:text-white flex items-center">
                              <Calendar className="h-5 w-5 text-red-600 dark:text-red-400 mr-2" />
                              2022-hozir: Yetakchilik
                            </h3>
                            <p className="text-gray-600 dark:text-gray-400">
                              O'zbekistondagi eng yirik elektron tijorat platformalaridan biriga aylandi. 200+ xodim va
                              50,000+ mijozlar.
                            </p>
                          </div>
                        </div>

                        <div className="relative h-[300px] rounded-lg overflow-hidden">
                          <Image
                            src="/placeholder.svg?height=300&width=800"
                            alt="Seven kompaniyasi tarixi"
                            fill
                            className="object-cover"
                          />
                        </div>
                      </motion.div>
                    )}

                    {activeTab === "mission" && (
                      <motion.div
                        key="mission"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        transition={{ duration: 0.3 }}
                        className="space-y-8"
                      >
                        <div>
                          <h2 className="text-3xl font-bold mb-4 text-gray-900 dark:text-white">
                            Missiya va qadriyatlar
                          </h2>
                          <p className="text-gray-600 dark:text-gray-400 mb-4">
                            Bizning missiyamiz - O'zbekiston aholisiga zamonaviy texnologiyalarni qulay narxlarda va
                            yuqori sifatli xizmat bilan yetkazib berishdir. Biz har bir mijozga individual yondashuvni
                            ta'minlash va ularning ehtiyojlarini qondirish uchun doimo harakat qilamiz.
                          </p>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                          <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg text-center">
                            <div className="w-12 h-12 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                              <Award className="h-6 w-6 text-red-600 dark:text-red-400" />
                            </div>
                            <h3 className="text-xl font-semibold mb-2 text-gray-900 dark:text-white">Sifat</h3>
                            <p className="text-gray-600 dark:text-gray-400">
                              Biz faqat yuqori sifatli va ishonchli mahsulotlarni taqdim etamiz
                            </p>
                          </div>
                          <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg text-center">
                            <div className="w-12 h-12 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                              <Users className="h-6 w-6 text-red-600 dark:text-red-400" />
                            </div>
                            <h3 className="text-xl font-semibold mb-2 text-gray-900 dark:text-white">Mijozlar</h3>
                            <p className="text-gray-600 dark:text-gray-400">
                              Mijozlarimiz bizning eng katta boyligimiz va ustuvorligimiz
                            </p>
                          </div>
                          <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg text-center">
                            <div className="w-12 h-12 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                              <Target className="h-6 w-6 text-red-600 dark:text-red-400" />
                            </div>
                            <h3 className="text-xl font-semibold mb-2 text-gray-900 dark:text-white">Innovatsiya</h3>
                            <p className="text-gray-600 dark:text-gray-400">
                              Biz doimo yangiliklar va innovatsiyalarga intilishga harakat qilamiz
                            </p>
                          </div>
                        </div>

                        <div className="bg-red-50 dark:bg-red-900/10 p-6 rounded-lg border border-red-100 dark:border-red-900/20">
                          <h3 className="text-xl font-semibold mb-3 text-gray-900 dark:text-white">Bizning va'damiz</h3>
                          <ul className="space-y-2 text-gray-600 dark:text-gray-400">
                            <li className="flex items-start">
                              <ChevronRight className="h-5 w-5 text-red-600 dark:text-red-400 mr-2 flex-shrink-0 mt-0.5" />
                              <span>Har bir mahsulot uchun kamida 1 yillik kafolat</span>
                            </li>
                            <li className="flex items-start">
                              <ChevronRight className="h-5 w-5 text-red-600 dark:text-red-400 mr-2 flex-shrink-0 mt-0.5" />
                              <span>14 kun ichida muammosiz qaytarish imkoniyati</span>
                            </li>
                            <li className="flex items-start">
                              <ChevronRight className="h-5 w-5 text-red-600 dark:text-red-400 mr-2 flex-shrink-0 mt-0.5" />
                              <span>24/7 mijozlarni qo'llab-quvvatlash xizmati</span>
                            </li>
                            <li className="flex items-start">
                              <ChevronRight className="h-5 w-5 text-red-600 dark:text-red-400 mr-2 flex-shrink-0 mt-0.5" />
                              <span>Toshkent bo'ylab bepul yetkazib berish</span>
                            </li>
                          </ul>
                        </div>
                      </motion.div>
                    )}

                    {activeTab === "team" && (
                      <motion.div
                        key="team"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        transition={{ duration: 0.3 }}
                        className="space-y-8"
                      >
                        <div>
                          <h2 className="text-3xl font-bold mb-4 text-gray-900 dark:text-white">Bizning jamoa</h2>
                          <p className="text-gray-600 dark:text-gray-400 mb-4">
                            Seven kompaniyasining muvaffaqiyati ortida turgan asosiy kuch - bu bizning ajoyib
                            jamoamizdir. Biz o'z sohasining mutaxassislari bo'lgan, innovatsion fikrlaydigan va mijozlar
                            uchun eng yaxshi natijalarni ta'minlashga intiluvchi insonlarni jamlagan jamoamiz bilan
                            faxrlanamiz.
                          </p>
                        </div>

                        <div className="space-y-8">
                          <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg">
                            <div className="flex flex-col md:flex-row gap-6">
                              <div className="md:w-1/3">
                                <div className="relative h-[300px] rounded-lg overflow-hidden">
                                  <Image
                                    src="/placeholder.svg?height=300&width=300"
                                    alt="Abdulaziz Toshpo'latov"
                                    fill
                                    className="object-cover"
                                  />
                                </div>
                              </div>
                              <div className="md:w-2/3">
                                <h3 className="text-2xl font-bold mb-2 text-gray-900 dark:text-white">
                                  Abdulaziz Toshpo'latov
                                </h3>
                                <p className="text-red-600 dark:text-red-400 font-medium mb-4">
                                  Asoschisi va Bosh direktor
                                </p>
                                <p className="text-gray-600 dark:text-gray-400 mb-4">
                                  Abdulaziz Toshpo'latov 1990-yilda Andijon viloyatida tug'ilgan. U Toshkent Axborot
                                  Texnologiyalari Universitetini tamomlagan va dasturiy ta'minot muhandisi sifatida
                                  faoliyat boshlagan.
                                </p>
                                <p className="text-gray-600 dark:text-gray-400 mb-4">
                                  2018-yilda u o'zining birinchi startapi - Seven elektron do'konini ochdi. Uning
                                  rahbarligi ostida kompaniya O'zbekistondagi eng yirik elektron tijorat
                                  platformalaridan biriga aylandi.
                                </p>
                                <p className="text-gray-600 dark:text-gray-400">
                                  "Bizning maqsadimiz - O'zbekiston aholisiga zamonaviy texnologiyalarni qulay narxlarda
                                  va yuqori sifatli xizmat bilan yetkazib berishdir. Biz har bir mijozga individual
                                  yondashuvni ta'minlash va ularning ehtiyojlarini qondirish uchun doimo harakat
                                  qilamiz."
                                </p>
                              </div>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg overflow-hidden">
                              <div className="relative h-[200px]">
                                <Image
                                  src="/placeholder.svg?height=200&width=300"
                                  alt="Jamoa a'zosi"
                                  fill
                                  className="object-cover"
                                />
                              </div>
                              <div className="p-4">
                                <h4 className="text-lg font-semibold text-gray-900 dark:text-white">Dilshod Karimov</h4>
                                <p className="text-red-600 dark:text-red-400 text-sm mb-2">
                                  Texnologiya bo'yicha direktor
                                </p>
                                <p className="text-gray-600 dark:text-gray-400 text-sm">
                                  10+ yillik IT sohasidagi tajriba. Seven kompaniyasining texnologik infratuzilmasini
                                  rivojlantirish uchun mas'ul.
                                </p>
                              </div>
                            </div>
                            <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg overflow-hidden">
                              <div className="relative h-[200px]">
                                <Image
                                  src="/placeholder.svg?height=200&width=300"
                                  alt="Jamoa a'zosi"
                                  fill
                                  className="object-cover"
                                />
                              </div>
                              <div className="p-4">
                                <h4 className="text-lg font-semibold text-gray-900 dark:text-white">Madina Rahimova</h4>
                                <p className="text-red-600 dark:text-red-400 text-sm mb-2">Marketing direktori</p>
                                <p className="text-gray-600 dark:text-gray-400 text-sm">
                                  Raqamli marketing sohasidagi mutaxassis. Seven brendini rivojlantirish va mijozlar
                                  bazasini kengaytirish uchun mas'ul.
                                </p>
                              </div>
                            </div>
                            <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg overflow-hidden">
                              <div className="relative h-[200px]">
                                <Image
                                  src="/placeholder.svg?height=200&width=300"
                                  alt="Jamoa a'zosi"
                                  fill
                                  className="object-cover"
                                />
                              </div>
                              <div className="p-4">
                                <h4 className="text-lg font-semibold text-gray-900 dark:text-white">Rustam Aliyev</h4>
                                <p className="text-red-600 dark:text-red-400 text-sm mb-2">
                                  Operatsiyalar bo'yicha direktor
                                </p>
                                <p className="text-gray-600 dark:text-gray-400 text-sm">
                                  Logistika va ta'minot zanjiri sohasidagi mutaxassis. Kompaniyaning kundalik
                                  operatsiyalarini boshqaradi.
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </TabsContent>

            {/* Warranty Tab Content */}
            <TabsContent value="warranty" className="mt-8">
              <div className="max-w-4xl mx-auto">
                <div className="mb-8 text-center">
                  <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Shield className="h-8 w-8 text-red-600 dark:text-red-400" />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Garantiya</h2>
                  <p className="text-gray-600 dark:text-gray-400">
                    Bizning do'konimizda sotiladigan barcha mahsulotlar rasmiy kafolat bilan ta'minlanadi. Mahsulotlar
                    sifatiga ishonamiz va mijozlarimizga ishonchli xizmat ko'rsatishni maqsad qilganmiz.
                  </p>
                </div>

                <div className="space-y-8">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center text-xl">
                        <Check className="h-5 w-5 text-green-500 mr-2" />
                        Nimalarga kafolat beriladi?
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        <li className="flex items-start">
                          <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                          <span>Zavod nuqsonlari (ichki nosozliklar)</span>
                        </li>
                        <li className="flex items-start">
                          <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                          <span>Rasmiy dasturiy ta'minotdagi xatoliklar</span>
                        </li>
                        <li className="flex items-start">
                          <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                          <span>Normal foydalanish davomida yuzaga kelgan texnik muammolar</span>
                        </li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center text-xl">
                        <AlertTriangle className="h-5 w-5 text-amber-500 mr-2" />
                        Kafolat quyidagi holatlarga tatbiq etilmaydi
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        <li className="flex items-start">
                          <AlertTriangle className="h-5 w-5 text-amber-500 mr-2 flex-shrink-0 mt-0.5" />
                          <span>Mahsulotning suvga tushishi, singishi yoki yonishi</span>
                        </li>
                        <li className="flex items-start">
                          <AlertTriangle className="h-5 w-5 text-amber-500 mr-2 flex-shrink-0 mt-0.5" />
                          <span>Kuchli zarba yoki noto'g'ri saqlash oqibatidagi shikastlar</span>
                        </li>
                        <li className="flex items-start">
                          <AlertTriangle className="h-5 w-5 text-amber-500 mr-2 flex-shrink-0 mt-0.5" />
                          <span>Mahsulotni ruxsatsiz (notasdiqlangan) servisda ochish yoki ta'mirlash</span>
                        </li>
                        <li className="flex items-start">
                          <AlertTriangle className="h-5 w-5 text-amber-500 mr-2 flex-shrink-0 mt-0.5" />
                          <span>Kuchlanish o'zgarishi tufayli yuzaga kelgan muammolar</span>
                        </li>
                        <li className="flex items-start">
                          <AlertTriangle className="h-5 w-5 text-amber-500 mr-2 flex-shrink-0 mt-0.5" />
                          <span>
                            Tashqi omillar (quyosh nurlari, namlik, chang) ta'sirida paydo bo'lgan nosozliklar
                          </span>
                        </li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center text-xl">
                        <Calendar className="h-5 w-5 text-blue-500 mr-2" />
                        Kafolat muddati
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Mahsulot turi</TableHead>
                            <TableHead>Kafolat muddati</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          <TableRow>
                            <TableCell className="font-medium">Yangi iPhone</TableCell>
                            <TableCell>12 oy</TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell className="font-medium">MacBook</TableCell>
                            <TableCell>12 oy</TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell className="font-medium">iPad</TableCell>
                            <TableCell>12 oy</TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell className="font-medium">Apple Watch</TableCell>
                            <TableCell>12 oy</TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell className="font-medium">Aksessuarlar</TableCell>
                            <TableCell>6 oy</TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell className="font-medium">Ishlatilgan mahsulotlar</TableCell>
                            <TableCell>1 oy (tekshiruv kafolati)</TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center text-xl">
                        <Truck className="h-5 w-5 text-indigo-500 mr-2" />
                        Kafolat asosida mahsulotni qaytarish / ta'mirlash tartibi
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ol className="list-decimal ml-5 space-y-2">
                        <li className="pl-1">
                          <span className="font-medium">Biz bilan bog'laning:</span>{" "}
                          <a
                            href="tel:+998987771133"
                            className="text-red-600 dark:text-red-400 hover:underline font-medium"
                          >
                            +998 98 777-11-33
                          </a>
                        </li>
                        <li className="pl-1">Mahsulotni ofisimizga yoki yetkazib berish xizmatimiz orqali yuboring</li>
                        <li className="pl-1">Mutaxassislarimiz mahsulotni tekshiradi (24–48 soat ichida)</li>
                        <li className="pl-1">Nosozlik tasdiqlansa, mahsulot ta'mirlanadi yoki almashtiriladi</li>
                      </ol>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center text-xl">
                        <MapPin className="h-5 w-5 text-purple-500 mr-2" />
                        Servis markazlarimiz
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                        <h4 className="font-semibold mb-2 text-gray-900 dark:text-white">Toshkent shahar bosh ofis:</h4>
                        <ul className="space-y-2 text-gray-600 dark:text-gray-400">
                          <li className="flex items-start">
                            <MapPin className="h-5 w-5 text-red-600 dark:text-red-400 mr-2 flex-shrink-0 mt-0.5" />
                            <span>Yunusobod tumani, Amir Temur ko'chasi, 45-uy</span>
                          </li>
                          <li className="flex items-start">
                            <Clock className="h-5 w-5 text-red-600 dark:text-red-400 mr-2 flex-shrink-0 mt-0.5" />
                            <span>Ish vaqti: Dushanba–Shanba, 09:00–18:00</span>
                          </li>
                          <li className="flex items-start">
                            <Phone className="h-5 w-5 text-red-600 dark:text-red-400 mr-2 flex-shrink-0 mt-0.5" />
                            <a href="tel:+998987771133" className="hover:underline">
                              Tel: +998 98 777-11-33
                            </a>
                          </li>
                        </ul>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center text-xl">
                        <MessageCircle className="h-5 w-5 text-teal-500 mr-2" />
                        Tez-tez so'raladigan savollar (FAQ)
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-semibold mb-1 text-gray-900 dark:text-white">
                            1. Mahsulotim ishlamayapti. Nima qilishim kerak?
                          </h4>
                          <p className="text-gray-600 dark:text-gray-400">
                            Birinchi navbatda, biz bilan bog'laning. Mutaxassislarimiz sizga maslahat beradi.
                          </p>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-1 text-gray-900 dark:text-white">
                            2. Kafolat qog'ozini yo'qotdim. Kafolat saqlanadimi?
                          </h4>
                          <p className="text-gray-600 dark:text-gray-400">
                            Agar xaridni bizning tizim orqali amalga oshirgan bo'lsangiz, kafolat elektron tarzda
                            saqlanadi.
                          </p>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-1 text-gray-900 dark:text-white">
                            3. Men mahsulotni o'zim ta'mirlaganman. Kafolat saqlanadimi?
                          </h4>
                          <p className="text-gray-600 dark:text-gray-400">
                            Yo'q. Nofavqulodda ta'mir harakati kafolatni bekor qiladi.
                          </p>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-1 text-gray-900 dark:text-white">
                            4. Kafolatni qanday uzaytirish mumkin?
                          </h4>
                          <p className="text-gray-600 dark:text-gray-400">
                            Ayrim mahsulotlar uchun qo'shimcha to'lov evaziga kafolat muddatini uzaytirish imkoni
                            mavjud. Qo'shimcha ma'lumot uchun bog'laning.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div className="mt-8 text-center">
                  <Button className="bg-red-600 hover:bg-red-700" onClick={scrollToContact}>
                    <Phone className="h-4 w-4 mr-2" />
                    Qo'shimcha savollar uchun bog'laning
                  </Button>
                </div>
              </div>
            </TabsContent>

            {/* Delivery Tab Content */}
            <TabsContent value="delivery" className="mt-8">
              <div className="max-w-4xl mx-auto">
                <div className="mb-8 text-center">
                  <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Truck className="h-8 w-8 text-red-600 dark:text-red-400" />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Yetkazib berish</h2>
                  <p className="text-gray-600 dark:text-gray-400">
                    Seven kompaniyasi O'zbekiston bo'ylab tezkor va ishonchli yetkazib berish xizmatini taqdim etadi.
                  </p>
                </div>

                <div className="space-y-8">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center text-xl">
                        <Check className="h-5 w-5 text-green-500 mr-2" />
                        Yetkazib berish turlari
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                          <h4 className="font-semibold mb-2 text-gray-900 dark:text-white flex items-center">
                            <Truck className="h-5 w-5 text-red-600 dark:text-red-400 mr-2" />
                            Standart yetkazib berish
                          </h4>
                          <p className="text-gray-600 dark:text-gray-400 mb-2">
                            Toshkent shahrida 24 soat ichida, viloyatlarda 2-3 kun ichida yetkazib beriladi.
                          </p>
                          <p className="text-green-600 dark:text-green-400 font-medium">
                            Bepul (50,000 so'mdan yuqori xaridlar uchun)
                          </p>
                        </div>
                        <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                          <h4 className="font-semibold mb-2 text-gray-900 dark:text-white flex items-center">
                            <Truck className="h-5 w-5 text-red-600 dark:text-red-400 mr-2" />
                            Tezkor yetkazib berish
                          </h4>
                          <p className="text-gray-600 dark:text-gray-400 mb-2">
                            Toshkent shahrida 3 soat ichida, viloyat markazlarida 24 soat ichida yetkazib beriladi.
                          </p>
                          <p className="text-gray-900 dark:text-gray-100 font-medium">
                            30,000 so'm (Toshkent), 50,000 so'm (viloyatlar)
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center text-xl">
                        <MapPin className="h-5 w-5 text-blue-500 mr-2" />
                        Qamrov hududi
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <p className="text-gray-600 dark:text-gray-400">
                          Biz O'zbekistonning barcha viloyatlari va Qoraqalpog'iston Respublikasi hududiga yetkazib
                          berish xizmatini taqdim etamiz.
                        </p>
                        <div className="relative h-[300px] rounded-lg overflow-hidden">
                          <Image
                            src="/placeholder.svg?height=300&width=800"
                            alt="O'zbekiston xaritasi"
                            fill
                            className="object-cover"
                          />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                          <div>
                            <h4 className="font-semibold mb-2 text-gray-900 dark:text-white">
                              Standart yetkazib berish:
                            </h4>
                            <ul className="space-y-1 text-gray-600 dark:text-gray-400">
                              <li>• Toshkent shahri</li>
                              <li>• Toshkent viloyati</li>
                              <li>• Samarqand</li>
                              <li>• Buxoro</li>
                              <li>• Andijon</li>
                              <li>• Farg'ona</li>
                              <li>• Namangan</li>
                            </ul>
                          </div>
                          <div>
                            <h4 className="font-semibold mb-2 text-gray-900 dark:text-white">
                              Tezkor yetkazib berish:
                            </h4>
                            <ul className="space-y-1 text-gray-600 dark:text-gray-400">
                              <li>• Toshkent shahri</li>
                              <li>• Toshkent viloyati (asosiy shaharlar)</li>
                              <li>• Samarqand shahri</li>
                              <li>• Andijon shahri</li>
                              <li>• Namangan shahri</li>
                              <li>• Farg'ona shahri</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center text-xl">
                        <Clock className="h-5 w-5 text-amber-500 mr-2" />
                        Yetkazib berish shartlari
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        <li className="flex items-start">
                          <ChevronRight className="h-5 w-5 text-red-600 dark:text-red-400 mr-2 flex-shrink-0 mt-0.5" />
                          <span>Yetkazib berish vaqti ish kunlarida 9:00 dan 21:00 gacha</span>
                        </li>
                        <li className="flex items-start">
                          <ChevronRight className="h-5 w-5 text-red-600 dark:text-red-400 mr-2 flex-shrink-0 mt-0.5" />
                          <span>Buyurtmangiz yetkazib berilishidan oldin siz bilan bog'lanishadi</span>
                        </li>
                        <li className="flex items-start">
                          <ChevronRight className="h-5 w-5 text-red-600 dark:text-red-400 mr-2 flex-shrink-0 mt-0.5" />
                          <span>Mahsulotni tekshirish va qabul qilish uchun 10 daqiqa vaqt beriladi</span>
                        </li>
                        <li className="flex items-start">
                          <ChevronRight className="h-5 w-5 text-red-600 dark:text-red-400 mr-2 flex-shrink-0 mt-0.5" />
                          <span>
                            Agar siz ko'rsatilgan vaqtda uyda bo'lmasangiz, yetkazib berish keyingi kunga ko'chiriladi
                          </span>
                        </li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center text-xl">
                        <AlertTriangle className="h-5 w-5 text-red-500 mr-2" />
                        Yetkazib berishni bekor qilish va o'zgartirish
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <p className="text-gray-600 dark:text-gray-400">
                          Agar yetkazib berish vaqtini o'zgartirish yoki bekor qilish kerak bo'lsa, buyurtma berilgan
                          kunning o'zida soat 18:00 gacha bizga xabar berishingiz kerak.
                        </p>
                        <div className="bg-red-50 dark:bg-red-900/10 p-4 rounded-lg border border-red-100 dark:border-red-900/20">
                          <h4 className="font-semibold mb-2 text-gray-900 dark:text-white">Diqqat:</h4>
                          <p className="text-gray-600 dark:text-gray-400">
                            Agar yetkazib beruvchi kelgan vaqtda siz uyda bo'lmasangiz yoki buyurtmani qabul qilishni
                            rad etsangiz, keyingi yetkazib berish uchun qo'shimcha to'lov olinadi.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center text-xl">
                        <MessageCircle className="h-5 w-5 text-purple-500 mr-2" />
                        Tez-tez so'raladigan savollar
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-semibold mb-1 text-gray-900 dark:text-white">
                            1. Yetkazib berish jarayonini qanday kuzatish mumkin?
                          </h4>
                          <p className="text-gray-600 dark:text-gray-400">
                            Buyurtma berilgandan so'ng, SMS orqali kuzatish havolasini olasiz. Shuningdek, saytimizda
                            "Buyurtmani kuzatish" bo'limidan foydalanishingiz mumkin.
                          </p>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-1 text-gray-900 dark:text-white">
                            2. Qanday to'lov usullarini qabul qilasiz?
                          </h4>
                          <p className="text-gray-600 dark:text-gray-400">
                            Mahsulot yetkazib berilganda naqd pul, terminal orqali yoki onlayn to'lovni amalga
                            oshirishingiz mumkin.
                          </p>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-1 text-gray-900 dark:text-white">
                            3. Mahsulotni qabul qilishdan oldin tekshirsa bo'ladimi?
                          </h4>
                          <p className="text-gray-600 dark:text-gray-400">
                            Ha, albatta. Mahsulotni qabul qilishdan oldin uning tashqi ko'rinishini va ishini
                            tekshirishingiz mumkin.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div className="mt-8 text-center">
                  <Button className="bg-red-600 hover:bg-red-700" onClick={scrollToContact}>
                    <Phone className="h-4 w-4 mr-2" />
                    Yetkazib berish bo'yicha savollarga javob olish
                  </Button>
                </div>
              </div>
            </TabsContent>

            {/* News Tab Content */}
            <TabsContent value="news" className="mt-8">
              <div className="max-w-4xl mx-auto">
                <div className="mb-8 text-center">
                  <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                    <FileText className="h-8 w-8 text-red-600 dark:text-red-400" />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Yangiliklar</h2>
                  <p className="text-gray-600 dark:text-gray-400">
                    Eng so'nggi yangiliklar, mahsulotlar va yangilanishlar bir joyda!
                  </p>
                </div>

                <div className="space-y-6">
                  <div className="flex justify-end mb-4">
                    <div className="flex space-x-2">
                      <Button variant="outline" className="flex items-center">
                        <Calendar className="h-4 w-4 mr-2" />
                        <span>So'nggi yangiliklar</span>
                      </Button>
                      <Button variant="outline" className="flex items-center">
                        <Tag className="h-4 w-4 mr-2" />
                        <span>Kategoriyalar</span>
                      </Button>
                    </div>
                  </div>

                  <Card className="overflow-hidden">
                    <div className="md:flex">
                      <div className="md:w-1/3 relative h-60 md:h-auto">
                        <Image
                          src="/placeholder.svg?height=300&width=300"
                          alt="Yangi iPhone modellari"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="md:w-2/3 p-6">
                        <div className="flex items-center mb-2">
                          <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900/30">
                            Yangi mahsulotlar
                          </Badge>
                          <time className="text-sm text-gray-500 dark:text-gray-400 ml-2">05.11.2023</time>
                        </div>
                        <CardTitle className="mb-2 text-2xl">Yangi iPhone 15 seriyasi do'konimizga keldi!</CardTitle>
                        <CardDescription className="mb-4">
                          Apple kompaniyasining eng so'nggi flagmanlari endi Seven do'konlarida. A17 Pro protsessor,
                          titanium korpus va yangilangan kamera tizimi bilan jihozlangan iPhone 15 Pro va Pro Max
                          modellarini xarid qiling.
                        </CardDescription>
                        <div className="flex justify-between items-center">
                          <Button variant="link" className="p-0 h-auto text-red-600 dark:text-red-400">
                            Batafsil ma'lumot <ChevronRight className="h-4 w-4 ml-1" />
                          </Button>
                          <div className="flex items-center text-gray-500 dark:text-gray-400 text-sm">
                            <Eye className="h-4 w-4 mr-1" />
                            <span>1,245</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>

                  <Card className="overflow-hidden">
                    <div className="md:flex">
                      <div className="md:w-1/3 relative h-60 md:h-auto">
                        <Image
                          src="/placeholder.svg?height=300&width=300"
                          alt="Chegirma aksiyasi"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="md:w-2/3 p-6">
                        <div className="flex items-center mb-2">
                          <Badge className="bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300 hover:bg-red-100 dark:hover:bg-red-900/30">
                            Aksiyalar
                          </Badge>
                          <time className="text-sm text-gray-500 dark:text-gray-400 ml-2">15.10.2023</time>
                        </div>
                        <CardTitle className="mb-2 text-2xl">Yil oxirigacha chegirmalar mavsum!</CardTitle>
                        <CardDescription className="mb-4">
                          Yil yakuni munosabati bilan barcha Apple mahsulotlariga 10% dan 20% gacha chegirmalar taqdim
                          etilmoqda. MacBook, iPad va AirPods mahsulotlarini hamyonbop narxlarda xarid qiling!
                        </CardDescription>
                        <div className="flex justify-between items-center">
                          <Button variant="link" className="p-0 h-auto text-red-600 dark:text-red-400">
                            Batafsil ma'lumot <ChevronRight className="h-4 w-4 ml-1" />
                          </Button>
                          <div className="flex items-center text-gray-500 dark:text-gray-400 text-sm">
                            <Eye className="h-4 w-4 mr-1" />
                            <span>2,187</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>

                  <Card className="overflow-hidden">
                    <div className="md:flex">
                      <div className="md:w-1/3 relative h-60 md:h-auto">
                        <Image
                          src="/placeholder.svg?height=300&width=300"
                          alt="Muddatli to'lov"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="md:w-2/3 p-6">
                        <div className="flex items-center mb-2">
                          <Badge className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300 hover:bg-green-100 dark:hover:bg-green-900/30">
                            Xizmatlar
                          </Badge>
                          <time className="text-sm text-gray-500 dark:text-gray-400 ml-2">28.09.2023</time>
                        </div>
                        <CardTitle className="mb-2 text-2xl">Endi barcha mahsulotlar muddatli to'lov bilan!</CardTitle>
                        <CardDescription className="mb-4">
                          Mijozlarimiz uchun qulaylik yaratish maqsadida endi barcha mahsulotlarni bank kartasi orqali
                          6, 12 va 24 oy muddatga to'lov asosida xarid qilish imkoniyati joriy etildi.
                        </CardDescription>
                        <div className="flex justify-between items-center">
                          <Button variant="link" className="p-0 h-auto text-red-600 dark:text-red-400">
                            Batafsil ma'lumot <ChevronRight className="h-4 w-4 ml-1" />
                          </Button>
                          <div className="flex items-center text-gray-500 dark:text-gray-400 text-sm">
                            <Eye className="h-4 w-4 mr-1" />
                            <span>1,836</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                </div>

                <div className="mt-8 text-center">
                  <div className="mb-6">
                    <Button variant="outline" className="bg-white dark:bg-gray-800 shadow-sm">
                      Barcha yangiklarni ko'rish
                    </Button>
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg">
                    <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">
                      Yangiliklar byulleteniga obuna bo'ling
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400 mb-4">
                      Eng so'nggi yangiliklar, yangi mahsulotlar va aksiyalar haqida birinchi bo'lib xabardor bo'ling!
                    </p>
                    <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
                      <Input type="email" placeholder="Email manzilingizni kiriting" />
                      <Button className="bg-red-600 hover:bg-red-700">
                        <MailOpen className="h-4 w-4 mr-2" />
                        Obuna bo'lish
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Contact Tab Content */}
            <TabsContent value="contact" className="mt-8" ref={formRef}>
              <div className="max-w-4xl mx-auto">
                <div className="mb-8 text-center">
                  <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                    <MessageCircle className="h-8 w-8 text-red-600 dark:text-red-400" />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Bog'lanish</h2>
                  <p className="text-gray-600 dark:text-gray-400">
                    Har qanday savol, taklif yoki hamkorlik bo'yicha biz bilan bog'laning. Mijozlarimizni qadrlaymiz va
                    sizning fikringiz biz uchun muhim.
                  </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div>
                    <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Bog'lanish ma'lumotlari</h3>
                    <div className="space-y-6">
                      <Card>
                        <CardContent className="pt-6">
                          <div className="space-y-4">
                            <div className="flex items-start">
                              <div className="w-10 h-10 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center flex-shrink-0 mr-4">
                                <Phone className="h-5 w-5 text-red-600 dark:text-red-400" />
                              </div>
                              <div>
                                <h4 className="font-semibold text-gray-900 dark:text-white">Telefon raqami</h4>
                                <a href="tel:+998987771133" className="text-red-600 dark:text-red-400 hover:underline">
                                  +998 98-777-11-33
                                </a>
                              </div>
                            </div>
                            <div className="flex items-start">
                              <div className="w-10 h-10 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center flex-shrink-0 mr-4">
                                <Mail className="h-5 w-5 text-red-600 dark:text-red-400" />
                              </div>
                              <div>
                                <h4 className="font-semibold text-gray-900 dark:text-white">Email</h4>
                                <a
                                  href="mailto:support@seven.uz"
                                  className="text-red-600 dark:text-red-400 hover:underline"
                                >
                                  support@seven.uz
                                </a>
                              </div>
                            </div>
                            <div className="flex items-start">
                              <div className="w-10 h-10 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center flex-shrink-0 mr-4">
                                <MapPin className="h-5 w-5 text-red-600 dark:text-red-400" />
                              </div>
                              <div>
                                <h4 className="font-semibold text-gray-900 dark:text-white">Manzil</h4>
                                <p className="text-gray-600 dark:text-gray-400">
                                  Toshkent shahri, Chilonzor tumani, Kichik xalqa yo'li 45-uy
                                </p>
                              </div>
                            </div>
                            <div className="flex items-start">
                              <div className="w-10 h-10 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center flex-shrink-0 mr-4">
                                <Clock className="h-5 w-5 text-red-600 dark:text-red-400" />
                              </div>
                              <div>
                                <h4 className="font-semibold text-gray-900 dark:text-white">Ish vaqti</h4>
                                <p className="text-gray-600 dark:text-gray-400">Har kuni, 09:00 — 20:00</p>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      <div>
                        <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Ijtimoiy tarmoqlar</h3>
                        <div className="flex space-x-4">
                          <a
                            href="https://t.me/seven_muddatli"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center hover:bg-blue-200 dark:hover:bg-blue-800/50 transition-colors"
                          >
                            <svg
                              className="w-6 h-6 text-blue-600 dark:text-blue-400"
                              viewBox="0 0 24 24"
                              fill="none"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <path
                                d="M22.2581 3.03371C21.9881 2.79371 21.5001 2.74971 20.9501 2.90371L2.90006 9.57371C2.01006 9.83371 1.55006 10.2237 1.53006 10.7437C1.51006 11.2637 1.94006 11.6837 2.82006 11.9837L6.21006 13.0537L8.33006 20.0637C8.50006 20.6237 8.83006 21.0037 9.25006 21.1737C9.43006 21.2437 9.61006 21.2737 9.80006 21.2737C10.0801 21.2737 10.3601 21.1937 10.6301 21.0337L13.0701 19.2537L16.1901 21.8337C16.5401 22.1337 16.9401 22.2837 17.3601 22.2837C17.5501 22.2837 17.7401 22.2537 17.9301 22.1837C18.4701 22.0137 18.8801 21.6137 19.0301 21.0937L22.9401 4.55371C23.1301 3.85371 22.8801 3.47371 22.2581 3.03371Z"
                                fill="currentColor"
                              />
                            </svg>
                          </a>
                          <a
                            href="https://www.instagram.com/seven_iphone.uz/"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="w-12 h-12 rounded-full bg-pink-100 dark:bg-pink-900/30 flex items-center justify-center hover:bg-pink-200 dark:hover:bg-pink-800/50 transition-colors"
                          >
                            <Instagram className="h-6 w-6 text-pink-600 dark:text-pink-400" />
                          </a>
                          <a
                            href="#"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center hover:bg-blue-200 dark:hover:bg-blue-800/50 transition-colors"
                          >
                            <Facebook className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                          </a>
                        </div>
                      </div>

                      <div className="relative rounded-lg overflow-hidden h-64">
                        <iframe
                          src="https://yandex.uz/maps/org/seven_uz/5479195480/?ll=71.784168%2C40.385773&z=16.65"
                          width="100%"
                          height="100%"
                          style={{ border: 0 }}
                          allowFullScreen
                          loading="lazy"
                          referrerPolicy="no-referrer-when-downgrade"
                          className="absolute inset-0"
                        ></iframe>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Aloqa formasi</h3>
                    <Card>
                      <CardContent className="pt-6">
                        <form onSubmit={handleFormSubmit} className="space-y-4">
                          <div>
                            <label
                              htmlFor="name"
                              className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
                            >
                              Ismingiz*
                            </label>
                            <Input
                              id="name"
                              name="name"
                              value={formData.name}
                              onChange={handleFormChange}
                              required
                              placeholder="Ismingizni kiriting"
                            />
                          </div>
                          <div>
                            <label
                              htmlFor="email"
                              className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
                            >
                              Email manzilingiz*
                            </label>
                            <Input
                              id="email"
                              name="email"
                              type="email"
                              value={formData.email}
                              onChange={handleFormChange}
                              required
                              placeholder="Email manzilingizni kiriting"
                            />
                          </div>
                          <div>
                            <label
                              htmlFor="phone"
                              className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
                            >
                              Telefon raqamingiz (ixtiyoriy)
                            </label>
                            <Input
                              id="phone"
                              name="phone"
                              type="tel"
                              value={formData.phone}
                              onChange={handleFormChange}
                              placeholder="+998 90 123-45-67"
                            />
                          </div>
                          <div>
                            <label
                              htmlFor="subject"
                              className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
                            >
                              Murojaat mavzusi*
                            </label>
                            <Input
                              id="subject"
                              name="subject"
                              value={formData.subject}
                              onChange={handleFormChange}
                              required
                              placeholder="Murojaat mavzusini kiriting"
                            />
                          </div>
                          <div>
                            <label
                              htmlFor="message"
                              className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
                            >
                              Xabar matni*
                            </label>
                            <Textarea
                              id="message"
                              name="message"
                              value={formData.message}
                              onChange={handleFormChange}
                              required
                              placeholder="Xabar matnini kiriting"
                              rows={5}
                            />
                          </div>
                          <Button type="submit" className="w-full bg-red-600 hover:bg-red-700">
                            <Send className="h-4 w-4 mr-2" />
                            Yuborish
                          </Button>

                          {formSuccess && (
                            <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg text-center">
                              <p className="text-green-600 dark:text-green-400 font-medium">
                                Xabaringiz muvaffaqiyatli yuborildi!
                              </p>
                            </div>
                          )}
                        </form>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-red-600 to-red-700 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Bizning jamoaga qo'shiling</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Seven kompaniyasi doimo o'z sohasining mutaxassislarini izlaydi. Agar siz innovatsion va tez rivojlanayotgan
            kompaniyada ishlashni xohlasangiz, bizga qo'shiling!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="bg-white text-red-600 hover:bg-gray-100">Vakansiyalarni ko'rish</Button>
            <Button variant="outline" className="border-white text-white hover:bg-white/10" onClick={scrollToContact}>
              Biz bilan bog'lanish
            </Button>
          </div>
        </div>
      </section>
    </main>
  )
}
