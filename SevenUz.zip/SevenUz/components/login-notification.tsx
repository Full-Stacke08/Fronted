"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X, LogIn } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useLanguage } from "./language-provider"

interface LoginNotificationProps {
  onClose: () => void
  onLogin: () => void
}

export default function LoginNotification({ onClose, onLogin }: LoginNotificationProps) {
  const [isVisible, setIsVisible] = useState(false)
  const { translations } = useLanguage()

  useEffect(() => {
    // Show notification with a slight delay
    const timer = setTimeout(() => {
      setIsVisible(true)
    }, 500)

    return () => clearTimeout(timer)
  }, [])

  const handleClose = () => {
    setIsVisible(false)
    // Wait for exit animation to complete
    setTimeout(onClose, 300)
  }

  const handleLogin = () => {
    setIsVisible(false)
    // Wait for exit animation to complete
    setTimeout(() => {
      onClose()
      onLogin()
    }, 300)
  }

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          transition={{ duration: 0.3 }}
          className="fixed bottom-4 right-4 z-50 max-w-sm w-full bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 overflow-hidden"
        >
          <div className="p-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-red-100 dark:bg-red-900/30 rounded-full p-2">
                  <LogIn className="h-5 w-5 text-red-600 dark:text-red-400" />
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-gray-900 dark:text-white">
                    {translations.login} / {translations.register}
                  </h3>
                  <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                    {translations.dontHaveAccount?.split("?")[0] || "Don't have an account"}?
                  </p>
                </div>
              </div>
              <button
                onClick={handleClose}
                className="flex-shrink-0 ml-4 bg-white dark:bg-transparent rounded-md inline-flex text-gray-400 hover:text-gray-500 focus:outline-none"
              >
                <span className="sr-only">Keyinroq</span>
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="mt-4">
              <Button onClick={handleLogin} className="w-full bg-red-600 hover:bg-red-700">
                {translations.login}
              </Button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
