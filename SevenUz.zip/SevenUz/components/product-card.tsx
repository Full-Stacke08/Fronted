"use client"

import type React from "react"

import Image from "next/image"
import { motion } from "framer-motion"
import {
  ShoppingCart,
  Star,
  Cpu,
  HardDrive,
  Monitor,
  Battery,
  Camera,
  Smartphone,
  Headphones,
  Watch,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useCart } from "@/components/cart-provider"
import { useToast } from "@/hooks/use-toast"
import { useLanguage } from "@/components/language-provider"
import type { Product } from "@/lib/types"

interface ProductCardProps {
  product: Product
  categoryId: string
}

export function ProductCard({ product, categoryId }: ProductCardProps) {
  const { addToCart } = useCart()
  const { toast } = useToast()
  const { language, translations } = useLanguage()

  const getProductField = (field: "name" | "description") => {
    const langKey = field + language.charAt(0).toUpperCase() + language.slice(1)
    return (product as any)[langKey] || product[field] || ""
  }

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()

    addToCart({
      id: product.id,
      name: getProductField("name"),
      price: product.price,
      quantity: 1,
      image: product.image || "",
    })

    toast({
      title: translations.productAdded,
      description: `${getProductField("name")} ${translations.productAddedDesc}`,
      duration: 3000,
    })
  }

  // Mahsulot turiga qarab batafsil ma'lumotlar (uch tilda)
  const getProductDetails = () => {
    const name = product.name.toLowerCase()

    const specs = {
      uz: {
        processor: "Protsessor",
        camera: "Kamera",
        display: "Displey",
        battery: "Batareya",
        ram: "RAM",
        storage: "Xotira",
        chip: "Chip",
        anc: "Shovqin bekor qilish",
        audio: "Audio",
        body: "Korpus",
      },
      ru: {
        processor: "Процессор",
        camera: "Камера",
        display: "Дисплей",
        battery: "Батарея",
        ram: "ОЗУ",
        storage: "Память",
        chip: "Чип",
        anc: "Шумоподавление",
        audio: "Аудио",
        body: "Корпус",
      },
      en: {
        processor: "Processor",
        camera: "Camera",
        display: "Display",
        battery: "Battery",
        ram: "RAM",
        storage: "Storage",
        chip: "Chip",
        anc: "Noise Cancelling",
        audio: "Audio",
        body: "Body",
      },
    }

    const currentSpecs = specs[language as keyof typeof specs] || specs.uz

    if (name.includes("iphone") || name.includes("samsung") || name.includes("xiaomi")) {
      return {
        icon: <Smartphone className="h-4 w-4" />,
        specs: [
          {
            icon: <Cpu className="h-3 w-3" />,
            label: currentSpecs.processor,
            value: name.includes("iphone")
              ? "A17 Pro"
              : name.includes("samsung")
                ? "Snapdragon 8 Gen 3"
                : "Snapdragon 8 Gen 2",
          },
          {
            icon: <Camera className="h-3 w-3" />,
            label: currentSpecs.camera,
            value: name.includes("iphone") ? "48MP + 12MP" : "50MP + 12MP",
          },
          {
            icon: <Monitor className="h-3 w-3" />,
            label: currentSpecs.display,
            value: name.includes("iphone") ? '6.7" Super Retina' : '6.8" Dynamic AMOLED',
          },
          {
            icon: <Battery className="h-3 w-3" />,
            label: currentSpecs.battery,
            value: name.includes("iphone") ? "4441 mAh" : "5000 mAh",
          },
        ],
      }
    } else if (name.includes("macbook") || name.includes("laptop") || name.includes("asus") || name.includes("hp")) {
      return {
        icon: <Monitor className="h-4 w-4" />,
        specs: [
          {
            icon: <Cpu className="h-3 w-3" />,
            label: currentSpecs.processor,
            value: name.includes("macbook") ? "M3 Pro" : name.includes("asus") ? "Intel i7-13700H" : "AMD Ryzen 7",
          },
          { icon: <HardDrive className="h-3 w-3" />, label: currentSpecs.ram, value: "16GB" },
          { icon: <HardDrive className="h-3 w-3" />, label: "SSD", value: name.includes("macbook") ? "512GB" : "1TB" },
          {
            icon: <Monitor className="h-3 w-3" />,
            label: currentSpecs.display,
            value: name.includes("macbook") ? '16.2" Liquid Retina' : '15.6" Full HD',
          },
        ],
      }
    } else if (name.includes("watch") || name.includes("soat")) {
      return {
        icon: <Watch className="h-4 w-4" />,
        specs: [
          {
            icon: <Cpu className="h-3 w-3" />,
            label: currentSpecs.processor,
            value: name.includes("apple") ? "S9 SiP" : "Snapdragon W5",
          },
          {
            icon: <Monitor className="h-3 w-3" />,
            label: currentSpecs.display,
            value: name.includes("apple") ? "49mm OLED" : '1.4" AMOLED',
          },
          {
            icon: <Battery className="h-3 w-3" />,
            label: currentSpecs.battery,
            value: name.includes("apple")
              ? language === "uz"
                ? "36 soat"
                : language === "ru"
                  ? "36 часов"
                  : "36 hours"
              : language === "uz"
                ? "7 kun"
                : language === "ru"
                  ? "7 дней"
                  : "7 days",
          },
          {
            icon: <Watch className="h-3 w-3" />,
            label: currentSpecs.body,
            value: name.includes("apple")
              ? "Titanium"
              : language === "uz"
                ? "Alyuminiy"
                : language === "ru"
                  ? "Алюминий"
                  : "Aluminum",
          },
        ],
      }
    } else if (name.includes("airpods") || name.includes("headphone") || name.includes("quloqchin")) {
      return {
        icon: <Headphones className="h-4 w-4" />,
        specs: [
          {
            icon: <Cpu className="h-3 w-3" />,
            label: currentSpecs.chip,
            value: name.includes("airpods") ? "H2 chip" : "Bluetooth 5.3",
          },
          {
            icon: <Battery className="h-3 w-3" />,
            label: currentSpecs.battery,
            value: name.includes("airpods")
              ? language === "uz"
                ? "20 soat"
                : language === "ru"
                  ? "20 часов"
                  : "20 hours"
              : language === "uz"
                ? "30 soat"
                : language === "ru"
                  ? "30 часов"
                  : "30 hours",
          },
          {
            icon: <Headphones className="h-3 w-3" />,
            label: currentSpecs.anc,
            value: name.includes("airpods")
              ? language === "uz"
                ? "Adaptive"
                : language === "ru"
                  ? "Адаптивное"
                  : "Adaptive"
              : "Hybrid ANC",
          },
          {
            icon: <Headphones className="h-3 w-3" />,
            label: currentSpecs.audio,
            value: language === "uz" ? "Yuqori sifat" : language === "ru" ? "Hi-Res Audio" : "Hi-Res Audio",
          },
        ],
      }
    } else if (name.includes("ipad") || name.includes("tablet") || name.includes("planshet")) {
      return {
        icon: <Monitor className="h-4 w-4" />,
        specs: [
          {
            icon: <Cpu className="h-3 w-3" />,
            label: currentSpecs.processor,
            value: name.includes("ipad") ? "M2 chip" : "Snapdragon 8 Gen 2",
          },
          {
            icon: <Monitor className="h-3 w-3" />,
            label: currentSpecs.display,
            value: name.includes("ipad") ? '12.9" Liquid Retina' : '11" OLED',
          },
          { icon: <Camera className="h-3 w-3" />, label: currentSpecs.camera, value: "12MP + 10MP" },
          { icon: <HardDrive className="h-3 w-3" />, label: currentSpecs.storage, value: product.memory || "128GB" },
        ],
      }
    }

    return {
      icon: <Smartphone className="h-4 w-4" />,
      specs: [
        {
          icon: <Cpu className="h-3 w-3" />,
          label: currentSpecs.processor,
          value: language === "uz" ? "Yuqori sifat" : language === "ru" ? "Высокое качество" : "High Quality",
        },
        {
          icon: <Monitor className="h-3 w-3" />,
          label: currentSpecs.display,
          value: "HD+",
        },
        {
          icon: <Battery className="h-3 w-3" />,
          label: currentSpecs.battery,
          value: language === "uz" ? "Uzoq muddatli" : language === "ru" ? "Долговечная" : "Long-lasting",
        },
        {
          icon: <Camera className="h-3 w-3" />,
          label: language === "uz" ? "Sifat" : language === "ru" ? "Качество" : "Quality",
          value: language === "uz" ? "Premium" : language === "ru" ? "Премиум" : "Premium",
        },
      ],
    }
  }

  const productDetails = getProductDetails()

  return (
    <motion.div whileHover={{ y: -5, scale: 1.02 }} transition={{ duration: 0.2 }} className="h-full">
      <Card className="overflow-hidden h-full flex flex-col shadow-lg hover:shadow-xl transition-all duration-300">
        <div className="relative aspect-square bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-900">
          <Image
            src={product.image || "/placeholder.svg?height=300&width=300"}
            alt={getProductField("name")}
            fill
            className="object-contain p-4 transition-transform duration-300 hover:scale-105"
          />

          {/* Badges */}
          <div className="absolute top-2 left-2 flex flex-col gap-1">
            {product.oldPrice && (
              <Badge className="bg-red-600 text-white text-xs font-bold">
                -{Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100)}%
              </Badge>
            )}
            {product.isNew && (
              <Badge className="bg-green-600 text-white text-xs font-bold">{translations.newModel}</Badge>
            )}
          </div>

          {/* Product Type Icon */}
          <div className="absolute top-2 right-2 bg-white dark:bg-gray-800 rounded-full p-2 shadow-md">
            {productDetails.icon}
          </div>

          {/* Stock Status */}
          <div className="absolute bottom-2 left-2">
            <Badge variant={product.stock && product.stock > 10 ? "default" : "destructive"} className="text-xs">
              {product.stock && product.stock > 10 ? translations.inStock : translations.outOfStock}
            </Badge>
          </div>
        </div>

        <CardContent className="p-4 flex-1 flex flex-col">
          {/* Product Name */}
          <h3 className="font-bold text-lg text-gray-900 dark:text-white mb-2 line-clamp-2 min-h-[3.5rem]">
            {getProductField("name")}
          </h3>

          {/* Rating */}
          <div className="flex items-center mb-3">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`h-4 w-4 ${
                    i < Math.floor(product.rating || 5)
                      ? "text-yellow-400 fill-current"
                      : "text-gray-300 dark:text-gray-600"
                  }`}
                />
              ))}
            </div>
            <span className="text-sm text-gray-600 dark:text-gray-400 ml-2">
              {product.rating || 5.0} ({product.reviews || Math.floor(Math.random() * 100) + 50} {translations.reviews})
            </span>
          </div>

          {/* Product Specifications */}
          <div className="space-y-2 mb-4 flex-1">
            {productDetails.specs.map((spec, index) => (
              <div key={index} className="flex items-center justify-between text-sm">
                <div className="flex items-center text-gray-600 dark:text-gray-400">
                  {spec.icon}
                  <span className="ml-2">{spec.label}:</span>
                </div>
                <span className="font-medium text-gray-900 dark:text-white text-right">{spec.value}</span>
              </div>
            ))}
          </div>

          {/* Memory and Color Options */}
          <div className="space-y-2 mb-4">
            {product.memory && (
              <div className="flex flex-wrap gap-1">
                <Badge variant="outline" className="text-xs">
                  {product.memory}
                </Badge>
              </div>
            )}
            {product.color && (
              <div className="flex flex-wrap gap-1">
                <Badge variant="outline" className="text-xs">
                  {language === "uz" && product.colorUz
                    ? product.colorUz
                    : language === "ru" && product.colorRu
                      ? product.colorRu
                      : product.color}
                </Badge>
              </div>
            )}
          </div>

          {/* Price and Add to Cart */}
          <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-200 dark:border-gray-700">
            <div className="flex flex-col">
              <span className="text-2xl font-bold text-red-600 dark:text-red-400">${product.price}</span>
              {product.oldPrice && (
                <span className="text-sm text-gray-500 dark:text-gray-400 line-through">${product.oldPrice}</span>
              )}
            </div>
            <Button
              onClick={handleAddToCart}
              className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg transition-all duration-200 hover:scale-105"
            >
              <ShoppingCart className="h-4 w-4 mr-2" />
              {translations.addToCart}
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
