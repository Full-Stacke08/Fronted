"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

interface UserAddress {
  street: string
  city: string
  postalCode: string
  country: string
}

interface UserPromoCode {
  code: string
  discount: number
  used: boolean
  dateUsed?: string
}

interface UserOrder {
  id: string
  date: string
  products: {
    id: string
    name: string
    price: number
    quantity: number
  }[]
  total: number
  status: "pending" | "processing" | "shipped" | "delivered" | "cancelled"
}

interface User {
  id: string
  firstName: string
  lastName: string
  email?: string
  phone?: string
  password: string
  avatar?: string
  addresses: UserAddress[]
  promoCodes: UserPromoCode[]
  orders: UserOrder[]
  wishlist: string[]
  dateJoined: string
  lastLogin: string
  isAdmin?: boolean
}

interface AuthContextType {
  user: User | null
  login: (
    email: string | undefined,
    phone: string | undefined,
    password: string,
  ) => Promise<{ success: boolean; message: string }>
  register: (userData: Partial<User> & { password: string }) => Promise<{ success: boolean; message: string }>
  logout: () => void
  updateUser: (userData: Partial<User>) => void
  isAuthenticated: boolean
  addPromoCode: (code: string, discount: number) => void
  usePromoCode: (code: string) => boolean
  addAddress: (address: UserAddress) => void
  removeAddress: (index: number) => void
  addToWishlist: (productId: string) => void
  removeFromWishlist: (productId: string) => void
  loginError: string
  registerError: string
}

// Default users for testing
const getDefaultUsers = (): User[] => [
  {
    id: "admin-1",
    firstName: "Admin",
    lastName: "SevenUZ",
    email: "Admin-sevenuz@gmail.com",
    phone: "+998901111111",
    password: "admin-78542585426",
    avatar: "https://randomuser.me/api/portraits/men/32.jpg",
    addresses: [
      {
        street: "Admin ko'chasi, 1-uy",
        city: "Toshkent",
        postalCode: "100000",
        country: "O'zbekiston",
      },
    ],
    promoCodes: [
      {
        code: "ADMIN100",
        discount: 100,
        used: false,
      },
    ],
    orders: [],
    wishlist: [],
    dateJoined: "2025-01-01",
    lastLogin: new Date().toISOString(),
    isAdmin: true,
  },
  {
    id: "user-1",
    firstName: "Test",
    lastName: "User",
    email: "test@example.com",
    phone: "+998901234567",
    password: "123456",
    avatar: "https://randomuser.me/api/portraits/men/1.jpg",
    addresses: [],
    promoCodes: [
      {
        code: "WELCOME20",
        discount: 20,
        used: false,
      },
    ],
    orders: [],
    wishlist: [],
    dateJoined: "2025-01-15",
    lastLogin: new Date().toISOString(),
  },
]

const AuthContext = createContext<AuthContextType>({
  user: null,
  login: async () => ({ success: false, message: "" }),
  register: async () => ({ success: false, message: "" }),
  logout: () => {},
  updateUser: () => {},
  isAuthenticated: false,
  addPromoCode: () => {},
  usePromoCode: () => false,
  addAddress: () => {},
  removeAddress: () => {},
  addToWishlist: () => {},
  removeFromWishlist: () => {},
  loginError: "",
  registerError: "",
})

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [users, setUsers] = useState<User[]>([])
  const [loginError, setLoginError] = useState("")
  const [registerError, setRegisterError] = useState("")

  // Initialize users on mount
  useEffect(() => {
    console.log("🔄 AuthProvider initializing...")

    // Always start with default users
    const defaultUsers = getDefaultUsers()

    try {
      const savedUsers = localStorage.getItem("sevenuz_users")
      if (savedUsers) {
        const parsedUsers = JSON.parse(savedUsers)
        console.log("📦 Loaded users from localStorage:", parsedUsers)
        setUsers(parsedUsers)
      } else {
        console.log("🆕 No saved users, using defaults")
        setUsers(defaultUsers)
        localStorage.setItem("sevenuz_users", JSON.stringify(defaultUsers))
      }
    } catch (error) {
      console.error("❌ Error loading users:", error)
      setUsers(defaultUsers)
      localStorage.setItem("sevenuz_users", JSON.stringify(defaultUsers))
    }

    // Check if user is logged in
    try {
      const savedUser = localStorage.getItem("sevenuz_currentUser")
      if (savedUser) {
        const parsedUser = JSON.parse(savedUser)
        console.log("👤 Found logged in user:", parsedUser)
        setUser(parsedUser)
        setIsAuthenticated(true)
      }
    } catch (error) {
      console.error("❌ Error loading current user:", error)
      localStorage.removeItem("sevenuz_currentUser")
    }
  }, [])

  const login = async (
    email: string | undefined,
    phone: string | undefined,
    password: string,
  ): Promise<{ success: boolean; message: string }> => {
    console.log("🔐 Login attempt:", { email, phone, password })
    setLoginError("")

    // Validation
    if ((!email && !phone) || !password) {
      const message = "Email/telefon va parol kiritish shart"
      setLoginError(message)
      console.log("❌ Validation failed:", message)
      return { success: false, message }
    }

    // Get current users
    const currentUsers = users.length > 0 ? users : getDefaultUsers()
    console.log("👥 Checking against users:", currentUsers)

    // Find user
    const foundUser = currentUsers.find((u) => {
      const emailMatch = email && u.email && u.email.toLowerCase() === email.toLowerCase()
      const phoneMatch = phone && u.phone === phone
      const passwordMatch = u.password === password

      console.log("🔍 Checking user:", {
        userEmail: u.email,
        userPhone: u.phone,
        userPassword: u.password,
        emailMatch,
        phoneMatch,
        passwordMatch,
      })

      return (emailMatch || phoneMatch) && passwordMatch
    })

    if (!foundUser) {
      const message = "Noto'g'ri email/telefon yoki parol"
      setLoginError(message)
      console.log("❌ User not found or wrong password")
      return { success: false, message }
    }

    console.log("✅ User found:", foundUser)

    // Update last login
    const updatedUser = {
      ...foundUser,
      lastLogin: new Date().toISOString(),
    }

    // Update users array
    const updatedUsers = currentUsers.map((u) => (u.id === updatedUser.id ? updatedUser : u))
    setUsers(updatedUsers)
    localStorage.setItem("sevenuz_users", JSON.stringify(updatedUsers))

    // Set current user
    setUser(updatedUser)
    setIsAuthenticated(true)
    localStorage.setItem("sevenuz_currentUser", JSON.stringify(updatedUser))

    // Set admin flag if needed
    if (updatedUser.isAdmin) {
      localStorage.setItem("sevenuz_isAdmin", "true")
      console.log("👑 Admin user logged in")
    }

    console.log("✅ Login successful")
    return { success: true, message: "Muvaffaqiyatli kirish" }
  }

  const register = async (
    userData: Partial<User> & { password: string },
  ): Promise<{ success: boolean; message: string }> => {
    console.log("📝 Registration attempt:", userData)
    setRegisterError("")

    // Validation
    if (!userData.firstName) {
      const message = "Ism kiritish shart"
      setRegisterError(message)
      return { success: false, message }
    }

    if (!userData.password || userData.password.length < 3) {
      const message = "Parol kamida 3 ta belgi bo'lishi kerak"
      setRegisterError(message)
      return { success: false, message }
    }

    if (!userData.email && !userData.phone) {
      const message = "Email yoki telefon raqami kiritish shart"
      setRegisterError(message)
      return { success: false, message }
    }

    // Get current users
    const currentUsers = users.length > 0 ? users : getDefaultUsers()

    // Check if user exists
    const userExists = currentUsers.some((u) => {
      const emailMatch = userData.email && u.email && u.email.toLowerCase() === userData.email.toLowerCase()
      const phoneMatch = userData.phone && u.phone === userData.phone
      return emailMatch || phoneMatch
    })

    if (userExists) {
      const message = "Bu email/telefon raqami bilan foydalanuvchi allaqachon mavjud"
      setRegisterError(message)
      return { success: false, message }
    }

    // Create new user
    const newUser: User = {
      id: `user-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      firstName: userData.firstName,
      lastName: userData.lastName || "",
      email: userData.email,
      phone: userData.phone,
      password: userData.password,
      avatar: userData.avatar || `https://randomuser.me/api/portraits/lego/${Math.floor(Math.random() * 10)}.jpg`,
      addresses: [],
      promoCodes: [
        {
          code: "WELCOME20",
          discount: 20,
          used: false,
        },
      ],
      orders: [],
      wishlist: [],
      dateJoined: new Date().toISOString(),
      lastLogin: new Date().toISOString(),
    }

    console.log("👤 Creating new user:", newUser)

    // Add user to array
    const updatedUsers = [...currentUsers, newUser]
    setUsers(updatedUsers)
    localStorage.setItem("sevenuz_users", JSON.stringify(updatedUsers))

    // Log in the new user
    setUser(newUser)
    setIsAuthenticated(true)
    localStorage.setItem("sevenuz_currentUser", JSON.stringify(newUser))

    console.log("✅ Registration successful")
    return { success: true, message: "Muvaffaqiyatli ro'yxatdan o'tish" }
  }

  const logout = () => {
    console.log("🚪 Logging out")
    setUser(null)
    setIsAuthenticated(false)
    localStorage.removeItem("sevenuz_currentUser")
    localStorage.removeItem("sevenuz_isAdmin")
    setLoginError("")
    setRegisterError("")
  }

  const updateUser = (userData: Partial<User>) => {
    if (!user) return

    const updatedUser = { ...user, ...userData }
    const updatedUsers = users.map((u) => (u.id === updatedUser.id ? updatedUser : u))

    setUsers(updatedUsers)
    localStorage.setItem("sevenuz_users", JSON.stringify(updatedUsers))
    setUser(updatedUser)
    localStorage.setItem("sevenuz_currentUser", JSON.stringify(updatedUser))
  }

  const addPromoCode = (code: string, discount: number) => {
    if (!user || user.promoCodes.some((promo) => promo.code === code)) return

    const updatedUser = {
      ...user,
      promoCodes: [...user.promoCodes, { code, discount, used: false }],
    }

    updateUser(updatedUser)
  }

  const usePromoCode = (code: string): boolean => {
    if (!user) return false

    const promoIndex = user.promoCodes.findIndex((promo) => promo.code === code && !promo.used)
    if (promoIndex === -1) return false

    const updatedPromoCodes = [...user.promoCodes]
    updatedPromoCodes[promoIndex] = {
      ...updatedPromoCodes[promoIndex],
      used: true,
      dateUsed: new Date().toISOString(),
    }

    updateUser({ promoCodes: updatedPromoCodes })
    return true
  }

  const addAddress = (address: UserAddress) => {
    if (!user) return
    updateUser({ addresses: [...user.addresses, address] })
  }

  const removeAddress = (index: number) => {
    if (!user || index < 0 || index >= user.addresses.length) return
    const updatedAddresses = [...user.addresses]
    updatedAddresses.splice(index, 1)
    updateUser({ addresses: updatedAddresses })
  }

  const addToWishlist = (productId: string) => {
    if (!user || user.wishlist.includes(productId)) return
    updateUser({ wishlist: [...user.wishlist, productId] })
  }

  const removeFromWishlist = (productId: string) => {
    if (!user) return
    updateUser({ wishlist: user.wishlist.filter((id) => id !== productId) })
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        register,
        logout,
        updateUser,
        isAuthenticated,
        addPromoCode,
        usePromoCode,
        addAddress,
        removeAddress,
        addToWishlist,
        removeFromWishlist,
        loginError,
        registerError,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider")
  }
  return context
}
