import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Check, ChevronRight, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

export default function AppleWatchUltra2Page() {
  return (
    <div className="bg-white dark:bg-gray-950">
      {/* Breadcrumb */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
          <Link href="/" className="hover:text-red-600 dark:hover:text-red-400">
            Bosh sahifa
          </Link>
          <ChevronRight className="h-4 w-4 mx-2" />
          <Link href="/category/smartwatches" className="hover:text-red-600 dark:hover:text-red-400">
            Aqlli soatlar
          </Link>
          <ChevronRight className="h-4 w-4 mx-2" />
          <span className="text-gray-900 dark:text-white">Apple Watch Ultra 2</span>
        </div>
      </div>

      {/* Hero Section */}
      <div className="bg-gradient-to-b from-gray-100 to-white dark:from-gray-900 dark:to-gray-950 py-12 md:py-20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="w-full md:w-1/2 mb-8 md:mb-0">
              <Link href="/" className="inline-flex items-center text-red-600 mb-6 hover:underline">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Orqaga
              </Link>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-4">
                Apple Watch Ultra 2 (2025)
              </h1>
              <div className="flex items-center mb-4">
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="h-5 w-5 fill-current text-yellow-500" />
                  ))}
                </div>
                <span className="ml-2 text-gray-600 dark:text-gray-400">4.9 (842 sharh)</span>
              </div>
              <p className="text-lg text-gray-700 dark:text-gray-300 mb-6">
                Apple'ning eng chidamli va ko'p funksiyali aqlli soati. Yangilangan S9 protsessori, yanada yorqin
                displey va 36 soatgacha batareya quvvati bilan.
              </p>
              <div className="flex items-center mb-6">
                <span className="text-3xl font-bold text-gray-900 dark:text-white">7,999,000 so'm</span>
                <Badge className="ml-3 bg-green-600">Muddatli to'lov mavjud</Badge>
              </div>
              <div className="flex flex-wrap gap-4">
                <Button size="lg" className="bg-red-600 hover:bg-red-700">
                  Savatga qo'shish
                </Button>
              </div>
            </div>
            <div className="w-full md:w-1/2 flex justify-center">
              <div className="relative h-[400px] w-[700px]">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/watch-ultra-2-select-gps-cellular-49mm-titanium-blue-alpine-loop-blue_VW_34FR+watch-ultra-2-select-gps-cellular-49mm-titanium-blue-alpine-loop-blue_VW_SIDE_VW_34FR?wid=2560&hei=1640&fmt=p-jpg&qlt=80&.v=1693954851397"
                  alt="Apple Watch Ultra 2"
                  fill
                  className="object-contain"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Product Details */}
      <div className="container mx-auto px-4 py-12">
        <Tabs defaultValue="features" className="w-full">
          <TabsList className="grid w-full md:w-auto grid-cols-3 mb-8">
            <TabsTrigger value="features">Xususiyatlar</TabsTrigger>
            <TabsTrigger value="specifications">Texnik ma'lumotlar</TabsTrigger>
            <TabsTrigger value="reviews">Sharhlar</TabsTrigger>
          </TabsList>
          <TabsContent value="features" className="space-y-12">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                  S9 SiP - Eng kuchli Apple Watch protsessori
                </h2>
                <p className="text-gray-700 dark:text-gray-300 mb-4">
                  Yangi S9 SiP (System in Package) protsessori avvalgidan 30% tezroq va 20% energiya samaradorroq. Bu
                  sizga kunning oxirigacha batareya quvvatini saqlagan holda eng talabchan ilovalarni ham muammosiz
                  ishlatish imkonini beradi.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">64-bit ikki yadroli protsessor</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">
                      4-yadroli Neural Engine sun'iy intellekt operatsiyalari uchun
                    </span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">
                      Yangilangan grafik protsessor animatsiyalar va vizualizatsiya uchun
                    </span>
                  </li>
                </ul>
              </div>
              <div className="relative h-[300px]">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/watch-ultra-2-hero-202309_GEO_US?wid=1000&hei=1000&fmt=png-alpha&.v=1693611639539"
                  alt="S9 SiP Processor"
                  fill
                  className="object-contain"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div className="order-2 md:order-1 relative h-[300px]">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/watch-ultra-2-cellular-gps-202309_GEO_US?wid=1000&hei=1000&fmt=png-alpha&.v=1693611639539"
                  alt="Display"
                  fill
                  className="object-contain"
                />
              </div>
              <div className="order-1 md:order-2">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Yangilangan Retina displey</h2>
                <p className="text-gray-700 dark:text-gray-300 mb-4">
                  49 mm Always-On Retina displey 3000 nit gacha yorqinlikka ega, bu uni hatto eng yorqin quyosh nurida
                  ham o'qish imkonini beradi. Kechasi esa 1 nit gacha pasayib, ko'zlaringizni qorong'ida himoya qiladi.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">410x502 piksel o'lchamli Retina displey</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">LTPO OLED Always-On texnologiyasi</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">Sapfir kristalli himoya qatlami</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Chidamli va ko'p funksiyali</h2>
                <p className="text-gray-700 dark:text-gray-300 mb-4">
                  Apple Watch Ultra 2 har qanday sharoitda ishlash uchun mo'ljallangan. 100 metr chuqurlikkacha suv
                  o'tkazmaydigan korpus, -20°C dan +55°C gacha haroratda ishlash qobiliyati va titanli korpus uni eng
                  ekstrim sharoitlarda ham ishonchli hamrohga aylantiradi.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">100 metr chuqurlikkacha suv o'tkazmaydigan</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">MIL-STD 810H harbiy standartga mos</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                    <span className="text-gray-700 dark:text-gray-300">Titanli korpus yengil va o'ta chidamli</span>
                  </li>
                </ul>
              </div>
              <div className="relative h-[300px]">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/watch-ultra-2-202309_GEO_US?wid=1000&hei=1000&fmt=png-alpha&.v=1693611639539"
                  alt="Durability"
                  fill
                  className="object-contain"
                />
              </div>
            </div>
          </TabsContent>
          <TabsContent value="specifications" className="space-y-6">
            <div className="border dark:border-gray-800 rounded-lg overflow-hidden">
              <div className="grid grid-cols-1 md:grid-cols-2">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">Displey</div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  49 mm Always-On Retina LTPO OLED displey, 3000 nit maksimal yorqinlik
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  Protsessor
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  Apple S9 SiP, 64-bit ikki yadroli protsessor, 4-yadroli Neural Engine
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">Xotira</div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">32GB ichki xotira</div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  Batareya
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  36 soatgacha oddiy rejimda, 72 soatgacha quvvatni tejash rejimida
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  Sensorlar
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  Yurak urishi sensori, EKG, SpO2, harorat sensori, akselerometr, giroskop, altimetr, kompas
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">Aloqa</div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  LTE va UMTS, Wi-Fi 802.11b/g/n 2.4GHz va 5GHz, Bluetooth 5.3, Ultra Wideband chip, GPS/GNSS
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  Chidamlilik
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  100 metr chuqurlikkacha suv o'tkazmaydigan (ISO standart 22810:2010), EN13319 g'avvoslik standarti
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 border-t dark:border-gray-800">
                <div className="p-4 bg-gray-50 dark:bg-gray-900 font-medium text-gray-900 dark:text-white">
                  O'lchamlari
                </div>
                <div className="p-4 border-t md:border-t-0 md:border-l dark:border-gray-800">
                  49 x 44 x 14.4 mm, 61.3 g (brasletsiz)
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="reviews" className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">Mijozlar sharhlari</h3>
              <Button>Sharh qoldirish</Button>
            </div>

            <div className="space-y-6">
              {/* Review 1 */}
              <div className="border dark:border-gray-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                      <span className="font-medium text-gray-700 dark:text-gray-300">BT</span>
                    </div>
                    <div className="ml-3">
                      <p className="font-medium text-gray-900 dark:text-white">Bobur Toshmatov</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">15 May, 2025</p>
                    </div>
                  </div>
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-4 w-4 fill-current text-yellow-500" />
                    ))}
                  </div>
                </div>
                <p className="text-gray-700 dark:text-gray-300">
                  Men bu soatni tog' sayohatlarim uchun sotib oldim va juda mamnunman! Batareya quvvati ajoyib, GPS aniq
                  ishlaydi, va eng muhimi - har qanday ob-havo sharoitida ham ishonchli ishlaydi. Titanli korpus juda
                  yengil va chidamli.
                </p>
              </div>

              {/* Review 2 */}
              <div className="border dark:border-gray-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                      <span className="font-medium text-gray-700 dark:text-gray-300">SA</span>
                    </div>
                    <div className="ml-3">
                      <p className="font-medium text-gray-900 dark:text-white">Sarvinoz Aliyeva</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">2 May, 2025</p>
                    </div>
                  </div>
                  <div className="flex">
                    {[1, 2, 3, 4].map((star) => (
                      <Star key={star} className="h-4 w-4 fill-current text-yellow-500" />
                    ))}
                    <Star className="h-4 w-4 text-gray-300 dark:text-gray-600" />
                  </div>
                </div>
                <p className="text-gray-700 dark:text-gray-300">
                  Soat juda yaxshi, lekin narxi biroz qimmat. Displey yorqinligi va batareya quvvati juda zo'r, ammo
                  o'lchamlari ayollar qo'li uchun biroz katta. Umumiy baholashim - yaxshi, lekin mukammal emas.
                </p>
              </div>

              {/* Review 3 */}
              <div className="border dark:border-gray-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                      <span className="font-medium text-gray-700 dark:text-gray-300">RI</span>
                    </div>
                    <div className="ml-3">
                      <p className="font-medium text-gray-900 dark:text-white">Rustam Ismoilov</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">20 April, 2025</p>
                    </div>
                  </div>
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-4 w-4 fill-current text-yellow-500" />
                    ))}
                  </div>
                </div>
                <p className="text-gray-700 dark:text-gray-300">
                  Men g'avvoslik bilan shug'ullanaman va bu soat suvosti sayohatlarim uchun ajoyib hamroh bo'ldi. 100
                  metr chuqurlikkacha suv o'tkazmaydigan korpus, maxsus g'avvoslik rejimi va aniq ma'lumotlar bilan
                  ishlash qobiliyati - barchasi juda yaxshi ishlaydi. Albatta tavsiya qilaman!
                </p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Related Products */}
      <div className="bg-gray-50 dark:bg-gray-900 py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-8">O'xshash mahsulotlar</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Product 1 */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
              <div className="relative h-48">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/MT603ref_VW_34FR+watch-45-alum-midnight-nc-9s_VW_34FR_WF_CO_GEO_US?wid=1400&hei=1400&trim=1%2C0&fmt=p-jpg&qlt=95&.v=1693011485580"
                  alt="Apple Watch Series 9"
                  fill
                  className="object-contain p-4"
                />
              </div>
              <div className="p-4">
                <h3 className="font-medium text-gray-900 dark:text-white mb-2">Apple Watch Series 9</h3>
                <div className="flex items-center mb-2">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-3 w-3 fill-current text-yellow-500" />
                    ))}
                  </div>
                  <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">(1245)</span>
                </div>
                <p className="text-red-600 font-bold">4,999,000 so'm</p>
              </div>
            </div>

            {/* Product 2 */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
              <div className="relative h-48">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/watch-se-digitalmat-gallery-1-202309_GEO_US?wid=728&hei=666&fmt=png-alpha&.v=1693274502646"
                  alt="Apple Watch SE"
                  fill
                  className="object-contain p-4"
                />
              </div>
              <div className="p-4">
                <h3 className="font-medium text-gray-900 dark:text-white mb-2">Apple Watch SE</h3>
                <div className="flex items-center mb-2">
                  <div className="flex">
                    {[1, 2, 3, 4].map((star) => (
                      <Star key={star} className="h-3 w-3 fill-current text-yellow-500" />
                    ))}
                    <Star className="h-3 w-3 text-gray-300 dark:text-gray-600" />
                  </div>
                  <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">(876)</span>
                </div>
                <p className="text-red-600 font-bold">2,999,000 so'm</p>
              </div>
            </div>

            {/* Product 3 */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
              <div className="relative h-48">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/airpods-max-select-silver-202011?wid=940&hei=1112&fmt=png-alpha&.v=1604021221000"
                  alt="AirPods Max"
                  fill
                  className="object-contain p-4"
                />
              </div>
              <div className="p-4">
                <h3 className="font-medium text-gray-900 dark:text-white mb-2">AirPods Max</h3>
                <div className="flex items-center mb-2">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-3 w-3 fill-current text-yellow-500" />
                    ))}
                  </div>
                  <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">(932)</span>
                </div>
                <p className="text-red-600 font-bold">6,499,000 so'm</p>
              </div>
            </div>

            {/* Product 4 */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
              <div className="relative h-48">
                <Image
                  src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/iphone-16-pro-max-black-titanium-select?wid=940&hei=1112&fmt=png-alpha&.v=1694461306199"
                  alt="iPhone 16 Pro Max"
                  fill
                  className="object-contain p-4"
                />
              </div>
              <div className="p-4">
                <h3 className="font-medium text-gray-900 dark:text-white mb-2">iPhone 16 Pro Max</h3>
                <div className="flex items-center mb-2">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-3 w-3 fill-current text-yellow-500" />
                    ))}
                  </div>
                  <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">(1256)</span>
                </div>
                <p className="text-red-600 font-bold">14,999,000 so'm</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
