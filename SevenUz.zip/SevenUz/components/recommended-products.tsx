"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ShoppingCart, Check, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/components/cart-provider"
import { useToast } from "@/hooks/use-toast"
import { motion, AnimatePresence } from "framer-motion"
import { getRelatedProducts } from "@/lib/product-data"
import { useLanguage } from "@/hooks/use-language"

interface RecommendedProductsProps {
  productId: string
  title?: string
}

export default function RecommendedProducts({
  productId,
  title = "Tavsiya etilgan mahsulotlar",
}: RecommendedProductsProps) {
  const { addToCart } = useCart()
  const { toast } = useToast()
  const [addedProducts, setAddedProducts] = useState<{ [key: string]: boolean }>({})
  const { translations, language } = useLanguage()

  const relatedProducts = getRelatedProducts(productId)

  // Handle add to cart
  const handleAddToCart = (product: any) => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      quantity: 1,
      image: product.image,
    })

    // Show animation
    setAddedProducts((prev) => ({ ...prev, [product.id]: true }))

    // Reset after animation
    setTimeout(() => {
      setAddedProducts((prev) => ({ ...prev, [product.id]: false }))
    }, 1500)

    // Show toast notification
    toast({
      title: translations.productAdded,
      description: `${product.name} ${translations.addedToCart.toLowerCase()}`,
      duration: 3000,
    })
  }

  if (relatedProducts.length === 0) {
    return null
  }

  return (
    <section className="py-12 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold mb-8">{translations.recommendedProducts}</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {relatedProducts.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Link href={`/product/${product.id}`} className="block">
                <div className="relative h-48 bg-gray-100 dark:bg-gray-700">
                  <Image
                    src={product.image || "/placeholder.svg?height=200&width=200"}
                    alt={language === "uz" ? product.nameUz || product.name : product.name}
                    fill
                    className="object-contain w-full h-full p-2"
                  />
                  {product.oldPrice && (
                    <div className="absolute top-2 right-2 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded">
                      {language === "uz" ? "Chegirma" : "Sale"}
                    </div>
                  )}
                </div>
              </Link>

              <div className="p-4">
                <div className="flex items-center mb-1">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-3 w-3 ${
                          i
                            ? "text-yellow-400 fill-current"
                            : "text-gray-300 dark:text-gray-600"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-xs text-gray-600 dark:text-gray-400 ml-1">{product.rating}</span>
                </div>

                <Link href={`/product/${product.id}`} className="block">
                  <h3 className="font-medium text-gray-900 dark:text-white mb-1 hover:text-red-600 dark:hover:text-red-400 transition-colors line-clamp-2">
                    {language === "uz" ? product.nameUz || product.name : product.name}
                  </h3>
                </Link>

                <div className="flex items-center justify-between mt-2">
                  <div>
                    <span className="font-bold text-lg text-red-600 dark:text-red-400">${product.price}</span>
                    {product.oldPrice && (
                      <span className="text-sm text-gray-500 dark:text-gray-400 line-through ml-2">
                        ${product.oldPrice}
                      </span>
                    )}
                  </div>
                  <AnimatePresence>
                    {addedProducts[product.id] ? (
                      <motion.div
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.8, opacity: 0 }}
                        className="bg-green-600 text-white rounded-md px-3 py-1 flex items-center"
                      >
                        <Check className="h-4 w-4 mr-1" />
                        <span className="text-xs">{translations.added}</span>
                      </motion.div>
                    ) : (
                      <motion.div
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.8, opacity: 0 }}
                      >
                        <Button
                          size="sm"
                          onClick={() => handleAddToCart(product)}
                          className="bg-red-600 hover:bg-red-700 text-white"
                        >
                          <ShoppingCart className="h-4 w-4 mr-1" />
                          {translations.add}
                        </Button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
