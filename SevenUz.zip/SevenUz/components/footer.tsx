"use client"

import Link from "next/link"
import { Facebook, Instagram, Twitter, Youtube, Mail, Phone, MapPin } from "lucide-react"
import { useLanguage } from "./language-provider"

export default function Footer() {
  const { translations } = useLanguage()

  return (
    <footer className="bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">Seven</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">{translations.companyInfo}</p>
            <div className="flex space-x-4">
              <a
                href="https://facebook.com/sevenuz"
                className="text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a
                href="https://instagram.com/seven_uz"
                className="text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a
                href="https://t.me/seven_uz"
                className="text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                aria-label="Telegram"
              >
                <Twitter className="h-5 w-5" />
              </a>
              <a
                href="https://youtube.com/sevenuz"
                className="text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                aria-label="Youtube"
              >
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">{translations.categories}</h3>
            <ul className="space-y-2">
              <li>
                <Link
                  href="/category/smartphones"
                  className="text-gray-600 dark:text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                >
                  {translations.smartphones}
                </Link>
              </li>
              <li>
                <Link
                  href="/category/tablets"
                  className="text-gray-600 dark:text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                >
                  {translations.tablets}
                </Link>
              </li>
              <li>
                <Link
                  href="/category/laptops"
                  className="text-gray-600 dark:text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                >
                  {translations.laptops}
                </Link>
              </li>
              <li>
                <Link
                  href="/category/headphones"
                  className="text-gray-600 dark:text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                >
                  {translations.headphones}
                </Link>
              </li>
              <li>
                <Link
                  href="/category/smartwatches"
                  className="text-gray-600 dark:text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                >
                  {translations.smartwatches}
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">{translations.contact}</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 text-red-600 dark:text-red-400 mr-2 flex-shrink-0 mt-0.5" />
                 <a   className="text-gray-600 dark:text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors" target="_blank" href="https://yandex.uz/navi?whatshere%5Bpoint%5D=71.78416774147561%2C40.38577267242549&whatshere%5Bzoom%5D=17.423103&ll=71.7841677414756%2C40.385772672052916&z=17.423103">Fargʻona, Sayilgoh ko'chasi, 29</a>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 text-red-600 dark:text-red-400 mr-2 flex-shrink-0" />
                <a
                  href="tel:+998987771113"
                  className="text-gray-600 dark:text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                >
                  +998 98 777 11 33
                </a>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 text-red-600 dark:text-red-400 mr-2 flex-shrink-0" />
                <a
                  href="mailto:info@seven.uz"
                  className="text-gray-600 dark:text-gray-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
                >
                  info@seven.uz
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-gray-200 dark:border-gray-800">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-600 dark:text-gray-400 text-sm mb-4 md:mb-0">
              &copy; {new Date().getFullYear()} Seven. {translations.allRightsReserved}
            </p>
            <div className="flex flex-col md:flex-row items-center md:space-x-4 text-sm text-gray-600 dark:text-gray-400">
              <p>Kampaniya: UNIPRO</p>
              <p>Sayt yaratuvchisi: Lazizbek Sheryigitov</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
