import type React from "react"
import { TagIcon } from "lucide-react"
import { cn } from "@/lib/utils"

interface TagProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: "default" | "secondary" | "outline"
}

function Tag({ className, variant = "default", children, ...props }: TagProps) {
  return (
    <div
      className={cn(
        "inline-flex items-center rounded-md px-2.5 py-0.5 text-xs font-medium",
        variant === "default" && "bg-primary/10 text-primary",
        variant === "secondary" && "bg-secondary/50 text-secondary-foreground",
        variant === "outline" && "border border-input",
        className,
      )}
      {...props}
    >
      <TagIcon className="mr-1 h-3 w-3" />
      {children}
    </div>
  )
}

export { Tag }
