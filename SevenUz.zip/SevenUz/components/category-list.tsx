"use client"

import Link from "next/link"
import { categories as popularCategories } from "@/lib/categories"
import { motion } from "framer-motion"
import { useLanguage } from "@/hooks/use-language"

export default function CategoryList() {
  const { translations, language } = useLanguage()

  // Function to get the correct category name based on language
  const getCategoryName = (category: any) => {
    if (language === "uz") {
      return category.nameUz || category.name
    } else if (language === "ru") {
      return category.nameRu || category.name
    } else {
      return category.name
    }
  }

  return (
    <section className="py-12 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">{translations.categories}</h2>
        <div className="
          flex gap-4 overflow-x-auto pb-2
          md:grid md:grid-cols-3 lg:grid-cols-6 md:gap-4 md:overflow-x-visible
          scrollbar-thin scrollbar-thumb-gray-300 dark:scrollbar-thumb-gray-700
        ">
          {popularCategories.map((category, index) => (
            <motion.div
              key={category.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              whileHover={{ y: -5, scale: 1.03 }}
              className="min-w-[220px] md:min-w-0 flex-shrink-0 md:flex-shrink md:w-auto"
            >
              <Link
                href={`/category/${category.slug}`}
                className="group flex flex-col items-center p-4 bg-white dark:bg-gray-800 rounded-lg transition-all hover:shadow-lg"
              >
                <div className="w-full h-32 mb-4 overflow-hidden rounded-lg bg-gray-100 dark:bg-gray-700 flex items-center justify-center">
                  <img
                    src={category.image || "/placeholder.svg"}
                    alt={getCategoryName(category)}
                    className="w-full h-full object-cover transition-transform group-hover:scale-110"
                  />
                </div>
                <h3 className="text-lg font-medium text-center">{getCategoryName(category)}</h3>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
